var appointFinal = function(){

	WHRSCMain.setAlwaysReadonly('F_EFFECTIVE_DATE');
    WHRSCMain.setAlwaysReadonly('F_EMP_ID');
    WHRSCMain.setAlwaysReadonly('F_DATE_PROD_CAPHR');    
    $('#F_EFFECTIVE_DATE').css('background-color', '#efefef');
    $('#F_EMP_ID').css('background-color', '#efefef');
    $('#F_DATE_PROD_CAPHR').css('background-color', '#efefef');
    $('#F_EFFECTIVE_DATE_calendar_anchor').addClass('hidden');
	$('#F_DATE_PROD_CAPHR_calendar_anchor').addClass('hidden');
    $('#F_EFFECTIVE_DATE_calendar_anchor').attr('tabindex', 21);
    $('#F_DATE_PROD_CAPHR_calendar_anchor').attr('tabindex', 61);
    
    $('#temp_federal_hide').addClass('hidden');
    
    
    //dummy data EHRP
    $('#F_EFFECTIVE_DATE').val('03/08/2018');
    $('#F_EMP_ID').val('0011981432');
    $('#F_DATE_PROD_CAPHR').val('03/10/2018');
}