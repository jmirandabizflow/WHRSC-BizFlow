var base_url = '/bizflowwebmaker/listmanager_AUT/';
var manageCandidate = function(){

	setEmplPopulate();
    
	var displayAssign = 'false';
	hyf.util.hideComponent('Assign_Candidate');
	hyf.util.hideComponent('layout_group_53');

	$('#LIST_NAME').on("change", function(){
		var listNameLookup = $(this).children("option:selected").text();
		if(listNameLookup=='CTAP') {
			listNameLookup = 'listendReasonEndCTAP';
		}
		else if(listNameLookup=='PRL') {
			listNameLookup = 'listendReasonEndPRL';
		}
		else if(listNameLookup=='RPL') {
			listNameLookup = 'listendReasonEndRPL';
		}
		else {
			listNameLookup = 'listendReasonEndOTHER';
		}

		$.ajax({
			url: base_url + 'ListReasonEndReturn.do?listNameLookup=' + listNameLookup,
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				$('#ELIGIBILITY_END_REASON').empty();
				$('#ELIGIBILITY_END_REASON').append('<option value= >Select One</option>');
				var data = $('record', xmlResponse ).map(function() {
					 $('#ELIGIBILITY_END_REASON').append('<option value=\"' + $( 'LOOKUP_CODE', this ).text() + '\">' + $( 'LOOKUP_CODE', this ).text() + '</option>');
				}).get();
				
			}
		});	

	});
};

var setEmplPopulate = function () {
 
	$('#HHSID').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'HHSIDSearch.do?dataVal=' + $('#HHSID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {                      
						return {  
							lastName: $( 'LAST_NAME', this ).text(),
							firstName: $( 'FIRST_NAME', this ).text(),
							middleName: $( 'MIDDLE_NAME', this ).text(),
							emailAddress: $( 'EMAIL_ADDR', this ).text(),
							hhsId: $( 'HHSID', this ).text(),
							userType: $( 'USERTYPE', this ).text(),
							empId: $( 'EMPLID', this ).text(),
							payPlan: $( 'PAY_PLAN', this ).text(),
							grade: $( 'GRADE', this ).text(),
							positionTitle: $( 'POSITION_TITLE_NAME', this ).text(),
							series: $( 'SERIES', this ).text(),
							opdiv: $( 'OPDIV', this ).text(),
							orgCd: $( 'ORG_CD', this ).text(),
							staffdiv:$( 'STAFFDIV', this ).text(),
							perfRating:$( 'GVT_POSN_OCCUPIED', this ).text(),
							reviewRating:$( 'REVIEW_RATING', this ).text(),
							tenure:$( 'GVT_TENURE', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		/*
		change: function (e, u) {
			
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#HHSID_noMatch').remove();
				$(this).after("<span id='HHSID_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#HHSID_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#HHSID_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		*/
		select: function (event, ui) {
			var lastName = ui.item.lastName;
			var firstName = ui.item.firstName;
			var middleName = ui.item.middleName;
			var emailAddress = ui.item.emailAddress;
			var hhsId = ui.item.hhsId;
			var userType = ui.item.userType;
			var empId = ui.item.empId;
			var payPlan = ui.item.payPlan;
			var grade = ui.item.grade;
			var positionTitle = ui.item.positionTitle;
			var series = ui.item.series;
			var opdiv = ui.item.opdiv;
			var orgCd = ui.item.orgCd;
			var staffdiv = ui.item.staffdiv;
			var perfRating =  ui.item.perfRating;
			var reviewRating =  ui.item.reviewRating;
			var tenure =  ui.item.tenure;


			$('#LAST_NAME').val(lastName);
			$('#FIRST_NAME').val(firstName);
			$('#MIDDLE_INITIAL').val(middleName);
			$('#EMPLID').val(empId);
			$('#PAY_PLAN').val(payPlan);
			$('#GRADE').val(grade);
			$('#OCC_SERIES').val(series);
			$('#OPDIV').val(opdiv);
			$('#ADMIN_CODE').val(orgCd);
			$('#STAFF_DIV').val(staffdiv);
			$('#PERFORMANCE_RATING_CODE').val(perfRating);
			$('#POSITION_OCCUPIED').val(reviewRating);
			$('#TENURE_CODE').val(tenure);

			
			$("#HHSID").focus();
			setTimeout(function() {
				$('#HHSID').val(hhsId);
			}, 500);
		
		},
	
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	
	})

	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.hhsId + '">' + item.hhsId +  '</a>')
			.appendTo(ul);
	};	

	$('#EMPLID').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'EmplIDSearch.do?dataVal=' + $('#EMPLID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {                      
						return {  
							lastName: $( 'LAST_NAME', this ).text(),
							firstName: $( 'FIRST_NAME', this ).text(),
							middleName: $( 'MIDDLE_NAME', this ).text(),
							emailAddress: $( 'EMAIL_ADDR', this ).text(),
							hhsId: $( 'HHSID', this ).text(),
							userType: $( 'USERTYPE', this ).text(),
							empId: $( 'EMPLID', this ).text(),
							payPlan: $( 'PAY_PLAN', this ).text(),
							grade: $( 'GRADE', this ).text(),
							positionTitle: $( 'POSITION_TITLE_NAME', this ).text(),
							series: $( 'SERIES', this ).text(),
							opdiv: $( 'OPDIV', this ).text(),
							orgCd: $( 'ORG_CD', this ).text(),
							staffdiv:$( 'STAFFDIV', this ).text(),
							perfRating:$( 'GVT_POSN_OCCUPIED', this ).text(),
							reviewRating:$( 'REVIEW_RATING', this ).text(),
							tenure:$( 'GVT_TENURE', this ).text()


						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		select: function (event, ui) {
			var lastName = ui.item.lastName;
			var firstName = ui.item.firstName;
			var middleName = ui.item.middleName;
			var emailAddress = ui.item.emailAddress;
			var hhsId = ui.item.hhsId;
			var userType = ui.item.userType;
			var empId = ui.item.empId;
			var payPlan = ui.item.payPlan;
			var grade = ui.item.grade;
			var positionTitle = ui.item.positionTitle;
			var series = ui.item.series;
			var opdiv = ui.item.opdiv;
			var orgCd = ui.item.orgCd;
			var staffdiv = ui.item.staffdiv;
			var perfRating =  ui.item.perfRating;
			var reviewRating =  ui.item.reviewRating;
			var tenure =  ui.item.tenure;

			$('#LAST_NAME').val(lastName);
			$('#FIRST_NAME').val(firstName);
			$('#MIDDLE_INITIAL').val(middleName);
			$('#HHSID').val(hhsId);
			$('#PAY_PLAN').val(payPlan);
			$('#GRADE').val(grade);
			$('#OCC_SERIES').val(series);
			$('#OPDIV').val(opdiv);
			$('#ADMIN_CODE').val(orgCd);
			$('#STAFF_DIV').val(staffdiv);
			$('#PERFORMANCE_RATING_CODE').val(perfRating);
			$('#POSITION_OCCUPIED').val(reviewRating);
			$('#TENURE_CODE').val(tenure);

			
			$("#EMPLID").focus();
			setTimeout(function() {
				$('#EMPLID').val(empId);
			}, 500);
		},
	
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	
	})
		
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
		.append('<a title="' + item.empId + '">' + item.empId +  '</a>')
		.appendTo(ul);
	};

	$('#LAST_NAME').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'LastNameSearch.do?dataVal=' + $('#LAST_NAME').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {                      
						return {  
							lastName: $( 'LAST_NAME', this ).text(),
							firstName: $( 'FIRST_NAME', this ).text(),
							middleName: $( 'MIDDLE_NAME', this ).text(),
							emailAddress: $( 'EMAIL_ADDR', this ).text(),
							hhsId: $( 'HHSID', this ).text(),
							userType: $( 'USERTYPE', this ).text(),
							empId: $( 'EMPLID', this ).text(),
							payPlan: $( 'PAY_PLAN', this ).text(),
							grade: $( 'GRADE', this ).text(),
							positionTitle: $( 'POSITION_TITLE_NAME', this ).text(),
							series: $( 'SERIES', this ).text(),
							opdiv: $( 'OPDIV', this ).text(),
							orgCd: $( 'ORG_CD', this ).text(),
							staffdiv:$( 'STAFFDIV', this ).text(),
							perfRating:$( 'GVT_POSN_OCCUPIED', this ).text(),
							reviewRating:$( 'REVIEW_RATING', this ).text(),
							tenure:$( 'GVT_TENURE', this ).text()


						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		select: function (event, ui) {
			var lastName = ui.item.lastName;
			var firstName = ui.item.firstName;
			var middleName = ui.item.middleName;
			var emailAddress = ui.item.emailAddress;
			var hhsId = ui.item.hhsId;
			var userType = ui.item.userType;
			var empId = ui.item.empId;
			var payPlan = ui.item.payPlan;
			var grade = ui.item.grade;
			var positionTitle = ui.item.positionTitle;
			var series = ui.item.series;
			var opdiv = ui.item.opdiv;
			var orgCd = ui.item.orgCd;
			var staffdiv = ui.item.staffdiv;
			var perfRating =  ui.item.perfRating;
			var reviewRating =  ui.item.reviewRating;
			var tenure =  ui.item.tenure;

			$('#FIRST_NAME').val(firstName);
			$('#MIDDLE_INITIAL').val(middleName);
			$('#EMPLID').val(empId);
			$('#HHSID').val(hhsId);
			$('#PAY_PLAN').val(payPlan);
			$('#GRADE').val(grade);
			$('#OCC_SERIES').val(series);
			$('#OPDIV').val(opdiv);
			$('#ADMIN_CODE').val(orgCd);
			$('#STAFF_DIV').val(staffdiv);
			$('#PERFORMANCE_RATING_CODE').val(perfRating);
			$('#POSITION_OCCUPIED').val(reviewRating);
			$('#TENURE_CODE').val(tenure);

			
			$("#LAST_NAME").focus();
			setTimeout(function() {
				$('#LAST_NAME').val(lastName);
			}, 500);

		},
	
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	
	})
		
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.lastName + '">' + item.lastName +  '</a>')
			.appendTo(ul);
	};
};

function submitCandidate()
{
	var flag = true;
	var sHhsId = $('#HHSID').val();
	var sEmplId = $('#EMPLID').val();

	$.ajax({
		url: base_url + 'DuplicateCandidateCheck.do?hhsId=' + sHhsId + '&emplId=' + sEmplId,
		dataType: 'xml',
		cache: false,
		async: false,
		success: function (xmlResponse) {
			var data = $('record', xmlResponse ).map(function() {
				if($( 'COUNT', this ).text()!='0') {
					alert('Candidate already exists, enter a different candidate');
					$('#HHSID').val();
					$('#EMPLID').val();
					flag = false;
				}
			}).get();
		}
	});	

	if(flag==false) {
		return flag;
	}
	else {
		hyf.util.showComponent('Assign_Candidate');
		hyf.util.showComponent('layout_group_53');
		//hyf.util.disableComponent('Add_Candidate');
	
		$('#EMPLID').css('background-color', '#efefef');
		$('#HHSID').css('background-color', '#efefef');
		$('#LAST_NAME').css('background-color', '#efefef');
		$('#FIRST_NAME').css('background-color', '#efefef');
		$('#MIDDLE_INITIAL').css('background-color', '#efefef');
		$('#PAY_PLAN').css('background-color', '#efefef');
		$('#ADMIN_CODE').css('background-color', '#efefef');
		$('#OCC_SERIES').css('background-color', '#efefef');
		$('#GRADE').css('background-color', '#efefef');
		$('#OPDIV').css('background-color', '#efefef');
		$('#STAFF_DIV').css('background-color', '#efefef');
		$('#ORG_TITILE').css('background-color', '#efefef');
		$('#ADDRESS_LINE1').css('background-color', '#efefef');
		$('#ADDRESS_LINE2').css('background-color', '#efefef');
		$('#ADDRESS_CITY').css('background-color', '#efefef');
		$('#ADDRESS_STATE').css('background-color', '#efefef');
		$('#ADDRESS_ZIP').css('background-color', '#efefef');
		$('#PHONE_NUMBER').css('background-color', '#efefef');
		$('#EMAIL_ADDRESS').css('background-color', '#efefef');
		$('#HHS_EMPLMT_STATUS_CODE').css('background-color', '#efefef');
		$('#SEPARATION_DATE').css('background-color', '#efefef');
		$('#PERFORMANCE_RATING_CODE').css('background-color', '#efefef');
		$('#PERFORMANCE_PD_START').css('background-color', '#efefef');
		$('#PERFORMANCE_PD_END').css('background-color', '#efefef');
		$('#COMMENTS').css('background-color', '#efefef');
		$('#POSITION_OCCUPIED').css('background-color', '#efefef');
		$('#TENURE_CODE').css('background-color', '#efefef');
		$('#EMPL_DUTY_STATION').css('background-color', '#efefef');
		$('#LOCATION').css('background-color', '#efefef');
		$('#VETERAN_STATUS_CODE').css('background-color', '#efefef');

		$('#h_readOnly').val('y');
		
		return flag;
	}

}

function disabledCandidate() {
	setTimeout(function() {
				hyf.util.disableComponent('Add_Candidate');
			}, 1500);
	
}

function addEligibility() {
	var x='';
}