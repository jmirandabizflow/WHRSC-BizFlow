/**
 * Make sure the skin details are included in the main page form so that
 * they will be included in standard form submit actions.
 */
dojo.addOnLoad(function() {

        var skinDetails = document.getElementById('skin_workitemId_details');

        if (skinDetails)
        {
            var form = hyf.FMAction.getFormValidator().getForm();
            form.appendChild(skinDetails);
        }
})



/**
 * Make sure that the WIC ID fields in the skin are always submitted, even when doing an
 * ajax submission using a specific source group.
 */
require(["dojo/aspect"], function(aspect) {
        aspect.after(hyf.util, "encodeContainer", function(data) {

                //look for the skin details group
                var skinDetails = document.getElementById('skin_workitemId_details');

                if (skinDetails)
                {
                    //assume it only contains hidden fields
                    var inputs = skinDetails.getElementsByTagName('input');
                    for (var i = 0; i < inputs.length; ++i)
                    {
                        data[inputs[i].name] = inputs[i].value;
                    }
                }

                return data;
        });

});