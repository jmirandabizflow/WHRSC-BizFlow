var vacancyAnnouncement = function(){
    
    var cnt = $('#h_vacancy_count').val();
    var pcnt = $('#h_position_count').val();
    var vinnum = ["00000000"];

	var virtualCnt = cnt;
	
	var getRestData = $('#h_form_data').val();
 	if(getRestData!='') {
		var x2js = new X2JS();
		var getRestDataXML =  x2js.xml_str2json(getRestData);
	}

	if(cnt=="") {
		virtualCnt = 1;
		hyf.util.disableComponent('vacancy_group');

	}	
    //getActivityName
    //DEU Reviews/ Approves/Creates Vacancy/Cert
    var actName = WHRSCMain.activityOption.getActivityName();
	//alert (actName);
    
	for (var index = 1; index <= virtualCnt; index++) {
		
		var vnnNumber =  $('#vacancy_repeat' + index + 'V_VAN').val();
		var savedCnt = "";
		if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB!=undefined) {
			if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT!=undefined) {
				if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT.VACANCY!=undefined) {
					if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT.VACANCY.ANNOUNCEMENT!=undefined) {
						var vacancies = getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT.VACANCY.ANNOUNCEMENT;
						savedCnt = vacancies.status.record_count;	
						if(savedCnt=="0") {
							//do nothing
						}
						else if(savedCnt=="1") {
							if(vnnNumber==vacancies.record.V_VAN) {
								$('#vacancy_repeat' + index + 'V_CER').val(vacancies.record.V_CER);	
								$('#vacancy_repeat' + index + 'V_DHS').val(vacancies.record.V_DHS);	
								$('#vacancy_repeat' + index + 'V_DQR').val(vacancies.record.V_DQR);	
								$('#vacancy_repeat' + index + 'V_CRC').val(vacancies.record.V_CRC);	
								$('#vacancy_repeat' + index + 'V_SPFC').val(vacancies.record.V_SPFC);	
								$('#vacancy_repeat' + index + 'V_QR').val(vacancies.record.V_QR);	

								$('#vacancy_repeat' + index + 'V_OCA').val(vacancies.record.V_OCA);	
								$('#vacancy_repeat' + index + 'DIRECT_HIRE').val(vacancies.record.DIRECT_HIRE);	

								var vDsd = vacancies.record.V_DSD;
								if(vDsd!='') {
									vDsd = new Date(vDsd);
									$('#vacancy_repeat' + index + 'V_DSD').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, vDsd));
								}
								var vDaad = vacancies.record.V_DAAD;
								if(vDaad!='') {
									vDaad = new Date(vDaad);
									$('#vacancy_repeat' + index + 'V_DAAD').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},vDaad));
								}
							}
						}
						else {
							for (var indx =0; indx < savedCnt; indx++) {
								if(vnnNumber==vacancies.record[indx].V_VAN) {
									$('#vacancy_repeat' + index + 'V_CER').val(vacancies.record[indx].V_CER);	
									$('#vacancy_repeat' + index + 'V_DHS').val(vacancies.record[indx].V_DHS);	
									$('#vacancy_repeat' + index + 'V_DQR').val(vacancies.record[indx].V_DQR);	
									$('#vacancy_repeat' + index + 'V_CRC').val(vacancies.record[indx].V_CRC);	
									$('#vacancy_repeat' + index + 'V_SPFC').val(vacancies.record[indx].V_SPFC);	
									$('#vacancy_repeat' + index + 'V_QR').val(vacancies.record[indx].V_QR);	

									$('#vacancy_repeat' + index + 'V_OCA').val(vacancies.record[indx].V_OCA);	
									$('#vacancy_repeat' + index + 'DIRECT_HIRE').val(vacancies.record[indx].DIRECT_HIRE);	

									var vDsd = vacancies.record[indx].V_DSD;
									if(vDsd!='') {
										vDsd = new Date(vDsd);
										$('#vacancy_repeat' + index + 'V_DSD').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, vDsd));
									}
									var vDaad = vacancies.record[indx].V_DAAD;
									if(vDaad!='') {
										vDaad = new Date(vDaad);
										$('#vacancy_repeat' + index + 'V_DAAD').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},vDaad));
									}
								}
							}	
						}
						
					}
			
				}
			}
		}
		

		//calendar icon tabindex
		$('#vacancy_repeat' + index + 'V_DSD_calendar_anchor').attr('tabindex', 830);
		$('#vacancy_repeat' + index + 'V_DAAD_calendar_anchor').attr('tabindex', 830);
		$('#vacancy_repeat' + index + 'V_DAP_calendar_anchor').attr('tabindex', 830);
		$('#vacancy_repeat' + index + 'V_DAO_calendar_anchor').attr('tabindex', 830);
		$('#vacancy_repeat' + index + 'V_DACL_calendar_anchor').attr('tabindex', 830);
		$('#vacancy_repeat' + index + 'V_DACA_calendar_anchor').attr('tabindex', 830);
		
		vinnum[index] = $('#vacancy_repeat' + index + 'V_VIN').val();
		
		/*$('#vacancy_repeat' + index + 'V_USASTAFF').on("click", function(){
			
			window.open('https://usastaffing.gov/staffing/vacancy/edit/' + vinnum + '','_blank');
		});*/
		
		$("[id^=vacancy_repeat" + index + "V_USASTAFF]").on('click', function(event){ 
			var id = $(this).attr("id");

			 if(id.indexOf("_container") == -1){
				var num = id.replace(/[^0-9]/g,"");
				window.open('https://usastaffing.gov/staffing/vacancy/edit/' + vinnum[num] + '','_blank');
				//alert(vinnum[num]);
			}

		});
		var vAoc = $('#vacancy_repeat' + index + 'V_AOC').val();
		/* comment out
		if (vAoc.indexOf('All sources') > 0 || vAoc.indexOf('DE only') > 0){
			$('#vacancy_repeat' + index + 'L_AC3').addClass('hidden');
		}else{
			$('#vacancy_repeat' + index + 'L_AC1').addClass('hidden');
			$('#vacancy_repeat' + index + 'L_AC2').addClass('hidden');
		}
		*/
			/*
			$('#vacancy_repeat' + index + 'V_AOC').on("change", function(){
				var comSelVal = $(this).children("option:selected").val();

				if (comSelVal == 'All sources' || comSelVal == 'DE only') {

					$('#vacancy_repeat' + index + 'L_AC1').removeClass('hidden');
					$('#vacancy_repeat' + index + 'L_AC2').removeClass('hidden');
					$('#vacancy_repeat' + index + 'L_AC3').addClass('hidden');

				}else{

					$('#vacancy_repeat' + index + 'L_AC1').addClass('hidden');
					$('#vacancy_repeat' + index + 'L_AC2').addClass('hidden');
					$('#vacancy_repeat' + index + 'L_AC3').removeClass('hidden');
					//$('#MISSING_DOCS_EMAIL_SENT_DATE').val('');
				}
			});
			*/

			WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_NPA');
			$('#vacancy_repeat' + index + 'V_NPA').css('background-color', '#efefef'); 
        	
        	$('#vacancy_repeat' + index + 'V_AOC').val($('#vacancy_repeat' + index + 'V_AOC').val().replace(/;/gi, '; '));
        
			WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_AOC');
			$('#vacancy_repeat' + index + 'V_AOC').css('background-color', '#efefef'); 
        	WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_MP');
			$('#vacancy_repeat' + index + 'V_MP').css('background-color', '#efefef'); 
		
		
			//$('#vacancy_repeat' + index + 'V_CRC').attr('_type', 'text');
			//$('#vacancy_repeat' + index + 'V_SPFC').attr('_type', 'text');
		
		$('#vacancy_repeat' + index + 'TITLE_container').addClass('hidden');
		$('#vacancy_repeat' + index + 'PAYPLAN_container').addClass('hidden');
		$('#vacancy_repeat' + index + 'SERISE_container').addClass('hidden');
		$('#vacancy_repeat' + index + 'GRADE_container').addClass('hidden');
		$('#vacancy_repeat' + index + 'PLEVEL_container').addClass('hidden');
		$('#vacancy_repeat' + index + 'LOCATION_container').addClass('hidden');
		
        $('#vacancy_repeat' + index + 'V_AT').val(addComma3($('#vacancy_repeat' + index + 'V_AT').val()));
        
		//To do loop   $('#vacancy_repeat' + index + 'record_repeat_2' + pindex + 'record_group_2_headings').addClass('hidden');
		//$('#vacancy_repeat' + index + 'record_repeat_21record_group_2_headings').addClass('hidden');
		/*for (var pindex = 1; pindex <= pcnt; pindex++) {
			$('#vacancy_repeat' + index + 'record_repeat_2' + pindex + 'record_group_2_headings').addClass('hidden');
		}*/

				  WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_VIN');
				  $('#vacancy_repeat' + index + 'V_VIN').css('background-color', '#efefef'); 

				  WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_VAN');
				  $('#vacancy_repeat' + index + 'V_VAN').css('background-color', '#efefef'); 

				  WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_AT');
				  $('#vacancy_repeat' + index + 'V_AT').css('background-color', '#efefef'); 

				  WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_DAP');
				  $('#vacancy_repeat' + index + 'V_DAP').css('background-color', '#efefef');  
				  $('#vacancy_repeat' + index + 'V_DAP_calendar_anchor').addClass('hidden');

				  WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_DAO');
				  $('#vacancy_repeat' + index + 'V_DAO').css('background-color', '#efefef');                    		
				  $('#vacancy_repeat' + index + 'V_DAO_calendar_anchor').addClass('hidden');
		
				  WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_DACL');
				  $('#vacancy_repeat' + index + 'V_DACL').css('background-color', '#efefef');
				  $('#vacancy_repeat' + index + 'V_DACL_calendar_anchor').addClass('hidden');

				  WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_DACA');
				  $('#vacancy_repeat' + index + 'V_DACA').css('background-color', '#efefef');
				  $('#vacancy_repeat' + index + 'V_DACA_calendar_anchor').addClass('hidden');
        
        if(actName != 'DE IR Audits Case' && actName != 'DEU Reviews/ Approves/Creates Vacancy/Cert'){
            WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_CRC');
			$('#vacancy_repeat' + index + 'V_CRC').css('background-color', '#efefef'); 
            
            WHRSCMain.setAlwaysReadonly('vacancy_repeat' + index + 'V_SPFC');
			$('#vacancy_repeat' + index + 'V_SPFC').css('background-color', '#efefef'); 
        }
		
			/* comment out 
			if ($('#vacancy_repeat' + index + 'V_AT').val() == 'DE'){
				
				
			}else{
			  
				//$('#vacancy_repeat' + index + 'L_AT1').addClass('hidden');
			}
			*/


		   /* $('#vacancy_repeat' + index + 'V_AT').on("change", function(){
				var comSelVal = $(this).children("option:selected").val();

				if (comSelVal == 'DE') {

					$('#vacancy_repeat' + index + 'L_AT1').removeClass('hidden');

				}else{

					$('#vacancy_repeat' + index + 'L_AT1').addClass('hidden');
					//$('#MISSING_DOCS_EMAIL_SENT_DATE').val('');
				}
			});*/


   }
    
    
}

function addComma3(fieldval){
    fieldval = fieldval.replace(/\./g,'');
	var chstr = fieldval.split('');
    var ctext = '';
        
    for ( var i in chstr ) {
     ctext += chstr[i] + '.';
    }
    
    return ctext;
}