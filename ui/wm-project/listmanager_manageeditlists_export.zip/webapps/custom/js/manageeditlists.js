var popupWindow = null;

$(function(){
  $('#EDIT_LIST_BTN_label_container,#EDIT_LIST_BTN_2_label_container').attr({ style:'border-left:0px' });

  var listRecordCount_priority1 = $('#h_recordCount').val();
  var listRecordCount_priority2 = $('#h_recordCount_2').val();

  for (var i = 1; i <= listRecordCount_priority1; i++) {
    buttonEvent_priority1(i);
  }
  for (var i = 1; i <= listRecordCount_priority2; i++) {
    buttonEvent_priority2(i);
  }

  $(':root').on({
    hover: function(){
        disableParent();
    },
    click: function(){
        disableParent();
    }
  });
  var disableParent = function(){
    if(popupWindow && !popupWindow.closed) {
      popupWindow.focus();
    } else {
      utility.greyOutScreen(false);
    }
  }

});

var popOption = "width=1350, height=600, top=190, left=120, resizable=0, scrollbars=yes, status=no";
var list_id = null;
var url = null;

var buttonEvent_priority1 = function(i){
  $('#BasicTable' + i + 'VIEW_LIST_BTN').on('click',function() {
    list_id = $('#BasicTable' + i + 'h_listId').val();
    url = "../listmanager_managelist/bizflowEntry.do?view_list_id="+list_id;
    popupWindow = window.open(url,"",popOption);
    //$(":root").fadeTo(500, 0.2);
    utility.greyOutScreen(true);
  });

  $('#BasicTable' + i + 'EDIT_LIST_BTN').on('click',function() {
    list_id = $('#BasicTable' + i + 'h_listId').val();
    url = "../listmanager_managelist/bizflowEntry.do?update_list_id="+list_id;
    popupWindow = window.open(url,"",popOption);
    //$(":root").fadeTo(500, 0.2);
    utility.greyOutScreen(true);
  });
}

var buttonEvent_priority2 = function(i){
  $('#BasicTable_2' + i + 'VIEW_LIST_BTN_2').on('click',function() {
    list_id = $('#BasicTable_2' + i + 'h_listId_2').val();
    url = "../listmanager_managelist/bizflowEntry.do?view_list_id="+list_id;
    popupWindow = window.open(url,"",popOption);
    //$(":root").fadeTo(500, 0.2);
    utility.greyOutScreen(true);
  });

  $('#BasicTable_2' + i + 'EDIT_LIST_BTN_2').on('click',function() {
    list_id = $('#BasicTable_2' + i + 'h_listId_2').val();
    url = "../listmanager_managelist/bizflowEntry.do?update_list_id="+list_id;
    popupWindow = window.open(url,"",popOption);
    //$(":root").fadeTo(500, 0.2);
    utility.greyOutScreen(true);
  });
}
