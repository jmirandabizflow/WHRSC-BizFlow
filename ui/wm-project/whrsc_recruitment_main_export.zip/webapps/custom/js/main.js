var WHRSCMain = {

	_USAS_DATA: null,

	_CMS_allUserGroups: null,

	_CMS_myUserGroups: null,

	

	actList: [{
		name: "HR Specialist Announces Job/Issues Cert/Selection Rec'd",
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3','tab4','tab5'],
		readonly: []
	},
	{
		name: "DEU Reviews/ Approves/Creates Vacancy/Cert",
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3','tab4','tab5'],
		readonly: []
	},
	{
		name: "DE IR Audits Case",
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3','tab4','tab5'],
		readonly: []
	}
		],

	tabList: [{
		id: 'tab1',
		targetUrl: '/whrsc_recruitment/recruitment_transaction.do', 
		targetGroup: 'partial_tab1',
		name: 'Transaction Information',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {
			$('#TransactionInfo_ActionStatus').on("change", function() {
                WHRSCMain.resetActionStatus();
            });
            WHRSCMain.resetActionStatus();
			$('#TransactionInfo_DateRecv').on("change", function() {
                WHRSCMain.resetDateReceived();
            });
            WHRSCMain.resetDateReceived();
        },
		enableHandler: null
	}
		, {
		id: 'tab2',
		targetUrl: '/whrsc_recruitment/recruitment_prerecruitment.do',
		targetGroup: 'partial_tab2',
		name: 'Pre-recruitment Information',
			loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {
			$('#JOB_OPENING_ID').on("change", function() {
                WHRSCMain.resetRequisitionNumber();
            });
			WHRSCMain.resetRequisitionNumber();
			
		},
		enableHandler: null
	}
	
		, {
		id: 'tab3',
		targetUrl: '/whrsc_recruitment/recruitment_vacancy.do', 
		targetGroup: 'partial_tab3',
		name: 'Vacancy Announcement Information',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {

		},
		enableHandler: null
	}

 	, {
		id: 'tab4',
		targetUrl: '/whrsc_recruitment/recruitment_applicant.do', 
		targetGroup: 'partial_tab4',
		name: 'Applicant Information',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {

		},
		enableHandler: null
	}		
	, {
		id: 'tab5',
		targetUrl: '/whrsc_recruitment/recruitment_certificate.do',
		targetGroup: 'partial_tab5',
		name: 'Certificate Information',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {

		},
		enableHandler: null
	}	],

	activityOption: null,

	tabManager: null,

	removeSizeLabel: function(element) {
		var target = null;
		var nodeName = $(element).get(0).tagName;
		if (nodeName == 'input') {
			if ($(element).hasClass('dijitInputInner')) {
				target = $(element).parent().parent().parent();
			} else {
				target = $(element).parent().parent();
			}
		} else if (nodeName == 'textarea') {
			target = $(element).parent();
		}

		if (target != null && target.length > 0) {
			$(target).find('p.sizeLabel').remove();
		}
	},
	// The element with alwaysDisabled/alwaysReadonly attribute will be submitted to the webserver.
	// But, when the form is enabled, element will not be enabled.
	setAlwaysDisabled: function(elementID) {
		var element = $('#' + elementID);
		var selectorKey = '#' + elementID;
		$(element).attr('disabled','disabled');
		$(element).attr('alwaysDisabled','true');

		WHRSCMain.removeSizeLabel(element);
	},
	setAlwaysReadonly: function(elementID) {
		var element = $('#' + elementID);
		$(element).prop('readonly','true');
		$(element).attr('alwaysReadonly','true');

		WHRSCMain.removeSizeLabel(element);
	},

	getUserGroupMemberID: function(userGroupName) {
		var userGroupMemberID = '';
		if (userGroupName == null || userGroupName.length == 0) {
			utility.debugLog('WHRSCMain - getUserGroupMemberID() - userGroupName is null or empty');
		}
		if (WHRSCMain._CMS_allUserGroups == null) {
			var rawAllUserGroupData = $('#h_cms_usergroupString').val();
			if (rawAllUserGroupData != null && rawAllUserGroupData.length > 0) {
				$('#h_cms_usergroupString').val('');
				var x2js = new X2JS();
				WHRSCMain._CMS_allUserGroups = x2js.xml_str2json(rawAllUserGroupData);
				x2js = null;
			} else {
				WHRSCMain._CMS_allUserGroups = {UserGroups: {}};
			}
			utility.debugLog('WHRSCMain - getUserGroupMemberID() - Usergroup information is initialized.');
		}

		if (WHRSCMain._CMS_allUserGroups != null
				&& WHRSCMain._CMS_allUserGroups.cms_usergroup != null
				&& WHRSCMain._CMS_allUserGroups.cms_usergroup.record != null) {
			var foundGroups = WHRSCMain._CMS_allUserGroups.cms_usergroup.record.filter(function(node, index) {
				return node.NAME == userGroupName
			});
			if (foundGroups.length > 0) {
				userGroupMemberID = foundGroups[0].MEMBERID;
			}
		}
		return userGroupMemberID;
	},


	// Action Status on Transaction Tab
	resetActionStatus: function() {

		var actionStatusLabel = $('#TransactionInfo_ActionStatus option:selected').text();
		var actionStatusValue = $('#TransactionInfo_ActionStatus option:selected').val();
		if (actionStatusValue != '') {
			$('#actionStatus').text(actionStatusLabel);
		} else {
			$('#actionStatus').text('');
		}
		this.tabManager.resetTabs();
	},
		// Action Status on Transaction Tab
	resetDateReceived: function() {
		var dateReceived = $('#TransactionInfo_DateRecv').val();
		if (dateReceived != '') {
			$('#dateReceived').text(dateReceived);
		} else {
			$('#dateReceived').text('');
		}
		this.tabManager.resetTabs();
	},
	
	resetRequisitionNumber: function() {
		var reqNumber = $('#JOB_OPENING_ID').val();
		if (reqNumber != '') {
			$('#requsitionNumber').text(reqNumber);
		} else {
			$('#requsitionNumber').text('');
		}
		this.tabManager.resetTabs();
		
	},

	_currentUserGroupData: null,

	getCurrentUserGroupData: function() {
		if (WHRSCMain._currentUserGroupData == null) {
			WHRSCMain._currentUserGroupData = $('#h_userGroups').val();
			if (WHRSCMain._currentUserGroupData == null || WHRSCMain._currentUserGroupData.length == 0) {
				utility.debugLog('WHRSCMain - getCurrentUserGroupData() - ActivityName is null or empty.');
			} else {
				$('#h_userGroups').val('');
			}
		}
		return WHRSCMain._currentUserGroupData;
	},
	_initUserGroupData: function() {
		var rawMyUserGroups = WHRSCMain.getCurrentUserGroupData();
		if (rawMyUserGroups != null && rawMyUserGroups.length > 0) {
			var x2js = new X2JS();
			WHRSCMain._CMS_myUserGroups = x2js.xml_str2json(rawMyUserGroups);
			x2js = null;
		} else {
			WHRSCMain._CMS_myUserGroups = {UserGroups: {}};
		}
	},
	isCurrentUserMemberOf: function(userGroupName) {
		if (userGroupName == null || userGroupName.length == 0) {
			utility.debugLog('WHRSCMain - isCurrentUserMemberOf() - userGroupName is null or empty');
		}
		if (WHRSCMain._CMS_myUserGroups == null) {
			WHRSCMain._initUserGroupData();
		}

		if (WHRSCMain._CMS_myUserGroups != null
				&& WHRSCMain._CMS_myUserGroups.UserGroups != null
				&& WHRSCMain._CMS_myUserGroups.UserGroups.UserGroup != null) {
			var foundGroups = WHRSCMain._CMS_myUserGroups.UserGroups.UserGroup.filter(function(node, index) {
				return node.Name == userGroupName
			});
			return foundGroups.length > 0;
		} else {
			return false;
		}
	},

	enableForModification: function() {
		var tabs = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5'];
		tabs.forEach(function(tab) {
			this.tabManager.enableTab(tab);
			WHRSCMain.initMaxSizePerTab(tab);
		})

		var activityName = this.activityOption.getActivityName();
		var option = this.activityOption.getCurrentActivityOption(activityName);
		option.readonly = [];

		//TODO: adjust ELIGQUAL form specific elements
		hyf.util.enableComponent('button_apscm_return_2');
		utility.disableComponents(['IS_SO_ACK','IS_HR_CLS_SPC_APR','IS_HR_STF_SPC_APR','btnCancelWorkitem'])
	},
	popupModifyRequest: function() {
		bootbox.dialog({
			message: 'Are you sure you want to modify worksheet?',
			onEscape: true,
			buttons: [{
				label: 'Yes',
				className: 'btn-success',
				callback: WHRSCMain.enableForModification
			}, {
				label: 'No',
				className: 'btn-danger'
			}]
		});
	},
	popupCancellation: function() {
		var isUserSO = WHRSCMain.isCurrentUserMemberOf('Selecting Officials');
		var isUserLiaison = WHRSCMain.isCurrentUserMemberOf('HR Liaison');
		var isXO = WHRSCMain.isCurrentUserMemberOf('Executive Officers');
		var isClassificationSpecialist = WHRSCMain.isCurrentUserMemberOf('HR Classification Specialists');
		var isStaffingSpecialist = WHRSCMain.isCurrentUserMemberOf('HR Staffing Specialists');

		var reasons = [];

		if (isUserSO == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[Selecting Officials]/CancellationReason');
		} else if (isUserLiaison == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[HR Liaison]/CancellationReason');
		} else if (isXO == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[Executive Officers]/CancellationReason');
		} else if (isClassificationSpecialist == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[HR Classification Specialists]/CancellationReason');
		} else if (isStaffingSpecialist == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[HR Staffing Specialists]/CancellationReason');
		} else {
			reasons = LookupManager.findByLTYPE('UserGroup[Default]/CancellationReason');
		}

		var options = '<option value>Select one</option>';
		reasons.forEach(function(reason) {
			options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
		});

		var dialog = bootbox.dialog({
			title: 'Reason for Cancellation',
			message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
			onEscape: true,
			buttons: {
				confirm: {
					label: 'OK',
					className: 'btn-success',
					callback: function() {
						var message = $('div.bootbox select option:selected').text();
						if (message == null || message.length == 0) {
							return false;
						}

						setTimeout(function() {
							utility.greyOutScreen(true);
							this.tabManager.enableTabsForSubmission();
							$('#WIH_complete_requested').val('true');
							$('#pv_requestStatus').val('Request Cancelled');
							$('#pv_requestStatusDate').val(utility.getNowUTCString());
							$('#pv_CancelReason').val(message);
							utility.submitFormPage('btnCancelWorkitem', 'saveNewForm');
						}, 0);
					}
				},
				cancel: {
					label: 'Cancel',
					className: 'btn-danger'
				}
			}
		});

		$('div.bootbox button.btn-success').prop('disabled', true);

		$('div.bootbox select').on('change keyup', function() {
			var message = $('div.bootbox select option:selected').val();
			if (message == '') {
				$('div.bootbox button.btn-success').prop('disabled', true);
			} else {
				$('div.bootbox button.btn-success').prop('disabled', false);
			}
		});
	},
	showAlertMessage: function(message) {
		var dialog = bootbox.dialog({
			title: 'Requested Changes',
			message: '<textarea disabled rows="5" class="bootbox-input bootbox-input-text form-control">' + message + '</textarea>',
			onEscape: true,
			buttons: {
				confirm: {
					label: 'OK',
					className: 'btn-success',
				}
			}
		});
	},
	validateTabCustomCallback: function(tabId){
		var result = true;
		if (result == true && tabId == 'tab2'){
			result = validateEligQualPosCustom();
		}
		return result;
	},

	//
	//
	// Form Initialization function
	// This function will be called when the mainform is loaded.
	init: function() {
		var requestNumber = $('#pvGetRequestNumber').val();
		var usasPath = $('#pv_usasPath').val();
		var usasUrl = usasPath + '/recruitment/' + requestNumber;
		if (requestNumber != '') {
			$.ajax({
				//url: '/usasrwsc/usas/reportXML/recruitment/'+ requestNumber,   //+ requestNumber, //070707',
				url: usasUrl,   
				dataType: 'text',
				cache: false,
				async: false,
				success: function (resultObj){					
					if(resultObj=='' || resultObj==null) {
						alert("An exception occurred. Please check the logs.");
						WHRSCMain._USAS_DATA = null;
					}
					else {					
						var indx = resultObj.indexOf('>');
						resultObj = resultObj.substring(indx+1);
						var x2js = new X2JS();
						var getRestDataXML =  x2js.xml_str2json(resultObj);
						
						var resultCode = getRestDataXML.USAStaffing_Recruitment.Result_Code;
						if(resultCode!='Success') {
							alert(getRestDataXML.USAStaffing_Recruitment.Failure_Message);
							
							WHRSCMain._USAS_DATA = '<USAStaffing_Recruitment  xmlns=""><Vacancies><record><Number_Of_Positions_Advertised /><Area_Of_Consideration /><Interdisciplinary_Position /><Vacancy_Identification_Number /><Vacancy_Announcement_Number /><Announcement_Type /><Date_Announcement_Posted /><Date_Announcement_Opened /><Date_Announcement_Closed /><Date_Announcement_Cancelled/><Positions><record><Position_Title /><Pay_Plan /><Series /><Grade /><Full_Performance_Level /><Duty_Location /></record></Positions><Applicants><Vacancy_Identification_Number /><Announcement_Number /><Total_Number_Of_Applicants /><Total_Number_Of_Eligible_Applicants /><Total_Number_Of_Unique_Referred_Applicants /><Date_Applicants_Notified_Eligibility_Status /><Date_Applicants_Notified_Referral_Status /></Applicants><Certificates><record><Announcement_Number /><Certificate_Type /><Certificate_Number /><Position_Title /><Series /><Grade /><Duty_Location /><Date_Certificate_Issued /><Date_Certificate_Sent_To_SO /><Selection_Made /><Action_Taken /><Date_Hiring_Decision_Received_In_HR /><Date_Final_Applicant_Statuses_Set /><Date_Audit_Completed /></record></Certificates></record></Vacancies><Positions><Number_Of_Positions_To_Be_Advertised /><Clearance_Level_Required_For_Position /><record><Position_Title /><Pay_Plan /><Series /><Grade /><Full_Performance_Level /><Duty_Location /></record></Positions><Result_Code /><Failure_Message /></USAStaffing_Recruitment>';
						}
						else {
							var vacancyCount = getRestDataXML.USAStaffing_Recruitment._VacancyCount;
							if (vacancyCount=='0') {
								alert('Missing Vacancy Information. Please review the USAStaffing for the Vacancy Information and update as necessary. You can then return to EWITS 2.0 to continue processing the action.');
								WHRSCMain._USAS_DATA = '<USAStaffing_Recruitment  xmlns=""><Vacancies><record><Number_Of_Positions_Advertised /><Area_Of_Consideration /><Interdisciplinary_Position /><Vacancy_Identification_Number /><Vacancy_Announcement_Number /><Announcement_Type /><Date_Announcement_Posted /><Date_Announcement_Opened /><Date_Announcement_Closed /><Date_Announcement_Cancelled/><Positions><record><Position_Title /><Pay_Plan /><Series /><Grade /><Full_Performance_Level /><Duty_Location /></record></Positions><Applicants><Vacancy_Identification_Number /><Announcement_Number /><Total_Number_Of_Applicants /><Total_Number_Of_Eligible_Applicants /><Total_Number_Of_Unique_Referred_Applicants /><Date_Applicants_Notified_Eligibility_Status /><Date_Applicants_Notified_Referral_Status /></Applicants><Certificates><record><Announcement_Number /><Certificate_Type /><Certificate_Number /><Position_Title /><Series /><Grade /><Duty_Location /><Date_Certificate_Issued /><Date_Certificate_Sent_To_SO /><Selection_Made /><Action_Taken /><Date_Hiring_Decision_Received_In_HR /><Date_Final_Applicant_Statuses_Set /><Date_Audit_Completed /></record></Certificates></record></Vacancies><Positions><Number_Of_Positions_To_Be_Advertised /><Clearance_Level_Required_For_Position /><record><Position_Title /><Pay_Plan /><Series /><Grade /><Full_Performance_Level /><Duty_Location /></record></Positions><Result_Code /><Failure_Message /></USAStaffing_Recruitment>';
							}
							else if(vacancyCount=='1') {
								if(getRestDataXML.USAStaffing_Recruitment.Vacancies.record.Applicants==undefined){
									alert('Missing Applicant data. Please review the USAStaffing for the Applicant data and update as necessary. You can then return to EWITS 2.0 to continue processing the action.');
									WHRSCMain._USAS_DATA = resultObj;
								}
								else {
									WHRSCMain._USAS_DATA = resultObj;
								}
							}
							else 
							{
								WHRSCMain._USAS_DATA = resultObj;
								
							}
							
						}				
					}
				}
			});

		} else {
			WHRSCMain._USAS_DATA = '<USAStaffing_Recruitment  xmlns=""><Vacancies><record><Number_Of_Positions_Advertised /><Area_Of_Consideration /><Interdisciplinary_Position /><Vacancy_Identification_Number /><Vacancy_Announcement_Number /><Announcement_Type /><Date_Announcement_Posted /><Date_Announcement_Opened /><Date_Announcement_Closed /><Date_Announcement_Cancelled/><Positions><record><Position_Title /><Pay_Plan /><Series /><Grade /><Full_Performance_Level /><Duty_Location /></record></Positions><Applicants><Vacancy_Identification_Number /><Announcement_Number /><Total_Number_Of_Applicants /><Total_Number_Of_Eligible_Applicants /><Total_Number_Of_Unique_Referred_Applicants /><Date_Applicants_Notified_Eligibility_Status /><Date_Applicants_Notified_Referral_Status /></Applicants><Certificates><record><Announcement_Number /><Certificate_Type /><Certificate_Number /><Position_Title /><Series /><Grade /><Duty_Location /><Date_Certificate_Issued /><Date_Certificate_Sent_To_SO /><Selection_Made /><Action_Taken /><Date_Hiring_Decision_Received_In_HR /><Date_Final_Applicant_Statuses_Set /><Date_Audit_Completed /></record></Certificates></record></Vacancies><Positions><Number_Of_Positions_To_Be_Advertised /><Clearance_Level_Required_For_Position /><record><Position_Title /><Pay_Plan /><Series /><Grade /><Full_Performance_Level /><Duty_Location /></record></Positions><Result_Code /><Failure_Message /></USAStaffing_Recruitment>';
		}
		
		// instantiate dependent objects
		this.activityOption = new BFActivityOption(this.actList, $('#h_activityName').val());
		this.tabManager = new TabManager(this.tabList, this.activityOption, 'tab5', 'WHRSCMain', this.validateTabCustomCallback);

		// Following should be called to reduce redundant network traffic.
		WHRSCMain.getCurrentUserGroupData();
		
		if (isReadOnly() == true) {
			var activityName = this.activityOption.getActivityName();
			var curActivityOption = this.activityOption.getCurrentActivityOption(activityName);
			curActivityOption.readonly = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5'];
		}

		LookupManager.init();
		this.tabManager.installCustomTabChanger();

		//this.tabManager.initTab(WHRSCMain.tabList);

		this.tabManager.initTab(WHRSCMain.tabList, WHRSCMain._USAS_DATA);



		// set focus on the current tab
		$('a.selectedTab').focus();

	}
}

var _readOnly = null;
function isReadOnly() {
	if (_readOnly == null) {
		_readOnly = $('#h_readOnly').val();
		if (_readOnly == 'y') {
			_readOnly = true;
		} else {
			_readOnly = false;
		}
	}
	return _readOnly;
}

function checkMandatory() {
	var alertMassage = "You must specify a value for the following for the field(s)";
	var ret = true;


	 var responseName = getSelectedResponse();
	 if(responseName=="Send Pkg rec'd Email") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}if($('#h_email').val()==''){  
			alertMassage = alertMassage + "\n HR Liasion";
			ret = false;
		}		
		if($('#o_email').val()==''){
			alertMassage = alertMassage + "\n Selecting Official";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}

		if($('#s_email').val()==''){
			alertMassage = alertMassage + "\n Supervisor";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){    
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;
		}
	 }
	else if(responseName=="Send Rev/App Email") {  
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}if($('#h_email').val()==''){  
			alertMassage = alertMassage + "\n HR Liasion";
			ret = false;
		}		
		if($('#o_email').val()==''){
			alertMassage = alertMassage + "\n Selecting Official";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#s_email').val()==''){
			alertMassage = alertMassage + "\n Supervisor";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		
		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;
		}
	}
	  else if(responseName=="Send Package Incomplete Email") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		if($('#h_email').val()==''){  
			alertMassage = alertMassage + "\n HR Liasion";
			ret = false;
		}		
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if ($('#MISSING_DOCS').val()=='') 	{			
			alertMassage = alertMassage + "\n List of Missing Docs/Info";
			ret = false;
		}
		if($('#PCKG_COMPLETE option:selected').val() =='Yes') {
			alertMassage = alertMassage + "\n The package complete must be 'NO'";
			ret = false;
		}

		if(ret ==false){alert(alertMassage); return false;}
		else {
			if($('#MISSING_DOCS_EMAIL_SENT_DATE').val()=='') {
				var now = new Date();
				var sysDate = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, now);
				$('#MISSING_DOCS_EMAIL_SENT_DATE').val(sysDate);                                     
			}
			return ret;
		}

    }
	else if(responseName=="Send to DEU (Ann Apvl)") {
		//all tabs except certificate tab
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}

		//Transaction tab
		if($('#h_lastname').val()==''){ 
			alertMassage = alertMassage + "\n HR Liasion Last Name";
			ret = false;
		}
		if($('#TransactionInfo_GR').val()==''){ 
			alertMassage = alertMassage + "\n SSB Recruitment";
			ret = false;
		}
		if($('#TransactionInfo_DateRecv').val()==''){ 
			alertMassage = alertMassage + "\n Date Recv'd in HR";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){ 
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#TransactionInfo_PED').val()==''){ 
			alertMassage = alertMassage + "\n Proposed Effective Date";
			ret = false;
		}
		if($('#TransactionInfo_BC').val()==''){ 
			alertMassage = alertMassage + "\n Branch Chief";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){ 
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){ 
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_HA').val()==''){ 
			alertMassage = alertMassage + "\n HR Assistant";
			ret = false;
		}
		if($('#TransactionInfo_FA').val()==''){ 
			alertMassage = alertMassage + "\n Final Authorizer";
			ret = false;
		}
		if($('#PCKG_COMPLETE').val()==''){ 
			alertMassage = alertMassage + "\n Is the package complete";
			ret = false;
		}
		if($('#TransactionInfo_Priority').val()==''){ 
			alertMassage = alertMassage + "\n Priority";
			ret = false;
		}
		if($('#TransactionInfo_ASC').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Code";
			ret = false;
		}
		if($('#TransactionInfo_ActionStatus').val()==''){ 
			alertMassage = alertMassage + "\n Action Status";
			ret = false;
		}
		if($('#TransactionInfo_ASD').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Description";
			ret = false;
		}

		//Pre-Recruitment tab
		if($('#LEGISLATIVE_INIT_SUPPORTED').val()==''){ 
			alertMassage = alertMassage + "\n Legislative Initiative Supported";
			ret = false;
		}
		if($('#NUM_POSITIONS_TO_BE_ADV').val()==''){ 
			alertMassage = alertMassage + "\n Number of Positions Advertised";
			ret = false;
		}
		if($('#IS_READVERTISEMENT').val()==''){ 
			alertMassage = alertMassage + "\n Is this a Re-Advertisement";
			ret = false;
		}
		if($('#HR_CARDS_PD_USED').val()==''){ 
			alertMassage = alertMassage + "\n Recruitment Document Repository Used";
			ret = false;
		}
		if($('#IS_TRANSITIONAL_RECRUIT').val()==''){ 
			alertMassage = alertMassage + "\n Transitional Recruitment";
			ret = false;
		}
		if($('#OTHER_RECRUIT_CONSIDERATIONS').val()==''){ 
			alertMassage = alertMassage + "\n Other Recruitment Considerations";
			ret = false;
		}
		if($('#CLEARANCE_LEVEL_REQUIRED').val()==''){ 
			alertMassage = alertMassage + "\n Clearance Level Required for Position";
			ret = false;
		}
		if($('#PAID_AD').val()==''){ 
			alertMassage = alertMassage + "\n Paid Ad";
			ret = false;
		}
		if($('#IS_RELOCATION_EXPENSES_PAID').val()==''){ 
			alertMassage = alertMassage + "\n Will Relocation Expenses Be Paid";
			ret = false;
		}
		if ($("input[type=checkbox][name=INCENTIVES_OFFERED_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Incentives Offered";
			ret = false;
		}
		if ($("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Additional Recruitment Channels";
			ret = false;
		}
		
		//Applicant tab
		var cnt = $('#h_applicant_count').val();
		if(cnt >0) {
			for (var index = 1; index <= cnt; index++) {
				if($("#record_repeat" + index + "A_EM").val() =="") {
					alertMassage = alertMassage + "\n Evaluation Method";
					ret = false; 
				}
				if ($("input[type=checkbox][name=record_repeat" + index + "A_R_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
					alertMassage = alertMassage + "\n Rater";
					ret = false; 
				}
			}
		}

		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			var cnt = $('#h_vacancy_count').val();
			for (var index = 1; index <= cnt; index++) {
				if ($('#vacancy_repeat' + index + 'V_AT').val() == 'DE') {
					var now = new Date();
					var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
					$('#DATE_SENT_TO_DEU').val(sysDate);			
				}
			}
			var now2 = new Date();
			var sysDate2= utility.getDateString({isUTC: true, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now2);
			$('#pv_dateSentDeu').val(sysDate2);	
			$('#pv_deStatus').val('DEU Active');

			$('#h_rybCode').val('Red');
			$('#h_rybStatus').val('Pending');
			$('#h_rybDesc').val('Under Review - DE');
			$('#h_updateRyb').val('true');

			
			return ret;
		}
		
	}
	else if(responseName=="Send to DEU (Cert Prep)") {
		//all tabs
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		//Transaction tab
		if($('#h_lastname').val()==''){ 
			alertMassage = alertMassage + "\n HR Liasion Last Name";
			ret = false;
		}
		if($('#TransactionInfo_GR').val()==''){ 
			alertMassage = alertMassage + "\n SSB Recruitment";
			ret = false;
		}
		if($('#TransactionInfo_DateRecv').val()==''){ 
			alertMassage = alertMassage + "\n Date Recv'd in HR";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){ 
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#TransactionInfo_PED').val()==''){ 
			alertMassage = alertMassage + "\n Proposed Effective Date";
			ret = false;
		}
		if($('#TransactionInfo_BC').val()==''){ 
			alertMassage = alertMassage + "\n Branch Chief";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){ 
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){ 
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_HA').val()==''){ 
			alertMassage = alertMassage + "\n HR Assistant";
			ret = false;
		}
		if($('#TransactionInfo_FA').val()==''){ 
			alertMassage = alertMassage + "\n Final Authorizer";
			ret = false;
		}
		if($('#PCKG_COMPLETE').val()==''){ 
			alertMassage = alertMassage + "\n Is the package complete";
			ret = false;
		}
		if($('#TransactionInfo_Priority').val()==''){ 
			alertMassage = alertMassage + "\n Priority";
			ret = false;
		}
		if($('#TransactionInfo_ASC').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Code";
			ret = false;
		}
		if($('#TransactionInfo_ActionStatus').val()==''){ 
			alertMassage = alertMassage + "\n Action Status";
			ret = false;
		}
		if($('#TransactionInfo_ASD').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Description";
			ret = false;
		}

		//Pre-Recruitment tab
		if($('#LEGISLATIVE_INIT_SUPPORTED').val()==''){ 
			alertMassage = alertMassage + "\n Legislative Initiative Supported";
			ret = false;
		}
		if($('#NUM_POSITIONS_TO_BE_ADV').val()==''){ 
			alertMassage = alertMassage + "\n Number of Positions Advertised";
			ret = false;
		}
		if($('#IS_READVERTISEMENT').val()==''){ 
			alertMassage = alertMassage + "\n Is this a Re-Advertisement";
			ret = false;
		}
		if($('#HR_CARDS_PD_USED').val()==''){ 
			alertMassage = alertMassage + "\n Recruitment Document Repository Used";
			ret = false;
		}
		if($('#IS_TRANSITIONAL_RECRUIT').val()==''){ 
			alertMassage = alertMassage + "\n Transitional Recruitment";
			ret = false;
		}
		if($('#OTHER_RECRUIT_CONSIDERATIONS').val()==''){ 
			alertMassage = alertMassage + "\n Other Recruitment Considerations";
			ret = false;
		}
		if($('#CLEARANCE_LEVEL_REQUIRED').val()==''){ 
			alertMassage = alertMassage + "\n Clearance Level Required for Position";
			ret = false;
		}
		if($('#PAID_AD').val()==''){ 
			alertMassage = alertMassage + "\n Paid Ad";
			ret = false;
		}
		if($('#IS_RELOCATION_EXPENSES_PAID').val()==''){ 
			alertMassage = alertMassage + "\n Will Relocation Expenses Be Paid";
			ret = false;
		}
		if ($("input[type=checkbox][name=INCENTIVES_OFFERED_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Incentives Offered";
			ret = false;
		}
		if ($("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Additional Recruitment Channels";
			ret = false;
		}
		
		//Applicant tab
		var cnt = $('#h_applicant_count').val();
		if(cnt >0) {
			for (var index = 1; index <= cnt; index++) {
				if($("#record_repeat" + index + "A_EM").val() =="") {
					alertMassage = alertMassage + "\n Evaluation Method";
					ret = false; 
				}
				if ($("input[type=checkbox][name=record_repeat" + index + "A_R_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
					alertMassage = alertMassage + "\n Rater";
					ret = false; 
				}
			}
		}

		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#h_updateRyb').val('false');
			return ret;
		}
	}
	else if(responseName=="Send to DEU (Other)") {
		//all tabs
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		//Transaction tab
		if($('#h_lastname').val()==''){ 
			alertMassage = alertMassage + "\n HR Liasion Last Name";
			ret = false;
		}
		if($('#TransactionInfo_GR').val()==''){ 
			alertMassage = alertMassage + "\n SSB Recruitment";
			ret = false;
		}
		if($('#TransactionInfo_DateRecv').val()==''){ 
			alertMassage = alertMassage + "\n Date Recv'd in HR";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){ 
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#TransactionInfo_PED').val()==''){ 
			alertMassage = alertMassage + "\n Proposed Effective Date";
			ret = false;
		}
		if($('#TransactionInfo_BC').val()==''){ 
			alertMassage = alertMassage + "\n Branch Chief";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){ 
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){ 
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_HA').val()==''){ 
			alertMassage = alertMassage + "\n HR Assistant";
			ret = false;
		}
		if($('#TransactionInfo_FA').val()==''){ 
			alertMassage = alertMassage + "\n Final Authorizer";
			ret = false;
		}
		if($('#PCKG_COMPLETE').val()==''){ 
			alertMassage = alertMassage + "\n Is the package complete";
			ret = false;
		}
		if($('#TransactionInfo_Priority').val()==''){ 
			alertMassage = alertMassage + "\n Priority";
			ret = false;
		}
		if($('#TransactionInfo_ASC').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Code";
			ret = false;
		}
		if($('#TransactionInfo_ActionStatus').val()==''){ 
			alertMassage = alertMassage + "\n Action Status";
			ret = false;
		}
		if($('#TransactionInfo_ASD').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Description";
			ret = false;
		}

		//Pre-Recruitment tab
		if($('#LEGISLATIVE_INIT_SUPPORTED').val()==''){ 
			alertMassage = alertMassage + "\n Legislative Initiative Supported";
			ret = false;
		}
		if($('#NUM_POSITIONS_TO_BE_ADV').val()==''){ 
			alertMassage = alertMassage + "\n Number of Positions Advertised";
			ret = false;
		}
		if($('#IS_READVERTISEMENT').val()==''){ 
			alertMassage = alertMassage + "\n Is this a Re-Advertisement";
			ret = false;
		}
		if($('#HR_CARDS_PD_USED').val()==''){ 
			alertMassage = alertMassage + "\n Recruitment Document Repository Used";
			ret = false;
		}
		if($('#IS_TRANSITIONAL_RECRUIT').val()==''){ 
			alertMassage = alertMassage + "\n Transitional Recruitment";
			ret = false;
		}
		if($('#OTHER_RECRUIT_CONSIDERATIONS').val()==''){ 
			alertMassage = alertMassage + "\n Other Recruitment Considerations";
			ret = false;
		}
		if($('#CLEARANCE_LEVEL_REQUIRED').val()==''){ 
			alertMassage = alertMassage + "\n Clearance Level Required for Position";
			ret = false;
		}
		if($('#PAID_AD').val()==''){ 
			alertMassage = alertMassage + "\n Paid Ad";
			ret = false;
		}
		if($('#IS_RELOCATION_EXPENSES_PAID').val()==''){ 
			alertMassage = alertMassage + "\n Will Relocation Expenses Be Paid";
			ret = false;
		}
		if ($("input[type=checkbox][name=INCENTIVES_OFFERED_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Incentives Offered";
			ret = false;
		}
		if ($("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Additional Recruitment Channels";
			ret = false;
		}
		
		//Applicant tab
		var cnt = $('#h_applicant_count').val();
		if(cnt >0) {
			for (var index = 1; index <= cnt; index++) {
				if($("#record_repeat" + index + "A_EM").val() =="") {
					alertMassage = alertMassage + "\n Evaluation Method";
					ret = false; 
				}
				if ($("input[type=checkbox][name=record_repeat" + index + "A_R_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
					alertMassage = alertMassage + "\n Rater";
					ret = false; 
				}
			}
		}

		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;
		}
	}
	else if(responseName=="Forward") {
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;
		}
	}
	else if(responseName=="Initiate Appointment") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;
		}
	}
	else if(responseName=="Pos'n Filled-Other Hiring Mechanism") {
		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#h_status').val('COMPLETED');
			var now = new Date();
			var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
			$('#h_statusDate').val(sysDate);
			$('#h_statusUserID').val($('#h_currentUserID').val());
			
			$('#h_rybCode').val('Blue');
			$('#h_rybStatus').val('Completed');
			$('#h_rybDesc').val('Position Filled by Other Hiring Mechanism');
			$('#h_updateRyb').val('true');

			return ret;
		}

	}
	else if(responseName=="Position Not Filled - Close Action") {
		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#h_status').val('COMPLETED');
			var now = new Date();
			var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
			$('#h_statusDate').val(sysDate);
			$('#h_statusUserID').val($('#h_currentUserID').val());
			
			$('#h_rybCode').val('Blue');
			$('#h_rybStatus').val('Completed');
			$('#h_rybDesc').val('Position Not Filled');
			$('#h_updateRyb').val('true');

			return ret;
		}
	}
	else if(responseName=="No response - Close Action") {
		//if($('#JOB_OPENING_ID').val()==''){
		//	alertMassage = alertMassage + "\n Requisition Number";
		//	ret = false;
		//}
		if($('#h_email').val()==''){  
			alertMassage = alertMassage + "\n HR Liasion";
			ret = false;
		}		
		if($('#o_email').val()==''){
			alertMassage = alertMassage + "\n Selecting Official";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#h_status').val('COMPLETED');
			var now = new Date();
			var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
			$('#h_statusDate').val(sysDate);
			$('#h_statusUserID').val($('#h_currentUserID').val());
			
			$('#h_rybCode').val('Blue');
			$('#h_rybStatus').val('Completed');
			$('#h_rybDesc').val('Completed');
			$('#h_updateRyb').val('true');

			return ret;
		}
	}
	else if(responseName=="Complete Recruitment") {
		//all tabs
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		//Transaction tab
		if($('#h_lastname').val()==''){ 
			alertMassage = alertMassage + "\n HR Liasion Last Name";
			ret = false;
		}
		if($('#TransactionInfo_GR').val()==''){ 
			alertMassage = alertMassage + "\n SSB Recruitment";
			ret = false;
		}
		if($('#TransactionInfo_DateRecv').val()==''){ 
			alertMassage = alertMassage + "\n Date Recv'd in HR";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){ 
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#TransactionInfo_PED').val()==''){ 
			alertMassage = alertMassage + "\n Proposed Effective Date";
			ret = false;
		}
		if($('#TransactionInfo_BC').val()==''){ 
			alertMassage = alertMassage + "\n Branch Chief";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){ 
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){ 
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_HA').val()==''){ 
			alertMassage = alertMassage + "\n HR Assistant";
			ret = false;
		}
		if($('#TransactionInfo_FA').val()==''){ 
			alertMassage = alertMassage + "\n Final Authorizer";
			ret = false;
		}
		if($('#PCKG_COMPLETE').val()==''){ 
			alertMassage = alertMassage + "\n Is the package complete";
			ret = false;
		}
		if($('#TransactionInfo_Priority').val()==''){ 
			alertMassage = alertMassage + "\n Priority";
			ret = false;
		}
		if($('#TransactionInfo_ASC').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Code";
			ret = false;
		}
		if($('#TransactionInfo_ActionStatus').val()==''){ 
			alertMassage = alertMassage + "\n Action Status";
			ret = false;
		}
		if($('#TransactionInfo_ASD').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Description";
			ret = false;
		}

		//Pre-Recruitment tab
		if($('#LEGISLATIVE_INIT_SUPPORTED').val()==''){ 
			alertMassage = alertMassage + "\n Legislative Initiative Supported";
			ret = false;
		}
		if($('#NUM_POSITIONS_TO_BE_ADV').val()==''){ 
			alertMassage = alertMassage + "\n Number of Positions Advertised";
			ret = false;
		}
		if($('#IS_READVERTISEMENT').val()==''){ 
			alertMassage = alertMassage + "\n Is this a Re-Advertisement";
			ret = false;
		}
		if($('#HR_CARDS_PD_USED').val()==''){ 
			alertMassage = alertMassage + "\n Recruitment Document Repository Used";
			ret = false;
		}
		if($('#IS_TRANSITIONAL_RECRUIT').val()==''){ 
			alertMassage = alertMassage + "\n Transitional Recruitment";
			ret = false;
		}
		if($('#OTHER_RECRUIT_CONSIDERATIONS').val()==''){ 
			alertMassage = alertMassage + "\n Other Recruitment Considerations";
			ret = false;
		}
		if($('#CLEARANCE_LEVEL_REQUIRED').val()==''){ 
			alertMassage = alertMassage + "\n Clearance Level Required for Position";
			ret = false;
		}
		if($('#PAID_AD').val()==''){ 
			alertMassage = alertMassage + "\n Paid Ad";
			ret = false;
		}
		if($('#IS_RELOCATION_EXPENSES_PAID').val()==''){ 
			alertMassage = alertMassage + "\n Will Relocation Expenses Be Paid";
			ret = false;
		}
		if ($("input[type=checkbox][name=INCENTIVES_OFFERED_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Incentives Offered";
			ret = false;
		}
		if ($("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Additional Recruitment Channels";
			ret = false;
		}
		
		//Applicant tab
		var cnt = $('#h_applicant_count').val();
		if(cnt >0) {
			for (var index = 1; index <= cnt; index++) {
				if($("#record_repeat" + index + "A_EM").val() =="") {
					alertMassage = alertMassage + "\n Evaluation Method";
					ret = false; 
				}
				if ($("input[type=checkbox][name=record_repeat" + index + "A_R_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
					alertMassage = alertMassage + "\n Rater";
					ret = false; 
				}
			}
		}

		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#h_status').val('COMPLETED');
			var now = new Date();
			var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
			$('#h_statusDate').val(sysDate);
			$('#h_statusUserID').val($('#h_currentUserID').val());
			
			$('#h_rybCode').val('Blue');
			$('#h_rybStatus').val('Completed');
			$('#h_rybDesc').val('Completed');
			$('#h_updateRyb').val('true');

			return ret;
		}
	}
	else if(responseName=="Send for Final Audit (DE)") {
		//all tabs
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
				//Transaction tab
		if($('#h_lastname').val()==''){ 
			alertMassage = alertMassage + "\n HR Liasion Last Name";
			ret = false;
		}
		if($('#TransactionInfo_GR').val()==''){ 
			alertMassage = alertMassage + "\n SSB Recruitment";
			ret = false;
		}
		if($('#TransactionInfo_DateRecv').val()==''){ 
			alertMassage = alertMassage + "\n Date Recv'd in HR";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){ 
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#TransactionInfo_PED').val()==''){ 
			alertMassage = alertMassage + "\n Proposed Effective Date";
			ret = false;
		}
		if($('#TransactionInfo_BC').val()==''){ 
			alertMassage = alertMassage + "\n Branch Chief";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){ 
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){ 
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_HA').val()==''){ 
			alertMassage = alertMassage + "\n HR Assistant";
			ret = false;
		}
		if($('#TransactionInfo_FA').val()==''){ 
			alertMassage = alertMassage + "\n Final Authorizer";
			ret = false;
		}
		if($('#PCKG_COMPLETE').val()==''){ 
			alertMassage = alertMassage + "\n Is the package complete";
			ret = false;
		}
		if($('#TransactionInfo_Priority').val()==''){ 
			alertMassage = alertMassage + "\n Priority";
			ret = false;
		}
		if($('#TransactionInfo_ASC').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Code";
			ret = false;
		}
		if($('#TransactionInfo_ActionStatus').val()==''){ 
			alertMassage = alertMassage + "\n Action Status";
			ret = false;
		}
		if($('#TransactionInfo_ASD').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Description";
			ret = false;
		}

		//Pre-Recruitment tab
		if($('#LEGISLATIVE_INIT_SUPPORTED').val()==''){ 
			alertMassage = alertMassage + "\n Legislative Initiative Supported";
			ret = false;
		}
		if($('#NUM_POSITIONS_TO_BE_ADV').val()==''){ 
			alertMassage = alertMassage + "\n Number of Positions Advertised";
			ret = false;
		}
		if($('#IS_READVERTISEMENT').val()==''){ 
			alertMassage = alertMassage + "\n Is this a Re-Advertisement";
			ret = false;
		}
		if($('#HR_CARDS_PD_USED').val()==''){ 
			alertMassage = alertMassage + "\n Recruitment Document Repository Used";
			ret = false;
		}
		if($('#IS_TRANSITIONAL_RECRUIT').val()==''){ 
			alertMassage = alertMassage + "\n Transitional Recruitment";
			ret = false;
		}
		if($('#OTHER_RECRUIT_CONSIDERATIONS').val()==''){ 
			alertMassage = alertMassage + "\n Other Recruitment Considerations";
			ret = false;
		}
		if($('#CLEARANCE_LEVEL_REQUIRED').val()==''){ 
			alertMassage = alertMassage + "\n Clearance Level Required for Position";
			ret = false;
		}
		if($('#PAID_AD').val()==''){ 
			alertMassage = alertMassage + "\n Paid Ad";
			ret = false;
		}
		if($('#IS_RELOCATION_EXPENSES_PAID').val()==''){ 
			alertMassage = alertMassage + "\n Will Relocation Expenses Be Paid";
			ret = false;
		}
		if ($("input[type=checkbox][name=INCENTIVES_OFFERED_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Incentives Offered";
			ret = false;
		}
		if ($("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Additional Recruitment Channels";
			ret = false;
		}
		
		//Applicant tab
		var cnt = $('#h_applicant_count').val();
		if(cnt >0) {
			for (var index = 1; index <= cnt; index++) {
				if($("#record_repeat" + index + "A_EM").val() =="") {
					alertMassage = alertMassage + "\n Evaluation Method";
					ret = false; 
				}
				if ($("input[type=checkbox][name=record_repeat" + index + "A_R_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
					alertMassage = alertMassage + "\n Rater";
					ret = false; 
				}
			}
		}
		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;
		}
	}
	else if(responseName=="Cancel") {		
		if($('#pv_initiatedFromRecruitmentRequest').val=="true") {
			if($('#TransactionInfo_HS').val()==''){
				alertMassage = alertMassage + "\n HR Specialist";
				ret = false;
			}
		}
		
		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#h_status').val('CANCELLED');
			var now = new Date();
			var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
			$('#h_statusDate').val(sysDate);
			$('#h_statusUserID').val($('#h_currentUserID').val());
			$('#h_updateRyb').val('true');
			return ret;
		}
	}
	else if(responseName=="Action Disapproved - Close Action") {
		$('#h_status').val('COMPLETED');
		var now = new Date();
		var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
		$('#h_statusDate').val(sysDate);
		$('#h_statusUserID').val($('#h_currentUserID').val());
		
		$('#h_rybCode').val('Blue');
		$('#h_rybStatus').val('Completed');
		$('#h_rybDesc').val('Action Disapproved');
		$('#h_updateRyb').val('true');

		return true;
		
	}
	else if(responseName=="Send to DEU (Job Analysis)") {
		//transaction and pre-recuritment
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}

				//Transaction tab
		if($('#h_lastname').val()==''){ 
			alertMassage = alertMassage + "\n HR Liasion Last Name";
			ret = false;
		}
		if($('#TransactionInfo_GR').val()==''){ 
			alertMassage = alertMassage + "\n SSB Recruitment";
			ret = false;
		}
		if($('#TransactionInfo_DateRecv').val()==''){ 
			alertMassage = alertMassage + "\n Date Recv'd in HR";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){ 
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#TransactionInfo_PED').val()==''){ 
			alertMassage = alertMassage + "\n Proposed Effective Date";
			ret = false;
		}
		if($('#TransactionInfo_BC').val()==''){ 
			alertMassage = alertMassage + "\n Branch Chief";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){ 
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){ 
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_HA').val()==''){ 
			alertMassage = alertMassage + "\n HR Assistant";
			ret = false;
		}
		if($('#TransactionInfo_FA').val()==''){ 
			alertMassage = alertMassage + "\n Final Authorizer";
			ret = false;
		}
		if($('#PCKG_COMPLETE').val()==''){ 
			alertMassage = alertMassage + "\n Is the package complete";
			ret = false;
		}
		if($('#TransactionInfo_Priority').val()==''){ 
			alertMassage = alertMassage + "\n Priority";
			ret = false;
		}
		if($('#TransactionInfo_ASC').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Code";
			ret = false;
		}
		if($('#TransactionInfo_ActionStatus').val()==''){ 
			alertMassage = alertMassage + "\n Action Status";
			ret = false;
		}
		if($('#TransactionInfo_ASD').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Description";
			ret = false;
		}

		//Pre-Recruitment tab
		if($('#LEGISLATIVE_INIT_SUPPORTED').val()==''){ 
			alertMassage = alertMassage + "\n Legislative Initiative Supported";
			ret = false;
		}
		if($('#NUM_POSITIONS_TO_BE_ADV').val()==''){ 
			alertMassage = alertMassage + "\n Number of Positions Advertised";
			ret = false;
		}
		if($('#IS_READVERTISEMENT').val()==''){ 
			alertMassage = alertMassage + "\n Is this a Re-Advertisement";
			ret = false;
		}
		if($('#HR_CARDS_PD_USED').val()==''){ 
			alertMassage = alertMassage + "\n Recruitment Document Repository Used";
			ret = false;
		}
		if($('#IS_TRANSITIONAL_RECRUIT').val()==''){ 
			alertMassage = alertMassage + "\n Transitional Recruitment";
			ret = false;
		}
		if($('#OTHER_RECRUIT_CONSIDERATIONS').val()==''){ 
			alertMassage = alertMassage + "\n Other Recruitment Considerations";
			ret = false;
		}
		if($('#CLEARANCE_LEVEL_REQUIRED').val()==''){ 
			alertMassage = alertMassage + "\n Clearance Level Required for Position";
			ret = false;
		}
		if($('#PAID_AD').val()==''){ 
			alertMassage = alertMassage + "\n Paid Ad";
			ret = false;
		}
		if($('#IS_RELOCATION_EXPENSES_PAID').val()==''){ 
			alertMassage = alertMassage + "\n Will Relocation Expenses Be Paid";
			ret = false;
		}
		if ($("input[type=checkbox][name=INCENTIVES_OFFERED_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Incentives Offered";
			ret = false;
		}
		if ($("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Additional Recruitment Channels";
			ret = false;
		}
		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;
		}
	}
	else if(responseName=="Audit Complete-Close Action") {
		//all tabs and if certificate type is "DE" and Date Audit Completed field is auto populated. 
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
				//Transaction tab
		if($('#h_lastname').val()==''){ 
			alertMassage = alertMassage + "\n HR Liasion Last Name";
			ret = false;
		}
		if($('#TransactionInfo_GR').val()==''){ 
			alertMassage = alertMassage + "\n SSB Recruitment";
			ret = false;
		}
		if($('#TransactionInfo_DateRecv').val()==''){ 
			alertMassage = alertMassage + "\n Date Recv'd in HR";
			ret = false;
		}
		if($('#ADMIN_CODE').val()==''){ 
			alertMassage = alertMassage + "\n Administrative Code";
			ret = false;
		}
		if($('#INSTITUTE').val()==''){ 
			alertMassage = alertMassage + "\n Customer Center";
			ret = false;
		}
		if($('#TransactionInfo_PED').val()==''){ 
			alertMassage = alertMassage + "\n Proposed Effective Date";
			ret = false;
		}
		if($('#TransactionInfo_BC').val()==''){ 
			alertMassage = alertMassage + "\n Branch Chief";
			ret = false;
		}
		if($('#TransactionInfo_TL').val()==''){ 
			alertMassage = alertMassage + "\n Team Leader";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){ 
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}
		if($('#TransactionInfo_HA').val()==''){ 
			alertMassage = alertMassage + "\n HR Assistant";
			ret = false;
		}
		if($('#TransactionInfo_FA').val()==''){ 
			alertMassage = alertMassage + "\n Final Authorizer";
			ret = false;
		}
		if($('#PCKG_COMPLETE').val()==''){ 
			alertMassage = alertMassage + "\n Is the package complete";
			ret = false;
		}
		if($('#TransactionInfo_Priority').val()==''){ 
			alertMassage = alertMassage + "\n Priority";
			ret = false;
		}
		if($('#TransactionInfo_ASC').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Code";
			ret = false;
		}
		if($('#TransactionInfo_ActionStatus').val()==''){ 
			alertMassage = alertMassage + "\n Action Status";
			ret = false;
		}
		if($('#TransactionInfo_ASD').val()==''){ 
			alertMassage = alertMassage + "\n Action Status Description";
			ret = false;
		}

		//Pre-Recruitment tab
		if($('#LEGISLATIVE_INIT_SUPPORTED').val()==''){ 
			alertMassage = alertMassage + "\n Legislative Initiative Supported";
			ret = false;
		}
		if($('#NUM_POSITIONS_TO_BE_ADV').val()==''){ 
			alertMassage = alertMassage + "\n Number of Positions Advertised";
			ret = false;
		}
		if($('#IS_READVERTISEMENT').val()==''){ 
			alertMassage = alertMassage + "\n Is this a Re-Advertisement";
			ret = false;
		}
		if($('#HR_CARDS_PD_USED').val()==''){ 
			alertMassage = alertMassage + "\n Recruitment Document Repository Used";
			ret = false;
		}
		if($('#IS_TRANSITIONAL_RECRUIT').val()==''){ 
			alertMassage = alertMassage + "\n Transitional Recruitment";
			ret = false;
		}
		if($('#OTHER_RECRUIT_CONSIDERATIONS').val()==''){ 
			alertMassage = alertMassage + "\n Other Recruitment Considerations";
			ret = false;
		}
		if($('#CLEARANCE_LEVEL_REQUIRED').val()==''){ 
			alertMassage = alertMassage + "\n Clearance Level Required for Position";
			ret = false;
		}
		if($('#PAID_AD').val()==''){ 
			alertMassage = alertMassage + "\n Paid Ad";
			ret = false;
		}
		if($('#IS_RELOCATION_EXPENSES_PAID').val()==''){ 
			alertMassage = alertMassage + "\n Will Relocation Expenses Be Paid";
			ret = false;
		}
		if ($("input[type=checkbox][name=INCENTIVES_OFFERED_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Incentives Offered";
			ret = false;
		}
		if ($("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			alertMassage = alertMassage + "\n Additional Recruitment Channels";
			ret = false;
		}
		
		//Applicant tab
		var cnt = $('#h_applicant_count').val();
		if(cnt >0) {
			for (var index = 1; index <= cnt; index++) {
				if($("#record_repeat" + index + "A_EM").val() =="") {
					alertMassage = alertMassage + "\n Evaluation Method";
					ret = false; 
				}
				if ($("input[type=checkbox][name=record_repeat" + index + "A_R_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
					alertMassage = alertMassage + "\n Rater";
					ret = false; 
				}
			}
		}
		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#h_status').val('COMPLETED');
			var now = new Date();
			var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
			$('#h_statusDate').val(sysDate);
			$('#h_statusUserID').val($('#h_currentUserID').val());
			
			$('#h_rybCode').val('Blue');
			$('#h_rybStatus').val('Completed');
			$('#h_rybDesc').val('Completed');
			$('#h_updateRyb').val('true');

			return ret;
		}
	}
	else if(responseName=="Ann Appvd to Post-Return to Branch") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}

		if(ret ==false){alert(alertMassage); return false;}
		else 	{
		    var cnt = $('#h_vacancy_count').val();
			for (var index = 1; index <= cnt; index++) {
				if ($('#vacancy_repeat' + index + 'V_AT').val() == 'DE') {
					var now = new Date();
					var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
					$('#DATE_ANN_APPROVED_BY_DEU').val(sysDate);			
				}
			}
			$('#pv_deStatus').val(' ');
			$('#h_rybCode').val('Red');
			$('#h_rybStatus').val('Active in HR');
			$('#h_rybDesc').val('Active');
			$('#h_updateRyb').val('true');

			return ret;	
		}
	}
	else if(responseName=="No Action Taken-Return to Branch") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}

		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#pv_deStatus').val(' ');
			$('#h_rybCode').val('Red');
			$('#h_rybStatus').val('Active in HR');
			$('#h_rybDesc').val('Active');
			$('#h_updateRyb').val('true');

			return ret;	
		}
	}
	else if(responseName=="Send Pending SPF Email") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}

		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;	
		}

	}
	else if(responseName=="Send SPF Outcome Email") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}

		if(ret ==false){alert(alertMassage); return false;}
		else {
			$('#h_updateRyb').val('false');
			return ret;	
		}
	}
	else if(responseName=="Send to Pending Status") {
		$('#h_updateRyb').val('false');
		return true;
	}
	else if(responseName=="Issue Cert-Return to Branch") {
		if($('#JOB_OPENING_ID').val()==''){
			alertMassage = alertMassage + "\n Requisition Number";
			ret = false;
		}
		if($('#TransactionInfo_HS').val()==''){
			alertMassage = alertMassage + "\n HR Specialist";
			ret = false;
		}

		if(ret ==false){alert(alertMassage); return false;}
		else 	{
			$('#pv_deStatus').val(' ');
			$('#h_rybCode').val('Red');
			$('#h_rybStatus').val('Active in HR');
			$('#h_rybDesc').val('Active');
			$('#h_updateRyb').val('true');

			return ret;	
		}
	}
	else
	{
		alert("Cannot find Response");
		return false;
	}
}

function getSelectedResponse()
{
    var response = "";

    try
    {
        var obj = basicWIHActionClient.getSelectedResponse();
        if(obj)
        {
            return obj.NAME;
        }
    }
    catch (e)
    {
        response = "";
    }

    return response;
}