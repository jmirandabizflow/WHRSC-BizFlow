
var recruitementStatus = function(){
	var cnt = $('#checkCount').val();

	for (var index = 1; index <= cnt; index++) {
        runActionStatus(index);
	}
}

function submit() {
	var cnt = $('#checkCount').val();
	for (var index = 1; index <= cnt; index++) {	
		var orgComment  =  $('#BasicTable' + index + 'COMMENTS').val();
		if (orgComment.length > 0) {
			var cmmCnt = $('#BasicTable' + index + 'COMMENTS').val().length+16;
			var cmmStatus = $('#BasicTable' + index + 'COMMENT_STATUS').val();
			var cmmStatusCnt = cmmStatus.length;
			var subs = 4000 - cmmStatusCnt +cmmCnt;
			var totalCnt = cmmCnt + cmmStatusCnt;
			if(totalCnt > 4000) {
				$('#BasicTable' + index + 'COMMENT_STATUS').val(cmmStatus.substring(0,3900-subs));
			}		
			var now = new Date();
			var sysDate = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, now);
			var commInput = sysDate + ' ' + orgComment + '\r\n';
			$('#BasicTable' + index + 'COMMENT_DATA').val(commInput);                       
		}
		else {
			$('#BasicTable' + index + 'COMMENT_DATA').val('');
		}
		
	}
}
function  runActionStatus(index) {
	$('#BasicTable' + index + 'ACTION_STATUS').on('change',function() {
		var originalActionStatus = $('#BasicTable' + index + 'ORIGINAL_ACTION_STATUS').val();
		var currentActionStatus =  $('#BasicTable' + index + 'ACTION_STATUS').val();
		if(originalActionStatus!=currentActionStatus) {
			 
			$('#BasicTable' + index + 'COMMENTS').attr('_required', 'true');
		}
		else {
			$('#BasicTable' + index + 'COMMENTS').attr('_required', 'false');
		}
	});
}