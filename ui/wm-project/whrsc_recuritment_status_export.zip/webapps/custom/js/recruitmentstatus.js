function submit() {
	var cnt = $('#checkCount').val();
	for (var index = 1; index <= cnt; index++) {	
		var cmmCnt = $('#BasicTable' + index + 'COMMENTS').val().length+16;
		var cmmStatus = $('#BasicTable' + index + 'COMMENT_STATUS').val();
		var cmmStatusCnt = cmmStatus.length;
		var subs = 4000 - cmmStatusCnt +cmmCnt;
		var totalCnt = cmmCnt + cmmStatusCnt;
		if(totalCnt > 4000) {
			$('#BasicTable' + index + 'COMMENT_STATUS').val(cmmStatus.substring(0,3900-subs));
		}		
	}
}
