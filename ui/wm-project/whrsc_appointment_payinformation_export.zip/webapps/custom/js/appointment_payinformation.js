var appointPay = function(){
    
    
    $('#P_DATE_APR_SENT_APP_calendar_anchor').attr('tabindex', 41);
    $('#P_DATE_APR_APP_calendar_anchor').attr('tabindex', 61);
    $('#P_DATE_HPR_AUTH_calendar_anchor').attr('tabindex', 161);
    
    	if ($("#P_PAY_TYPE").val() != ''){
			//alert (selVal);     
			 if ($("#P_PAY_TYPE").val() == 'Advanced Rate of Pay'){
        		$('#highest_group').addClass('hidden');
                $('#advanced_group').removeClass('hidden');
             }else{
                $('#advanced_group').addClass('hidden');
            	$('#highest_group').removeClass('hidden');
             }
        }else{
            $('#advanced_group').addClass('hidden');
            $('#highest_group').addClass('hidden');
        }
    
    $("#P_PAY_TYPE").on("change", function(){
		var selVal = $(this).children("option:selected").val();
        
        if (selVal != ''){
			//alert (selVal);     
			 if (selVal == 'Advanced Rate of Pay'){
        		$('#highest_group').addClass('hidden');
                $('#advanced_group').removeClass('hidden');
                $('#P_DATE_HPR_AUTH').val('');
                $('#P_MAX_PAY_RATE').val('');
             }else{
                $('#advanced_group').addClass('hidden');
            	$('#highest_group').removeClass('hidden');
                $('#P_DATE_APR_SENT_APP').val('');
                $('#P_DATE_APR_APP').val('');
                 
                $("input[type=checkbox][name=P_APR_JUSTIFI_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
				$("input[type=checkbox][name=P_SD_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
				
				var ct_just = $("#P_APR_JUSTIFI option").size();
				
				var ct_deter =  $("#P_SD option").size();
				
				for (var ij = 1 ; ij <= ct_just - 1; ij++){
					
					$('#P_APR_JUSTIFI_M' + ij).attr('checked',false); 
					
				}
				
				for (var id = 1 ; id <= ct_deter - 1 ; id++){
					
					$('#P_SD_M' + id).attr('checked',false); 
					
				}
                //alert ($('#P_APR_JUSTIFI_M'));
                //$('#P_APR_JUSTIFI_M').children().remove();
                //$('#P_APR_JUSTIFI_M').empty();
                //$('#P_APR_STEP_DETERMINE_M').empty();
                //$('#P_APR_JUSTIFI_M :checked').each(function(){
                //    var tmp = $(this).val() ;
                //    alert (tmp);
                    //alert ('2' + $(this).text());
                    //if ($(this).text()==tempnat){
                    //    $('#A_NAT_ACT_CD').append('<option selected value=' + $tmp.val() + '>' + $tmp.text() + '</option>');
                    //}else{
                    //    $('#A_NAT_ACT_CD').append('<option value=' + $tmp.val() + '>' + $tmp.text() + '</option>');
                    //}            
                //});
             }
        }else{
            $('#advanced_group').addClass('hidden');
            $('#highest_group').addClass('hidden');
            $('#P_DATE_HPR_AUTH').val('');
            $('#P_MAX_PAY_RATE').val('');
            $('#P_DATE_APR_SENT_APP').val('');
            $('#P_DATE_APR_APP').val('');
                 
            $("input[type=checkbox][name=P_APR_JUSTIFI_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
			$("input[type=checkbox][name=P_SD_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
				
				var ct_just = $("#P_APR_JUSTIFI option").size();
				
				var ct_deter =  $("#P_SD option").size();
				
				for (var ij = 1 ; ij <= ct_just - 1; ij++){
					
					$('#P_APR_JUSTIFI_M' + ij).attr('checked',false); 
					
				}
				
				for (var id = 1 ; id <= ct_deter - 1 ; id++){
					
					$('#P_SD_M' + id).attr('checked',false); 
					
				}
        }
        
    });
    
    
    utility.multiSelectFD('P_APR_JUSTIFI',0);
    //multiSelonPay('P_APR_JUSTIFI');
    $("input[type=checkbox][name=P_APR_JUSTIFI_M]").trigger("change");
    $('#P_APR_JUSTIFI').attr("title", "Please select using space and arrows key.");
    //multiSelonPay('P_STEP_ASSGIN');
	//$("input[type=checkbox][name=P_STEP_ASSGIN_M]").trigger("change");
	utility.multiSelectFD('P_SD',0);
	//multiSelonPay('P_SD');
    $("input[type=checkbox][name=P_SD_M]").trigger("change");
    $('#P_SD').attr("title", "Please select using space and arrows key.");
}