var base_url = '/bizflowwebmaker/whrsc_AUT/';

var appointAppointment = function(){
	var h_viNumber = $('#h_viNumber').val(); 
	var h_certNumber = $('#h_certNumber').val(); 

    $('#layout_hidden_1').addClass('hidden');
    $('#layout_hidden_2').addClass('hidden');
    

	var  from2 = $('#pv_from').val();
	if(from2!='Appointment') {
		WHRSCMain.setAlwaysReadonly('A_CAP_HR_JOB_REQ');
		$('#A_CAP_HR_JOB_REQ').css('background-color', '#efefef');		
	}

	var requsitionNumber = $('#h_requisitionNumber').val();
	if(requsitionNumber!='')
	{
		$('#A_CAP_HR_JOB_REQ').val(requsitionNumber);
	}

	WHRSCMain.setAlwaysReadonly('A_RELATE_RECR_REQ');
    WHRSCMain.setAlwaysReadonly('A_ANNOUNCEMENT');
    WHRSCMain.setAlwaysReadonly('A_CERTIFICATE_NO');
    WHRSCMain.setAlwaysReadonly('A_RELATIONSIHP_ACT');
    WHRSCMain.setAlwaysReadonly('A_CERTIFICATE_TYPE');
    WHRSCMain.setAlwaysReadonly('A_POSITION_TITL');
    WHRSCMain.setAlwaysReadonly('A_PAY_PLAN');
    WHRSCMain.setAlwaysReadonly('A_SERIES');
    WHRSCMain.setAlwaysReadonly('A_GRADE');
    WHRSCMain.setAlwaysReadonly('A_FPL');
    WHRSCMain.setAlwaysReadonly('A_SP_STATUS');
    WHRSCMain.setAlwaysReadonly('A_JOB_OFF_RES');
    WHRSCMain.setAlwaysReadonly('A_306_AS_ON_MAN');
    WHRSCMain.setAlwaysReadonly('A_CLEAR_LEV_REQ');
    WHRSCMain.setAlwaysReadonly('A_TYPE_SEL');
    WHRSCMain.setAlwaysReadonly('A_DUTY_INPUT');
    WHRSCMain.setAlwaysReadonly('A_DUTY_INPUT_C');
	$('#A_RELATE_RECR_REQ').css('background-color', '#efefef');
    $('#A_ANNOUNCEMENT').css('background-color', '#efefef');
    $('#A_CERTIFICATE_NO').css('background-color', '#efefef');
    $('#A_RELATIONSIHP_ACT').css('background-color', '#efefef');
    $('#A_CERTIFICATE_TYPE').css('background-color', '#efefef');
    $('#A_POSITION_TITL').css('background-color', '#efefef');
    $('#A_PAY_PLAN').css('background-color', '#efefef');
    $('#A_SERIES').css('background-color', '#efefef');
    $('#A_GRADE').css('background-color', '#efefef');
    $('#A_FPL').css('background-color', '#efefef');
    $('#A_SP_STATUS').css('background-color', '#efefef');
    $('#A_JOB_OFF_RES').css('background-color', '#efefef');
    $('#A_306_AS_ON_MAN').css('background-color', '#efefef');
    $('#A_CLEAR_LEV_REQ').css('background-color', '#efefef');
    $('#A_TYPE_SEL').css('background-color', '#efefef');
    $('#A_DUTY_INPUT').css('background-color', '#efefef');
    $('#A_DUTY_INPUT_C').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('A_DATE_CERT_SNT_SEL');
    WHRSCMain.setAlwaysReadonly('A_DATE_HIR_DEC');
    WHRSCMain.setAlwaysReadonly('A_DATE_HIR_DEC_HR');
    WHRSCMain.setAlwaysReadonly('A_DATE_TENT_JOB_OFF');
    WHRSCMain.setAlwaysReadonly('A_DATA_TENT_JOB_PES');
    WHRSCMain.setAlwaysReadonly('A_DATE_OFF_JOB');
    WHRSCMain.setAlwaysReadonly('A_DATE_JOB_OFF_RESP');
    WHRSCMain.setAlwaysReadonly('A_EOD');
    $('#A_DATE_CERT_SNT_SEL').css('background-color', '#efefef');
    $('#A_DATE_HIR_DEC').css('background-color', '#efefef');
    $('#A_DATE_HIR_DEC_HR').css('background-color', '#efefef');
    $('#A_DATE_TENT_JOB_OFF').css('background-color', '#efefef');
    $('#A_DATA_TENT_JOB_PES').css('background-color', '#efefef');
    $('#A_DATE_OFF_JOB').css('background-color', '#efefef');
    $('#A_DATE_JOB_OFF_RESP').css('background-color', '#efefef');
    $('#A_EOD').css('background-color', '#efefef');
    $('#A_DATE_CERT_SNT_SEL_calendar_anchor').addClass('hidden');
    $('#A_DATE_HIR_DEC_calendar_anchor').addClass('hidden');
    $('#A_DATE_HIR_DEC_HR_calendar_anchor').addClass('hidden');
    $('#A_DATE_TENT_JOB_OFF_calendar_anchor').addClass('hidden');
    $('#A_DATA_TENT_JOB_PES_calendar_anchor').addClass('hidden');
    $('#A_DATE_OFF_JOB_calendar_anchor').addClass('hidden');
    $('#A_DATE_JOB_OFF_RESP_calendar_anchor').addClass('hidden');
    $('#A_EOD_calendar_anchor').addClass('hidden');

    
    $('#A_NAME_INPUT_E_container').addClass('hidden');
	$('#A_NAME_INPUT_E').attr('_required', 'false');
    
    //$('#A_NAME_INPUT_F_container').addClass('hidden');
    //WHRSCMain.setAlwaysDisabled('A_NAME_INPUT_F');
	//$('#A_NAME_INPUT_F').attr('_required', 'false');
	//background-color : #ffffff;
	//border-top-color : #ffffff; border-right-color : #ffffff; border-bottom-color : #ffffff; border-left-color : #ffffff; background-color : #ffffff;
	$('#hidden_emp_email_1').addClass('hidden');
    $('#hidden_emp_email_2').removeClass('hidden');   
    
    //WHRSCMain.setAlwaysDisabled('A_DUTY_INPUT_C');
    
    //$('#A_NAME_INPUT_I_container').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('A_NAME_INPUT_I');
    $('#A_NAME_INPUT_I').css('background-color', '#efefef');
	//$('#A_NAME_INPUT_I').attr('_required', 'false');
    
    $('#Supervisor_section_8').addClass('hidden');
    
    $('#A_SP_INPUT_F_container').addClass('hidden');
	$('#A_SP_INPUT_F').attr('_required', 'false');
    $('#A_SP_INPUT_E_container').addClass('hidden');
	$('#A_SP_INPUT_E').attr('_required', 'false');
    
    $('#A_DATE_SECU_NOTI_REC_calendar_anchor').attr('tabindex', 461);
    $('#A_DATE_PRE_NEW_HIR_EMAIL_calendar_anchor').attr('tabindex', 481);
    $('#A_DATE_WORK_PERMIT_RECEIVED_calendar_anchor').attr('tabindex', 601);
    $('#A_NTE_DATE_calendar_anchor').attr('tabindex', 731);
    $('#A_EDUCATIONAL_DOCS_RCVD_DATE_calendar_anchor').attr('tabindex', 741);
    $('#A_EXP_DATE_PRG_COM_calendar_anchor').attr('tabindex', 586);
    $('#A_BASIC_PAY_MIN_label_hint_container').attr('tabindex', 609);
    $('#A_BASIC_PAY_MAX_label_hint_container').attr('tabindex', 619);
    $('#A_IS_REEMPLOYED_ANNUITANT_label_hint_container').attr('tabindex', 709);
    $('#A_ADDITIONAL_APPROVAL_COMMENT').attr('_type', 'string');
    
    $('#category_temp_hide').addClass('hidden');
    $('#parent_layout_group').addClass('hidden');
    $('#A_NAT_ACT_CD').empty();
    //$('#A_NAT_ACT_CD').append('<option value='' Selected>Select One</option>');
    //
    if ($('#A_ADDITIONAL_APPROVAL_REQ').val() == 'No'){
            WHRSCMain.setAlwaysReadonly('AP_DATE_PKG_SENT');    
            $('#AP_DATE_PKG_SENT').css('background-color', '#efefef');
        	$('#AP_DATE_PKG_SENT').css('width', 400);
            $('#AP_DATE_PKG_SENT_calendar_anchor').addClass('hidden');
        
        	WHRSCMain.setAlwaysReadonly('AP_DATE_APP_DEC_REC');    
            $('#AP_DATE_APP_DEC_REC').css('background-color', '#efefef');
        	$('#AP_DATE_APP_DEC_REC').css('width', 400);
            $('#AP_DATE_APP_DEC_REC_calendar_anchor').addClass('hidden');
        }
    
    $('#A_ADDITIONAL_APPROVAL_REQ').on('change',function(e) {
        
        var aaar = $(this).children("option:selected").val();
               
        if (aaar == 'No') {
            WHRSCMain.setAlwaysReadonly('AP_DATE_PKG_SENT');    
            $('#AP_DATE_PKG_SENT').css('background-color', '#efefef');
            $('#AP_DATE_PKG_SENT').css('width', 400);
            $('#AP_DATE_PKG_SENT_calendar_anchor').addClass('hidden');
            
            WHRSCMain.setAlwaysReadonly('AP_DATE_APP_DEC_REC');    
            $('#AP_DATE_APP_DEC_REC').css('background-color', '#efefef');
            $('#AP_DATE_APP_DEC_REC').css('width', 400);
            $('#AP_DATE_APP_DEC_REC_calendar_anchor').addClass('hidden');
        }else{
            $('#AP_DATE_PKG_SENT').removeAttr("readonly");
        	$('#AP_DATE_PKG_SENT').css('background-color', '#ffffff');
            $('#AP_DATE_PKG_SENT').css('width', 366);
            $('#AP_DATE_PKG_SENT_calendar_anchor').removeClass('hidden');
            
            $('#AP_DATE_APP_DEC_REC').removeAttr("readonly");
        	$('#AP_DATE_APP_DEC_REC').css('background-color', '#ffffff');
            $('#AP_DATE_APP_DEC_REC').css('width', 366);
            $('#AP_DATE_APP_DEC_REC_calendar_anchor').removeClass('hidden');
        }
    });
    
    
    if ($('#nature_temp').val() != '' ){
        var tempnat = $('#nature_temp').val();
        $('#nature_type_parent').val($('#A_APPOINT_TYPE').val());
        $('#A_NAT_ACT_CD').append('<option value= >Select One</option>');
        $('#nature_type_parent :selected').each(function(){
            var $tmp = $('#nature_type_data option[value=\"' + $(this).text() + '\"]');
            //alert ('1' + tempnat);
            //alert ('2' + $(this).text());
            if ($(this).text()==tempnat){
                $('#A_NAT_ACT_CD').append('<option selected value=\"' + $tmp.text() + '\">' + $tmp.text() + '</option>');
            }else{
                $('#A_NAT_ACT_CD').append('<option value=\"' + $tmp.text() + '\">' + $tmp.text() + '</option>');
            }            
        });
        if (tempnat !== undefined) {
            $('#A_NAT_ACT_CD').val(tempnat);
        }
    }
    
    
    $('#A_APPOINT_TYPE').on('change',function(e) {
        
        var preselect = $('#A_NAT_ACT_CD').val();
        $('#A_NAT_ACT_CD').empty();
        $('#nature_type_parent').val($(this).val());
        $('#A_NAT_ACT_CD').append($('<option>',{value: "", text: "Select One"}));
        $('#nature_type_parent :selected').each(function(){
            var $tmp = $('#nature_type_data option[value=\"' + $(this).text() + '\"]');
            $('#A_NAT_ACT_CD').append('<option value=\"' + $tmp.text() + '\">' + $tmp.text() + '</option>');
        });
        
        if (preselect !== undefined) {
            $('#A_NAT_ACT_CD').val(preselect);
        }
    });
    
        
        if ($('#A_HIRING_FLEX_TYPE').val() == 'Schedule D - Internship (Indefinite)' || $('#A_HIRING_FLEX_TYPE').val() == 'Schedule D - Internship (Temporary)'){
            $('#pathways_group').removeClass('hidden');
        	$('#workpermit_group').removeClass('hidden');
            $('#expect_prg_comp_1').removeClass('hidden');
            $('#expect_prg_comp_2').addClass('hidden');
            $('#hiring_other_1').addClass('hidden');
            $('#hiring_other_2').removeClass('hidden');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'true');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'false');
            $('#A_EXP_DATE_PRG_COM_marker').addClass('hidden');
        }else if ($('#A_HIRING_FLEX_TYPE').val() == 'Schedule D - Presidential Management Fellow (PMF)' || $('#A_HIRING_FLEX_TYPE').val() == 'Schedule D - Recent Graduate'){
            $('#pathways_group').removeClass('hidden');
        	$('#expect_prg_comp_1').removeClass('hidden');
            $('#expect_prg_comp_2').addClass('hidden');
            $('#workpermit_group').removeClass('hidden');
            $('#hiring_other_1').addClass('hidden');
            $('#hiring_other_2').removeClass('hidden');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'true');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'true');
            $('#A_EXP_DATE_PRG_COM_marker').removeClass('hidden');
        }else if ($('#A_HIRING_FLEX_TYPE').val() == 'Other'){
            $('#pathways_group').addClass('hidden');
            $('#workpermit_group').addClass('hidden');
    		$('#expect_prg_comp_1').addClass('hidden');
            $('#expect_prg_comp_2').removeClass('hidden');
            $('#hiring_other_1').removeClass('hidden');
            $('#hiring_other_2').addClass('hidden');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'false');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'false');
        }else{
            $('#pathways_group').addClass('hidden');
            $('#workpermit_group').addClass('hidden');
    		$('#expect_prg_comp_1').addClass('hidden');
            $('#expect_prg_comp_2').removeClass('hidden');
            $('#hiring_other_1').addClass('hidden');
            $('#hiring_other_2').removeClass('hidden');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'false');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'false');
        }        
    
    $('#A_HIRING_FLEX_TYPE').on('change', function(){
		var selVal = $(this).children('option:selected').val();
        
        if (selVal == 'Schedule D - Internship (Indefinite)' || selVal == 'Schedule D - Internship (Temporary)'){
            $('#pathways_group').removeClass('hidden');
        	$('#workpermit_group').removeClass('hidden');
            $('#expect_prg_comp_1').removeClass('hidden');
            $('#expect_prg_comp_2').addClass('hidden');
            $('#hiring_other_1').addClass('hidden');
            $('#hiring_other_2').removeClass('hidden');
            $('#A_HIRING_FLEX_TYPE_OTHER').val('');
            
            //$('#A_EXP_DATE_PRG_COM').val('');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'true');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'false');
            $('#A_EXP_DATE_PRG_COM_marker').addClass('hidden');
        }else if (selVal == 'Schedule D - Presidential Management Fellow (PMF)' || selVal == 'Schedule D - Recent Graduate'){
            $('#pathways_group').removeClass('hidden');
        	$('#expect_prg_comp_1').removeClass('hidden');
            $('#expect_prg_comp_2').addClass('hidden');
            $('#workpermit_group').removeClass('hidden');
            $('#hiring_other_1').addClass('hidden');
            $('#hiring_other_2').removeClass('hidden');
            $('#A_HIRING_FLEX_TYPE_OTHER').val('');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'true');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'true');
            $('#A_EXP_DATE_PRG_COM_marker').removeClass('hidden');
        }else if ($('#A_HIRING_FLEX_TYPE').val() == 'Other'){
            $('#pathways_group').addClass('hidden');
            $('#workpermit_group').addClass('hidden');
    		$('#expect_prg_comp_1').addClass('hidden');
            $('#expect_prg_comp_2').removeClass('hidden');
            $('#hiring_other_1').removeClass('hidden');
            $('#hiring_other_2').addClass('hidden');
            
            $('#A_IS_PATHWAY_AGREE_COMP').val('');
            $('#A_EXP_DATE_PRG_COM').val('');
            $('#A_WORK_PERMIT_REQUIRED').val('');
            $('#A_DATE_WORK_PERMIT_RECEIVED').val('');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'false');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'false');
            
        }else{
            $('#pathways_group').addClass('hidden');
            $('#workpermit_group').addClass('hidden');
    		$('#expect_prg_comp_1').addClass('hidden');
            $('#expect_prg_comp_2').removeClass('hidden');
            $('#hiring_other_1').addClass('hidden');
            $('#hiring_other_2').removeClass('hidden');
            $('#A_HIRING_FLEX_TYPE_OTHER').val('');
            
            $('#A_IS_PATHWAY_AGREE_COMP').val('');
            $('#A_EXP_DATE_PRG_COM').val('');
            $('#A_WORK_PERMIT_REQUIRED').val('');
            $('#A_DATE_WORK_PERMIT_RECEIVED').val('');
            
            $('#A_IS_PATHWAY_AGREE_COMP').attr('_required', 'false');
            $('#A_EXP_DATE_PRG_COM').attr('_required', 'false');
        }                
    });
    
    supervisorAutoComplete();
    
    if ($('#h_a_supervisor_lastname').val() != '') {
        
        	var li_last_name = "<li id=\"" + $('#h_a_supervisor_lastname').val() + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement($('#h_a_supervisor_lastname').val(), $('#h_a_supervisor_lastname').val(), '51');
            li_last_name += $('#h_a_supervisor_lastname').val() + '</b></li>';
            
            var li_first_name = "<li id=\"" + $('#h_a_supervisor_firstname').val() + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement($('#h_a_supervisor_firstname').val(), $('#h_a_supervisor_firstname').val(), '52');
            li_first_name += $('#h_a_supervisor_firstname').val() + '</b></li>';
            
            var li_email = "<li id=\"" + $('#h_a_supervisor_email').val() + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement($('#h_a_supervisor_email').val(), $('#h_a_supervisor_email').val(), '53');
			li_email += $('#h_a_supervisor_email').val() + '</b></li>';
        
        
        
        $('#A_SP_DISP').append(li_last_name).removeClass('hidden');
        $('#A_SP_DISP_F').append(li_first_name).removeClass('hidden');
        $('#A_SP_DISP_E').append(li_email).removeClass('hidden');
        
        $('#A_SP_INPUT_container').addClass('hidden');
		$('#A_SP_INPUT').attr('_required', 'false');
        $('#Supervisor_section_8').removeClass('hidden');
	}else{
    	$('#Supervisor_section_8').addClass('hidden');
    }
    
    $('#A_SP_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#A_SP_DISP').addClass('hidden').empty();
            $('#A_SP_DISP_F').addClass('hidden').empty();
            $('#A_SP_DISP_E').addClass('hidden').empty();
			$('#A_SP_INPUT_container').removeClass('hidden');
			//$('#A_SP_INPUT').attr('_required', 'true');
            $('#Supervisor_section_8').addClass('hidden');
            $('#h_a_supervisor_lastname').val('');
            $('#h_a_supervisor_firstname').val('');
            $('#h_a_supervisor_email').val('');
		}
	});
    
    $('#A_SP_DISP_F').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#A_SP_DISP_F').addClass('hidden').empty();
            $('#A_SP_DISP').addClass('hidden').empty();
            $('#A_SP_DISP_E').addClass('hidden').empty();
			$('#A_SP_INPUT_container').removeClass('hidden');
			//$('#A_SP_INPUT').attr('_required', 'true');
            $('#Supervisor_section_8').addClass('hidden');
            $('#h_a_supervisor_lastname').val('');
            $('#h_a_supervisor_firstname').val('');
            $('#h_a_supervisor_email').val('');
		}
	});

	$('#A_SP_DISP_E').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#A_SP_DISP_E').addClass('hidden').empty();
            $('#A_SP_DISP').addClass('hidden').empty();
            $('#A_SP_DISP_F').addClass('hidden').empty();
			$('#A_SP_INPUT_container').removeClass('hidden');
			//&('#A_SP_INPUT').attr('_required', 'true');
            $('#Supervisor_section_8').addClass('hidden');
            $('#h_a_supervisor_lastname').val('');
            $('#h_a_supervisor_firstname').val('');
            $('#h_a_supervisor_email').val('');
		}
	});
    
    employeeAutoComplete();
    
    
    if ($('#A_CURRENT_NIH_EMPLOYEE').val() == 'Yes') {
        
        	var li_last_name = "<li id=\"" + $('#h_a_emp_lastname').val() + "\" ><b>";
			li_last_name += removefuncapp.getAutoCompRemoveIconElement($('#h_a_emp_lastname').val(), $('#h_a_emp_lastname').val(), '51');
            li_last_name += $('#h_a_emp_lastname').val() + '</b></li>';
            
            var li_first_name = "<li id=\"" + $('#h_a_emp_firstname').val() + "\" ><b>";
			li_first_name += removefuncapp.getAutoCompRemoveIconElement($('#h_a_emp_firstname').val(), $('#h_a_emp_firstname').val(), '52');
            li_first_name += $('#h_a_emp_firstname').val() + '</b></li>';
            
            var li_email = "<li id=\"" + $('#h_a_emp_email').val() + "\" ><b>";
			li_email += removefuncapp.getAutoCompRemoveIconElement($('#h_a_emp_email').val(), $('#h_a_emp_email').val(), '53');
			li_email += $('#h_a_emp_email').val() + '</b></li>';
        
        	var li_emid = "<li id=\"" + $('#h_a_emp_empcode').val() + "\" ><b>";
			li_emid += removefuncapp.getAutoCompRemoveIconElement($('#h_a_emp_empcode').val(), $('#h_a_emp_empcode').val(), '53');
			li_emid += $('#h_a_emp_empcode').val() + '</b></li>';
        
        
        $('#A_NAME_DISP').append(li_last_name).removeClass('hidden');
        $('#A_NAME_DISP_F').append(li_first_name).removeClass('hidden');
        $('#A_NAME_DISP_E').append(li_email).removeClass('hidden');
        //$('#A_NAME_DISP_I').append(li_emid).removeClass('hidden');
        
        $('#A_NAME_INPUT_container').addClass('hidden');
		$('#A_NAME_INPUT').attr('_required', 'false');
        $('#A_NAME_INPUT_F_container').addClass('hidden');
        $('#A_NAME_INPUT_F').attr('_required', 'false');
    }else{
    	$('#A_NAME_INPUT').val($('#h_a_emp_lastname').val());
        $('#A_NAME_INPUT_F').val($('#h_a_emp_firstname').val());
    }
    
    $('#A_NAME_INPUT_F').on("blur", function(){
        
        if ($('#A_NAME_INPUT').val() != '' && $('#A_NAME_INPUT_F').val() != ''){
            
        	$('#A_NAME_INPUT_I').val('');
            $('#A_CURRENT_NIH_EMPLOYEE').val('No');
            
        }
    });
    
    $('#A_NAME_INPUT').on("change", function(){
		 var lmch = $('#A_NAME_INPUT').val();
        $('#h_a_emp_lastname').val(lmch);
    });
    
    $('#A_NAME_INPUT_F').on("change", function(){
		 var fmch = $('#A_NAME_INPUT_F').val();
        $('#h_a_emp_firstname').val(fmch);
    });
    
    $('#A_NAME_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
            $('#A_NAME_DISP').addClass('hidden').empty();
            $('#A_NAME_DISP_F').addClass('hidden').empty();
            $('#A_NAME_DISP_E').addClass('hidden').empty();
            $('#A_NAME_DISP_I').addClass('hidden').empty();
			$('#A_NAME_INPUT_container').removeClass('hidden');
            $('#A_NAME_INPUT_F_container').removeClass('hidden');
			//$('#A_NAME_INPUT').attr('_required', 'true');
            $('#A_NAME_INPUT_I').val('');
            $('#A_NAME_INPUT_F').val('');
            $('#A_NAME_INPUT').val('');
            $('#h_a_emp_lastname').val('');
            $('#h_a_emp_firstname').val('');
            $('#h_a_emp_email').val('');
            $('#h_a_emp_empcode').val('');
            $('#A_CURRENT_NIH_EMPLOYEE').val('No');
		}
	});
    
    $('#A_NAME_DISP_F').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#A_NAME_DISP_F').addClass('hidden').empty();
            $('#A_NAME_DISP').addClass('hidden').empty();
            $('#A_NAME_DISP_E').addClass('hidden').empty();
            $('#A_NAME_DISP_I').addClass('hidden').empty();
			$('#A_NAME_INPUT_container').removeClass('hidden');
			//$('#A_NAME_INPUT').attr('_required', 'true');
            $('#A_NAME_INPUT_F_container').removeClass('hidden');
            $('#A_NAME_INPUT_I').val('');
            $('#A_NAME_INPUT_F').val('');
            $('#A_NAME_INPUT').val('');
            $('#h_a_emp_lastname').val('');
            $('#h_a_emp_firstname').val('');
            $('#h_a_emp_email').val('');
            $('#h_a_emp_empcode').val('');
            $('#A_CURRENT_NIH_EMPLOYEE').val('No');
		}
	});

	$('#A_NAME_DISP_E').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#A_NAME_DISP_E').addClass('hidden').empty();
            $('#A_NAME_DISP').addClass('hidden').empty();
            $('#A_NAME_DISP_F').addClass('hidden').empty();
            $('#A_NAME_DISP_I').addClass('hidden').empty();
			$('#A_NAME_INPUT_container').removeClass('hidden');
			//$('#A_NAME_INPUT').attr('_required', 'true');
            $('#A_NAME_INPUT_F_container').removeClass('hidden');
            $('#A_NAME_INPUT_I').val('');
            $('#A_NAME_INPUT_F').val('');
            $('#A_NAME_INPUT').val(''); 
            $('#h_a_emp_lastname').val('');
            $('#h_a_emp_firstname').val('');
            $('#h_a_emp_email').val('');
            $('#h_a_emp_empcode').val('');
            $('#A_CURRENT_NIH_EMPLOYEE').val('No');
		}
	});
    $('#A_NAME_DISP_I').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#A_NAME_DISP_E').addClass('hidden').empty();
            $('#A_NAME_DISP').addClass('hidden').empty();
            $('#A_NAME_DISP_F').addClass('hidden').empty();
            $('#A_NAME_DISP_I').addClass('hidden').empty();
			$('#A_NAME_INPUT_container').removeClass('hidden');
			//$('#A_NAME_INPUT').attr('_required', 'true');
            $('#A_NAME_INPUT_F_container').removeClass('hidden');
            $('#A_NAME_INPUT_I').val('');
            $('#A_NAME_INPUT_F').val('');
            $('#A_NAME_INPUT').val('');
            $('#h_a_emp_lastname').val('');
            $('#h_a_emp_firstname').val('');
            $('#h_a_emp_email').val('');
            $('#h_a_emp_empcode').val('');
            $('#A_CURRENT_NIH_EMPLOYEE').val('No');
		}
	});
    
    //multiSelMedical();
    utility.multiSelectFD('A_MEDICAL_SPECIALITY',0);
	$("input[type=checkbox][name=A_MEDICAL_SPECIALITY_M]").trigger("change");
    $('#A_MEDICAL_SPECIALITY').attr("title", "Please select using space and arrows key.");
    
    //multiSelReferby();
    utility.multiSelectFD('A_APPOINTEE_REFERRED_BY',0);
    $("input[type=checkbox][name=A_APPOINTEE_REFERRED_BY_M]").trigger("change");
    $('#A_APPOINTEE_REFERRED_BY').attr("title", "Please select using space and arrows key.");
	
    
}

var supervisorAutoComplete = function () {
   
	$('#A_SP_INPUT').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchSV.do?SearchSV=' + $('#A_SP_INPUT').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       
                        
						return {
							//ac_id: $( 'AC_ID', this ).text(),
							last_name: $( 'LNAME', this ).text(),
							first_name: $( 'FNAME', this ).text(),
							email: $( 'EMAIL', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#A_SP_INPUT_noMatch').remove();
				$(this).after("<span id='A_SP_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#A_SP_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#A_SP_INPUT_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_last_name = "<li id=\"" + ui.item.last_name + "\" ><b>";
			li_last_name += removefuncapp.getAutoCompRemoveIconElement(ui.item.last_name, ui.item.last_name, '241');
            li_last_name += ui.item.last_name + '</b></li>';
            
            var li_first_name = "<li id=\"" + ui.item.first_name + "\" ><b>";
			li_first_name += removefuncapp.getAutoCompRemoveIconElement(ui.item.first_name, ui.item.first_name, '250');
            li_first_name += ui.item.first_name + '</b></li>';
            
            var li_email = "<li id=\"" + ui.item.email + "\" ><b>";
			li_email += removefuncapp.getAutoCompRemoveIconElement(ui.item.email, ui.item.email, '260');
			li_email += ui.item.email + '</b></li>';
            

			$('#A_SP_DISP').append(li_last_name).removeClass('hidden');
            $('#A_SP_DISP_F').append(li_first_name).removeClass('hidden');
            $('#A_SP_DISP_E').append(li_email).removeClass('hidden');
			$('#A_SP_INPUT_container').addClass('hidden');
			$('#A_SP_INPUT').attr('_required', 'false');
            $('#Supervisor_section_8').removeClass('hidden');
            $('#h_a_supervisor_lastname').val(ui.item.last_name);
            $('#h_a_supervisor_firstname').val(ui.item.first_name);
            $('#h_a_supervisor_email').val(ui.item.email);
			
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a>' + item.last_name + ', ' + item.first_name +  '</a>')
			.appendTo(ul);
	};

}

var employeeAutoComplete = function () {
   
	$('#A_NAME_INPUT').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchAppointEMP.do?EmpSearch=' + $('#A_NAME_INPUT').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       
                        
						return {
							last_name: $( 'LNAME', this ).text(),
							first_name: $( 'FNAME', this ).text(),
							email: $( 'EMAIL', this ).text(),
                            emp_id: $( 'EMPID', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		/*change: function (e, u) {
			
			if (u.item == null) {
				
				var pos = $(this).position();
				$('#A_NAME_INPUT_noMatch').remove();
				$(this).after("<span id='A_NAME_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#A_NAME_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#A_NAME_INPUT_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},*/
		select: function (event, ui) {
			var li_last_name = "<li id=\"" + ui.item.last_name + "\" ><b>";
			li_last_name += removefuncapp.getAutoCompRemoveIconElement(ui.item.last_name, ui.item.last_name, '21');
            li_last_name += ui.item.last_name + '</b></li>';
            
            var li_first_name = "<li id=\"" + ui.item.first_name + "\" ><b>";
			li_first_name += removefuncapp.getAutoCompRemoveIconElement(ui.item.first_name, ui.item.first_name, '22');
            li_first_name += ui.item.first_name + '</b></li>';
            
            var li_email = "<li id=\"" + ui.item.email + "\" ><b>";
			li_email += removefuncapp.getAutoCompRemoveIconElement(ui.item.email, ui.item.email, '30');
			li_email += ui.item.email + '</b></li>';
            
            
            var li_emid = "<li id=\"" + ui.item.emp_id + "\" ><b>";
			li_emid += removefuncapp.getAutoCompRemoveIconElement(ui.item.emp_id, ui.item.emp_id, '40');
			li_emid += ui.item.emp_id + '</b></li>';

			$('#A_NAME_DISP').append(li_last_name).removeClass('hidden');
            $('#A_NAME_DISP_F').append(li_first_name).removeClass('hidden');
            $('#A_NAME_DISP_E').append(li_email).removeClass('hidden');
            //$('#A_NAME_DISP_I').append(li_emid).removeClass('hidden');
			$('#A_NAME_INPUT_container').addClass('hidden');
			$('#A_NAME_INPUT').attr('_required', 'false');
            $('#A_NAME_INPUT_F_container').addClass('hidden');
        	$('#A_NAME_INPUT_F').attr('_required', 'false');
            $('#A_NAME_INPUT_I').val(ui.item.emp_id);
            if(ui.item.emp_id != ''){
                $('#F_EMP_ID').val(ui.item.emp_id);
            }
            $('#h_a_emp_lastname').val(ui.item.last_name);
            $('#h_a_emp_firstname').val(ui.item.first_name);
            $('#h_a_emp_email').val(ui.item.email);
            $('#h_a_emp_empcode').val('');
			$('#A_CURRENT_NIH_EMPLOYEE').val('Yes');
            $('#A_NAME_INPUT').val('');
            $('#A_NAME_INPUT_F').val('');
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a>' + item.last_name + ', ' + item.first_name +  ' (' + item.emp_id + ')</a>')        
			.appendTo(ul);
	};

}

var removefuncapp = {
    autoCompletionBaseURL: '/bizflowwebmaker/whrsc_AUT/',
    
    getAutoCompRemoveIconElement: function (target, targetDescription, tabIndex) {
        var elementString = '<img src="' + removefuncapp.autoCompletionBaseURL + 'custom/images/delete-icon.png' +
                    '" id="delete-' + target + '" deleteId="' + target +
                    '" title="Remove ' + targetDescription + '" tabindex="' + tabIndex + '" /> ';
        return elementString;
    }
};

