var base_url = '/bizflowwebmaker/whrsc_AUT/';

var appointTransInfo = function(){

	//check manual initiation
	var  from = $('#pv_from').val();
	if(from=='Appointment' || from=='Determine Staffing Process')
	{
		var isInitialLoad = $('#pv_initialLoad').val();
		if(isInitialLoad=="false")
		{
			$('#ACTION_TYPE').val($('#pv_actionType').val());
			
					// Request Date
			var dateReceivedStr = $('#pv_date_received').val();
			if (dateReceivedStr != null && dateReceivedStr.length > 0) {
				var dateReceived = new Date(dateReceivedStr);  // dateReceivedStr is GMT
				var newDate = new Date(dateReceived.getTime() - dateReceived.getTimezoneOffset() * 60000); // Adjust to local time
				var dateReceivedLabel = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
				$('#DATE_RECEIVED').val(dateReceivedLabel);
				$('#DATE_SF52_RECEIVED').val(dateReceivedLabel);
			}			
			$('#HR_SPECIALIST_ID').val($('#h_currentUserMemberID').val());	
			
			$('#pv_initialLoad').val("true");
		}
	}

    
    $('#HR_LLN_INPUT_E_container').addClass('hidden');
	$('#HR_LLN_INPUT_E').attr('_required', 'false');
    
    $('#HR_LLN_INPUT_F_container').addClass('hidden');
	$('#HR_LLN_INPUT_F').attr('_required', 'false');
    
    WHRSCMain.setAlwaysReadonly('ACTION_TYPE');
    $('#ACTION_TYPE').css('background-color', '#efefef');
    
	$('#DATE_SF52_RECEIVED_calendar_anchor').attr('tabindex', 71);
    $('#PROPOSED_EFF_DATE_calendar_anchor').attr('tabindex', 101);
    $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').attr('tabindex', 171);
    $('#MISSING_DOCS_RECEIPT_DATE_calendar_anchor').attr('tabindex', 181);
    
    WHRSCMain.setAlwaysReadonly('DATE_RECEIVED');
    $('#DATE_RECEIVED').css('background-color', '#efefef');
    $('#DATE_RECEIVED_calendar_anchor').addClass('hidden');
    
	if(from!='Appointment') {
		WHRSCMain.setAlwaysReadonly('INSTITUTE');
		$('#INSTITUTE').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('ORG_INITS');
		$('#ORG_INITS').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('ADMIN_CODE');
		$('#ADMIN_CODE').css('background-color', '#efefef');
		
	}

    //$('#ADMIN_CODE').attr('_type', 'text');
	$('#INSTITUTE').attr('_type', 'text');
	$('#ORG_INITS').attr('_type', 'text');
	$('#MISSING_DOCS').attr('_type', 'string');
	$('#COMMENTS_STATUS').attr('_type', 'string');
    
    if ($('#PCKG_COMPLETE').val() == 'No'){
        WHRSCMain.setAlwaysReadonly('MISSING_DOCS_EMAIL_SENT_DATE');
        $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#efefef');
        $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').addClass('hidden');
    }
    
    
    $('#PCKG_COMPLETE').on("change", function(){
        var comSelVal = $(this).children("option:selected").val();
        if (comSelVal == 'Yes') {
            
            $('#MISSING_DOCS_EMAIL_SENT_DATE').removeAttr("readonly");
            $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#FFFFFF');
            $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').removeClass('hidden');
            

        }else{
            
            WHRSCMain.setAlwaysReadonly('MISSING_DOCS_EMAIL_SENT_DATE');
            $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#efefef');
            $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').addClass('hidden');
            $('#MISSING_DOCS_EMAIL_SENT_DATE').val('');
        }
    });
    
    
    //
    if ($('#GLOBAL_RECRUITMENT').val() == 'No'){
		       
        $('#tl_group').addClass('hidden');
        $('#O_STL').val('');
    }
    
    
    
    $('#GLOBAL_RECRUITMENT').on("change", function(){
        var comSelVal = $(this).children("option:selected").val();
        if (comSelVal == 'Yes') {
            
            $('#tl_group').removeClass('hidden');
            

        }else{
            
            $('#tl_group').addClass('hidden');
        	$('#O_STL').val('');
        }
      
    });

	 $('#MISSING_DOCS_RECEIPT_DATE').on("change", function(){
		 var dcpr = $('#MISSING_DOCS_RECEIPT_DATE').val();
        $('#DATE_NEED_VALIDATED').val(dcpr);
    });
    
	var val = $('#BRANCH_CHIEF_ID option:selected').val();
	if(val !='') {
		var uName = $('#BRANCH_CHIEF_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_branchChiefUName').val(uName);
		$('#h_branchChiefName').val(fullName);
		$('#h_branchChief').val('[U]'+ val);
		if($('#h_branchChiefEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#BRANCH_CHIEF_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_branchChiefEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_branchChiefUName').val('');
		$('#h_branchChiefName').val('');
		$('#h_branchChief').val('');
		$('#h_branchChiefEmail').val('');
	}

	$('#BRANCH_CHIEF_ID').on('change', function() {
		var val = $('#BRANCH_CHIEF_ID option:selected').val();
		if(val !='') {
			var uName = $('#BRANCH_CHIEF_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_branchChiefUName').val(uName);
			$('#h_branchChiefName').val(fullName);
			$('#h_branchChief').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#BRANCH_CHIEF_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_branchChiefEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_branchChiefUName').val('');
			$('#h_branchChiefName').val('');
			$('#h_branchChief').val('');
			$('#h_branchChiefEmail').val('');
		}
		
	});

	var val = $('#TEAM_LEADER_ID option:selected').val();
	if(val !='') {
		var uName = $('#TEAM_LEADER_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_teamLeaderUName').val(uName);
		$('#h_teamLeaderName').val(fullName);
		$('#h_teamLeader').val('[U]'+ val);
		if($('#h_teamLeaderEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TEAM_LEADER_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_teamLeaderUName').val('');
		$('#h_teamLeaderName').val('');
		$('#h_teamLeader').val('');
		$('#h_teamLeaderEmail').val('');
	}

	$('#TEAM_LEADER_ID').on('change', function() {
		var val = $('#TEAM_LEADER_ID option:selected').val();
		if(val !='') {
			var uName = $('#TEAM_LEADER_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_teamLeaderUName').val(uName);
			$('#h_teamLeaderName').val(fullName);
			$('#h_teamLeader').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TEAM_LEADER_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_teamLeaderUName').val('');
			$('#h_teamLeaderName').val('');
			$('#h_teamLeader').val('');
			$('#h_teamLeaderEmail').val('');
		}
		
	});

	var val = $('#HR_SENIOR_ADVISOR_ID option:selected').val();
	if(val !='') {
		var uName = $('#HR_SENIOR_ADVISOR_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrSeniorAdvisorUName').val(uName);
		$('#h_hrSeniorAdvisorName').val(fullName);
		$('#h_hrSeniorAdvisor').val('[U]'+ val);
		if($('#h_hrSeniorAdvisorEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SENIOR_ADVISOR_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_hrSeniorAdvisorUName').val('');
		$('#h_hrSeniorAdvisorName').val('');
		$('#h_hrSeniorAdvisor').val('');
		$('#h_hrSeniorAdvisorEmail').val('');
	}
		
	$('#HR_SENIOR_ADVISOR_ID').on('change', function() {
		var val = $('#HR_SENIOR_ADVISOR_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_SENIOR_ADVISOR_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSeniorAdvisorUName').val(uName);
			$('#h_hrSeniorAdvisorName').val(fullName);
			$('#h_hrSeniorAdvisor').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SENIOR_ADVISOR_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_hrSeniorAdvisorUName').val('');
			$('#h_hrSeniorAdvisorName').val('');
			$('#h_hrSeniorAdvisor').val('');
			$('#h_hrSeniorAdvisorEmail').val('');
		}
		
	});

	var val = $('#HR_SPECIALIST_ID option:selected').val();
	if(val !='') {
		var uName = $('#HR_SPECIALIST_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrSpecialistUName').val(uName);
		$('#h_hrSpecialistName').val(fullName);
		$('#h_hrSpecialist').val('[U]'+ val);
		if($('#h_hrSpecialistEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPECIALIST_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_hrSpecialistUName').val('');
		$('#h_hrSpecialistName').val('');
		$('#h_hrSpecialist').val('');
		$('#h_hrSpecialistEmail').val('');
	}


	$('#HR_SPECIALIST_ID').on('change', function() {
		var val = $('#HR_SPECIALIST_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_SPECIALIST_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSpecialistUName').val(uName);
			$('#h_hrSpecialistName').val(fullName);
			$('#h_hrSpecialist').val('[U]'+ val);
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPECIALIST_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_hrSpecialistUName').val('');
			$('#h_hrSpecialistName').val('');
			$('#h_hrSpecialist').val('');
			$('#h_hrSpecialistEmail').val('');
		}
		
	});


	var val = $('#HR_ASSISTANT_ID option:selected').val();
	if(val !='') {
		var uName = $('#HR_ASSISTANT_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrAssistantUName').val(uName);
		$('#h_hrAssistantName').val(fullName);
		$('#h_hrAssistant').val('[U]'+ val);
		if($('#h_hrAssistantEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_ASSISTANT_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrAssistantEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_hrAssistantUName').val('');
		$('#h_hrAssistantName').val('');
		$('#h_hrAssistant').val('');
		$('#h_hrAssistantEmail').val('');
	}

	$('#HR_ASSISTANT_ID').on('change', function() {
		var val = $('#HR_ASSISTANT_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_ASSISTANT_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrAssistantUName').val(uName);
			$('#h_hrAssistantName').val(fullName);
			$('#h_hrAssistant').val('[U]'+ val);
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_ASSISTANT_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrAssistantEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_hrAssistantUName').val('');
			$('#h_hrAssistantName').val('');
			$('#h_hrAssistant').val('');
			$('#h_hrAssistantEmail').val('');
		}
			
	});

	var val = $('#HR_SPA_ID option:selected').val();
	if(val !='') {
		var uName = $('#HR_SPA_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrSpaUName').val(uName);
		$('#h_hrSpaName').val(fullName);
		$('#h_hrSpa').val('[U]'+ val);
		if($('#h_hrSpaEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPA_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpaEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_hrSpaUName').val('');
		$('#h_hrSpaName').val('');
		$('#h_hrSpa').val('');
		$('#h_hrSpaEmail').val('');
	}

	$('#HR_SPA_ID').on('change', function() {
		var val = $('#HR_SPA_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_SPA_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSpaUName').val(uName);
			$('#h_hrSpaName').val(fullName);
			$('#h_hrSpa').val('[U]'+ val);
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPA_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpaEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_hrSpaUName').val('');
			$('#h_hrSpaName').val('');
			$('#h_hrSpa').val('');
			$('#h_hrSpaEmail').val('');
		}
		
	});

	


	setACAutoComplete();
    
    if ($('#h_lastname').val() != '') {
        
        	var li_last_name = "<li id=\"" + $('#h_lastname').val() + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement($('#h_lastname').val(), $('#h_lastname').val(), '51');
            li_last_name += $('#h_lastname').val() + '</b></li>';
            
            var li_first_name = "<li id=\"" + $('#h_firstname').val() + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement($('#h_firstname').val(), $('#h_firstname').val(), '52');
            li_first_name += $('#h_firstname').val() + '</b></li>';
            
            var li_email = "<li id=\"" + $('#h_email').val() + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement($('#h_email').val(), $('#h_email').val(), '53');
			li_email += $('#h_email').val() + '</b></li>';
        
        
		/*var li_org_name = "<li id=\"" + $("#AC_ADMIN_CD").val() + "_dscr\">";
		var li_admin_cd = "<li id=\"" + $("#AC_ADMIN_CD").val() + "\">";
		if ($('#h_readOnly').val() != 'y') {
			li_org_name += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val() + '_dscr', $('#AC_ADMIN_CD_DESCR').val(), '35');
			li_admin_cd += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val(), $('#AC_ADMIN_CD').val(), '25');
		}
		li_admin_cd += $('#AC_ADMIN_CD').val() + '</li>';
		li_org_name += $('#AC_ADMIN_CD_DESCR').val() + '</li>';*/
        
        $('#HR_LLN_DISP').append(li_last_name).removeClass('hidden');
        $('#HR_LLN_DISP_F').append(li_first_name).removeClass('hidden');
        $('#HR_LLN_DISP_E').append(li_email).removeClass('hidden');
        
        $('#HR_LLN_INPUT_container').addClass('hidden');
		$('#HR_LLN_INPUT').attr('_required', 'false');
	}else{
    	$('#HR_LLN_section_8').addClass('hidden');
    }
    
    $('#HR_LLN_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_F').addClass('hidden').empty();
            $('#HR_LLN_DISP_E').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});
    
    $('#HR_LLN_DISP_F').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP_F').addClass('hidden').empty();
            $('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_E').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});

	$('#HR_LLN_DISP_E').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP_E').addClass('hidden').empty();
            $('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_F').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});

}


var setACAutoComplete = function () {
   
	$('#HR_LLN_INPUT').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchLiaison.do?searchLiaison=' + $('#HR_LLN_INPUT').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       
                        
						return {
							//ac_id: $( 'AC_ID', this ).text(),
							last_name: $( 'LNAME', this ).text(),
							first_name: $( 'FNAME', this ).text(),
							email: $( 'EMAIL', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#HR_LLN_INPUT_noMatch').remove();
				$(this).after("<span id='HR_LLN_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#HR_LLN_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#HR_LLN_INPUT_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_last_name = "<li id=\"" + ui.item.last_name + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement(ui.item.last_name, ui.item.last_name, '51');
            li_last_name += ui.item.last_name + '</b></li>';
            
            var li_first_name = "<li id=\"" + ui.item.first_name + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement(ui.item.first_name, ui.item.first_name, '52');
            li_first_name += ui.item.first_name + '</b></li>';
            
            var li_email = "<li id=\"" + ui.item.email + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement(ui.item.email, ui.item.email, '53');
			li_email += ui.item.email + '</b></li>';

			$('#HR_LLN_DISP').append(li_last_name).removeClass('hidden');
            $('#HR_LLN_DISP_F').append(li_first_name).removeClass('hidden');
            $('#HR_LLN_DISP_E').append(li_email).removeClass('hidden');
			$('#HR_LLN_INPUT_container').addClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'false');
            $('#HR_LLN_section_8').removeClass('hidden');
            $('#h_lastname').val(ui.item.last_name);
            $('#h_firstname').val(ui.item.first_name);
            $('#h_email').val(ui.item.email);
			
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a>' + item.last_name + ', ' + item.first_name +  '</a>')
			.appendTo(ul);
	};

}


var removefunc = {
    autoCompletionBaseURL: '/bizflowwebmaker/whrsc_AUT/',
    
    getAutoCompRemoveIconElement: function (target, targetDescription, tabIndex) {
        var elementString = '<img src="' + removefunc.autoCompletionBaseURL + 'custom/images/delete-icon.png' +
                    '" id="delete-' + target + '" deleteId="' + target +
                    '" title="Remove ' + targetDescription + '" tabindex="' + tabIndex + '" /> ';
        return elementString;
    }
};

