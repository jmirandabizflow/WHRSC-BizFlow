var base_url = '/bizflowwebmaker/whrsc_AUT/';
var base_branch_url = '/bizflowwebmaker/whrsc_branchAUT/';

var transInfo = function(){

	//check manual initiation
	var  parentProcess = $('#pv_parentProcessID').val();
	if(parentProcess=='')
	{
		var isInitialLoad = $('#pv_initialLoad').val();
		if(isInitialLoad=="false")
		{
			$('#ACTION_TYPE').val($('#pv_actionType').val());
			
					// Request Date
			var dateReceivedStr = $('#pv_date_received').val();
			if (dateReceivedStr != null && dateReceivedStr.length > 0) {
				var dateReceived = new Date(dateReceivedStr);  // dateReceivedStr is GMT
				var newDate = new Date(dateReceived.getTime() - dateReceived.getTimezoneOffset() * 60000); // Adjust to local time
				var dateReceivedLabel = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
				$('#DATE_RECEIVED').val(dateReceivedLabel);
				$('#TransactionInfo_DateRecv').val(dateReceivedLabel);
			}			
			$('#TransactionInfo_HS').val($('#h_currentUserMemberID').val());	
			
			$('#pv_initialLoad').val("true");
		}
	}
    
    //508 setup
    //$('#ADMIN_CODE').val(addComma1($('#ADMIN_CODE').val()));
    //$('#INSTITUTE').val(addComma1($('#INSTITUTE').val()));
    
    $('#ADMIN_CODE_D').val(addComma1($('#ADMIN_CODE').val()));
    $('#ADMIN_CODE').val($('#ADMIN_CODE').val().replace(/\./g,''));//Temp
    $('#INSTITUTE_D').val(addComma1($('#INSTITUTE').val()));
    $('#INSTITUTE').val($('#INSTITUTE').val().replace(/\./g,''));//Temp
    
    $('#HR_LLN_INPUT_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_LLN_INPUT_F_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_LLN_INPUT_E_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_GR_label').attr('title', 'Asterisk denotes a required field');
    //$('#TransactionInfo_DateRecv_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_DateRecv_label').attr('title', 'mm/dd/yyyy');
    $('#ADMIN_CODE_label').attr('title', 'Asterisk denotes a required field');
    $('#INSTITUTE_label').attr('title', 'Asterisk denotes a required field');
    $('#ADMIN_CODE_D_label').attr('title', 'Asterisk denotes a required field');
    $('#INSTITUTE_D_label').attr('title', 'Asterisk denotes a required field');
    //$('#TransactionInfo_PED_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_PED_label').attr('title', 'mm/dd/yyyy');
    $('#TransactionInfo_BC_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_TL_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_SA_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_HS_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_HA_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_FA_label').attr('title', 'Asterisk denotes a required field');
    $('#PCKG_COMPLETE_label').attr('title', 'Asterisk denotes a required field');
    $('#PRIORITY_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_ASC_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_ActionStatus_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_ASD_label').attr('title', 'Asterisk denotes a required field');
    $('#TransactionInfo_DCPR_label').attr('title', 'mm/dd/yyyy');

    
    $('#HR_LLN_INPUT_E_container').addClass('hidden');
	$('#HR_LLN_INPUT_E').attr('_required', 'false');
    
    $('#HR_LLN_INPUT_F_container').addClass('hidden');
	$('#HR_LLN_INPUT_F').attr('_required', 'false');
    
    WHRSCMain.setAlwaysReadonly('ACTION_TYPE');
    $('#ACTION_TYPE').css('background-color', '#efefef');
    
    $('#TransactionInfo_DateRecv_calendar_anchor').attr('tabindex', 71);
    $('#TransactionInfo_PED_calendar_anchor').attr('tabindex', 101);
    $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').attr('tabindex', 171);
    $('#TransactionInfo_DCPR_calendar_anchor').attr('tabindex', 181);
    
    WHRSCMain.setAlwaysReadonly('DATE_RECEIVED');
    $('#DATE_RECEIVED').css('background-color', '#efefef');
    $('#DATE_RECEIVED_calendar_anchor').addClass('hidden');
    
	if(parentProcess!='') {
		/*WHRSCMain.setAlwaysReadonly('INSTITUTE');
		$('#INSTITUTE').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('ORG_INITS');
		$('#ORG_INITS').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('ADMIN_CODE');
		$('#ADMIN_CODE').css('background-color', '#efefef');*/
        
        WHRSCMain.setAlwaysReadonly('INSTITUTE_D');
		$('#INSTITUTE_D').css('background-color', '#efefef');
        $('#INSTITUTE_container').addClass('hidden');
        $('#INSTITUTE_label_container').addClass('hidden');
		
        WHRSCMain.setAlwaysReadonly('ORG_INITS');
		$('#ORG_INITS').css('background-color', '#efefef');
        
		WHRSCMain.setAlwaysReadonly('ADMIN_CODE_D');
		$('#ADMIN_CODE_D').css('background-color', '#efefef');
        $('#ADMIN_CODE_container').addClass('hidden');
        $('#ADMIN_CODE_label_container').addClass('hidden');

	}else{
    	$('#INSTITUTE_D_container').addClass('hidden');
        $('#INSTITUTE_D_label_container').addClass('hidden');
        
        $('#ADMIN_CODE_D_container').addClass('hidden');
        $('#ADMIN_CODE_D_label_container').addClass('hidden');
    }

    //$('#ADMIN_CODE').attr('_type', 'text');
	$('#INSTITUTE').attr('_type', 'text');
	$('#ORG_INITS').attr('_type', 'text');
	$('#MISSING_DOCS').attr('_type', 'string');
	$('#COMMENTS_STATUS').attr('_type', 'string');
    
    //if ($('#PCKG_COMPLETE').val() == 'No'){
        WHRSCMain.setAlwaysReadonly('MISSING_DOCS_EMAIL_SENT_DATE');
        $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#efefef');
        $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').addClass('hidden');
    //}
    
    
    /*$('#PCKG_COMPLETE').on("change", function(){
        var comSelVal = $(this).children("option:selected").val();
        if (comSelVal == 'Yes') {
            
            $('#MISSING_DOCS_EMAIL_SENT_DATE').removeAttr("readonly");
            $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#FFFFFF');
            $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').removeClass('hidden');
            

        }else{
            
            WHRSCMain.setAlwaysReadonly('MISSING_DOCS_EMAIL_SENT_DATE');
            $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#efefef');
            $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').addClass('hidden');
            $('#MISSING_DOCS_EMAIL_SENT_DATE').val('');
        }
    });*/

	var branchName = $('#h_branch').val();
	var bcUgPath = '/WHRSC/Role Specific/Branch Chief/' + branchName;
	var tlUgPath = '/WHRSC/Role Specific/HR Team Leader/' + branchName;
	var saUgPath = '/WHRSC/Role Specific/HR Senior Advisor/' + branchName;
	var hsUgPath = '/WHRSC/Role Specific/HR Specialist/' + branchName;

	$.ajax({
		url: base_branch_url + 'getBranchHS.do?branchhs=' + hsUgPath,
		dataType: 'xml',
		cache: false,
		success: function (xmlResponse) {
			var hs_id = $('#hs_id').val();
			$('#TransactionInfo_HS').empty();
			$('#TransactionInfo_HS').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#TransactionInfo_HS').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				 if (hs_id !== undefined && hs_id !== '') {
					$('#TransactionInfo_HS').val(hs_id);
				 }
			}).get();
			
		}
	});	
	$.ajax({
		url: base_branch_url + 'getBranchBC.do?branchbc=' + bcUgPath,
		dataType: 'xml',
		cache: false,
		success: function (xmlResponse) {
			var bc_id = $('#bc_id').val();
			$('#TransactionInfo_BC').empty();
			$('#TransactionInfo_BC').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#TransactionInfo_BC').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				 if (bc_id !== undefined && bc_id !== '') {
					$('#TransactionInfo_BC').val(bc_id);
				 }
			}).get();
			
		}
	});	
	$.ajax({
		url: base_branch_url + 'getBranchTL.do?branchtl=' + tlUgPath,
		dataType: 'xml',
		cache: false,
		success: function (xmlResponse) {
			var tl_id = $('#tl_id').val();
			$('#TransactionInfo_TL').empty();
			$('#TransactionInfo_TL').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#TransactionInfo_TL').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				 if (tl_id !== undefined && tl_id !== '') {
					$('#TransactionInfo_TL').val(tl_id);
				 }
			}).get();
			
		}
	});	
	$.ajax({
		url: base_branch_url + 'getBranchSA.do?branchsa=' + saUgPath,
		dataType: 'xml',
		cache: false,
		success: function (xmlResponse) {
			var sa_id = $('#sa_id').val();
			$('#TransactionInfo_SA').empty();
			$('#TransactionInfo_SA').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#TransactionInfo_SA').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				 if (sa_id !== undefined && sa_id !== '') {
					$('#TransactionInfo_SA').val(sa_id);
				 }
			}).get();
			
		}
	});	
	
	
	$('#TransactionInfo_GR').on("change", function(){
		var selVal = $(this).children("option:selected").val();
		
		if (selVal == 'Yes') {
			$('#h_branch').val("SSB");
			$.ajax({
				url: base_branch_url + 'getBranchHS.do?branchhs=' + "/WHRSC/Role Specific/HR Specialist/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_HS').empty();
					$('#TransactionInfo_HS').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_HS').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			$.ajax({
				url: base_branch_url + 'getBranchBC.do?branchbc=' + "/WHRSC/Role Specific/Branch Chief/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_BC').empty();
					$('#TransactionInfo_BC').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_BC').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			$.ajax({
				url: base_branch_url + 'getBranchTL.do?branchtl=' + "/WHRSC/Role Specific/HR Team Leader/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_TL').empty();
					$('#TransactionInfo_TL').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_TL').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			$.ajax({
				url: base_branch_url + 'getBranchSA.do?branchsa=' +  "/WHRSC/Role Specific/HR Senior Advisor/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_SA').empty();
					$('#TransactionInfo_SA').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_SA').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			
		}
		
		else {
			var orgBranch = $('#h_originalBranch').val();
			$('#h_branch').val(orgBranch);
			$.ajax({
				url: base_branch_url + 'getBranchHS.do?branchhs=' + '/WHRSC/Role Specific/HR Specialist/' + orgBranch, 
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_HS').empty();
					$('#TransactionInfo_HS').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_HS').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			$.ajax({
				url: base_branch_url + 'getBranchBC.do?branchbc=' + '/WHRSC/Role Specific/Branch Chief/' + orgBranch, 
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_BC').empty();
					$('#TransactionInfo_BC').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_BC').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			
			$.ajax({
				url: base_branch_url + 'getBranchTL.do?branchtl=' + '/WHRSC/Role Specific/HR Team Leader/' + orgBranch, 
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_TL').empty();
					$('#TransactionInfo_TL').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_TL').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			$.ajax({
				url: base_branch_url + 'getBranchSA.do?branchsa=' +  '/WHRSC/Role Specific/HR Senior Advisor/' + orgBranch, 
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TransactionInfo_SA').empty();
					$('#TransactionInfo_SA').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TransactionInfo_SA').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
		}
		
	});
	
	 $('#TransactionInfo_DCPR').on("change", function(){
		 var dcpr = $('#TransactionInfo_DCPR').val();
        $('#DATE_NEED_VALIDATED').val(dcpr);
    });
    
	var val = $('#TransactionInfo_BC option:selected').val();
	//var val = $('#TransactionInfo_BC').val();
	if(val !='') {
		var uName = $('#TransactionInfo_BC option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_branchChiefUName').val(uName);
		$('#h_branchChiefName').val(fullName);
		$('#h_branchChief').val('[U]'+ val);
		if($('#h_branchChiefEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_BC').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_branchChiefEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_branchChiefUName').val('');
		$('#h_branchChiefName').val('');
		$('#h_branchChief').val('');
		$('#h_branchChiefEmail').val('');
	}

	$('#TransactionInfo_BC').on('change', function() {
		var val = $('#TransactionInfo_BC option:selected').val();
		if(val !='') {
			var uName = $('#TransactionInfo_BC option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_branchChiefUName').val(uName);
			$('#h_branchChiefName').val(fullName);
			$('#h_branchChief').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_BC').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_branchChiefEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_branchChiefUName').val('');
			$('#h_branchChiefName').val('');
			$('#h_branchChief').val('');
			$('#h_branchChiefEmail').val('');
		}
		
	});
	/*
	$('#h_branchChiefName').val( $('#TransactionInfo_BC option:selected').text());
  	$('#TransactionInfo_BC').on('change', function() {
		var txt = $('#TransactionInfo_BC option:selected').text();
		$('#h_branchChiefName').val(txt);
	});
    */
	
	var val = $('#TransactionInfo_TL option:selected').val();
	//var val = $('#TransactionInfo_TL').val();
	if(val !='') {
		var uName = $('#TransactionInfo_TL option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_teamLeaderUName').val(uName);
		$('#h_teamLeaderName').val(fullName);
		$('#h_teamLeader').val('[U]'+ val);
		if($('#h_teamLeaderEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_TL').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_teamLeaderUName').val('');
		$('#h_teamLeaderName').val('');
		$('#h_teamLeader').val('');
		$('#h_teamLeaderEmail').val('');
	}

	$('#TransactionInfo_TL').on('change', function() {
		var val = $('#TransactionInfo_TL option:selected').val();
		if(val !='') {
			var uName = $('#TransactionInfo_TL option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_teamLeaderUName').val(uName);
			$('#h_teamLeaderName').val(fullName);
			$('#h_teamLeader').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_TL').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_teamLeaderUName').val('');
			$('#h_teamLeaderName').val('');
			$('#h_teamLeader').val('');
			$('#h_teamLeaderEmail').val('');
		}
		
	});
	/*
	$('#h_teamLeaderName').val($('#TransactionInfo_TL option:selected').text());
	if($('#TransactionInfo_TL option:selected').val() !='')
	{
		$.ajax({
			url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_TL').val(),
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				var data = $('record', xmlResponse ).map(function() {
					$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
				}).get();
				
			}
		});
	}
	$('#TransactionInfo_TL').on('change', function() {
		var txt = $('#TransactionInfo_TL option:selected').text();
		$('#h_teamLeaderName').val(txt);
		$.ajax({
			url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_TL').val(),
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				var data = $('record', xmlResponse ).map(function() {
					$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
				}).get();
				
			}
		});
	});
	*/
	
	var val = $('#TransactionInfo_SA option:selected').val();
	//var val = $('#TransactionInfo_SA').val();
	if(val !='') {
		var uName = $('#TransactionInfo_SA option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrSeniorAdvisorUName').val(uName);
		$('#h_hrSeniorAdvisorName').val(fullName);
		$('#h_hrSeniorAdvisor').val('[U]'+ val);
		if($('#h_hrSeniorAdvisorEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_SA').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_hrSeniorAdvisorUName').val('');
		$('#h_hrSeniorAdvisorName').val('');
		$('#h_hrSeniorAdvisor').val('');
		$('#h_hrSeniorAdvisorEmail').val('');
	}
		
	$('#TransactionInfo_SA').on('change', function() {
		var val = $('#TransactionInfo_SA option:selected').val();
		if(val !='') {
			var uName = $('#TransactionInfo_SA option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSeniorAdvisorUName').val(uName);
			$('#h_hrSeniorAdvisorName').val(fullName);
			$('#h_hrSeniorAdvisor').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_SA').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_hrSeniorAdvisorUName').val('');
			$('#h_hrSeniorAdvisorName').val('');
			$('#h_hrSeniorAdvisor').val('');
			$('#h_hrSeniorAdvisorEmail').val('');
		}
		
	});

	/*
		$('#h_hrSeniorAdvisorName').val($('#TransactionInfo_SA option:selected').text());
	if($('#TransactionInfo_SA option:selected').val()!='') {
		$('#h_hrSeniorAdvisor').val('[U]'+$('#TransactionInfo_SA option:selected').val());
		$.ajax({
			url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_SA').val(),
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				var data = $('record', xmlResponse ).map(function() {
					$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
				}).get();
				
			}
		});
	} 
	$('#TransactionInfo_SA').on('change', function() {
		if($('#TransactionInfo_SA option:selected').val()!='') {
			var txt = $('#TransactionInfo_SA option:selected').text();
			$('#h_hrSeniorAdvisorName').val(txt);
			var val = $('#TransactionInfo_SA option:selected').val();
			var hssa = '[U]'+ val;
			$('#h_hrAssistance').val(hssa);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_SA').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});
		}
	});
	*/
	
	var val = $('#TransactionInfo_HS option:selected').val();
	//var val = $('#TransactionInfo_HS').val();
	if(val !='') {
		var uName = $('#TransactionInfo_HS option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrSpecialistUName').val(uName);
		$('#h_hrSpecialistName').val(fullName);
		$('#h_hrSpecialist').val('[U]'+ val);
		if($('#h_hrSpecialistEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_HS').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_hrSpecialistUName').val('');
		$('#h_hrSpecialistName').val('');
		$('#h_hrSpecialist').val('');
		$('#h_hrSpecialistEmail').val('');
	}


	$('#TransactionInfo_HS').on('change', function() {
		var val = $('#TransactionInfo_HS option:selected').val();
		if(val !='') {
			var uName = $('#TransactionInfo_HS option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSpecialistUName').val(uName);
			$('#h_hrSpecialistName').val(fullName);
			$('#h_hrSpecialist').val('[U]'+ val);
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_HS').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_hrSpecialistUName').val('');
			$('#h_hrSpecialistName').val('');
			$('#h_hrSpecialist').val('');
			$('#h_hrSpecialistEmail').val('');
		}
		
	});

	/*
	var fullName = utility.getFirstLastName( $('#TransactionInfo_HS option:selected').text());
	$('#h_hrSpecialistName').val(fullName);


	if($('#TransactionInfo_HS option:selected').val() !='') {
		$('#h_hrSpecialist').val('[U]'+$('#TransactionInfo_HS option:selected').val());

		$.ajax({
			url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_HS').val(),
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				var data = $('record', xmlResponse ).map(function() {
					$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
				}).get();
				
			}
		});
	} 
	$('#TransactionInfo_HS').on('change', function() {
		if($('#TransactionInfo_HS option:selected').val() !='') {
			//var txt = $('#TransactionInfo_HS option:selected').text();
			//$('#h_hrSpecialistName').val(txt);
			var fullName = utility.getFirstLastName( $('#TransactionInfo_HS option:selected').text());
			$('#h_hrSpecialistName').val(fullName);

			var val = $('#TransactionInfo_HS option:selected').val();
			var hsSp = '[U]'+ val;
			$('#h_hrSpecialist').val(hsSp);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_HS').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
					}).get();
				}
			});
		}
	});
	*/

	$('#h_hrAssistanceName').val($('#TransactionInfo_HA option:selected').text());
	if($('#TransactionInfo_HA option:selected').val()!='') {
		$('#h_hrAssistance').val('[U]'+$('#TransactionInfo_HA option:selected').val());

		$.ajax({
			url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_HA').val(),
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				var data = $('record', xmlResponse ).map(function() {
					$('#h_hrAssistanceEmail').val($( 'EMAIL', this ).text());
				}).get();
				
			}
		});
	} 
	$('#TransactionInfo_HA').on('change', function() {
		if($('#TransactionInfo_HA option:selected').val()!='') {
			var txt = $('#TransactionInfo_HA option:selected').text();
			$('#h_hrAssistanceName').val(txt);
			var val = $('#TransactionInfo_HA option:selected').val();
			var hsha = '[U]'+ val;
			$('#h_hrAssistance').val(hsha);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TransactionInfo_HA').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrAssistanceEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});
		}
	});



	$('#h_hrFinalAuthorizerName').val($('#TransactionInfo_FA option:selected').text());
	$('#TransactionInfo_FA').on('change', function() {
		var txt = $('#TransactionInfo_FA option:selected').text();
		$('#h_hrFinalAuthorizerName').val(txt);
	});

	setACAutoComplete();
    
    if ($('#h_lastname').val() != '') {
        
        	var li_last_name = "<li id=\"" + $('#h_lastname').val() + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement($('#h_lastname').val(), $('#h_lastname').val(), '51');
            li_last_name += $('#h_lastname').val() + '</b></li>';
            
            var li_first_name = "<li id=\"" + $('#h_firstname').val() + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement($('#h_firstname').val(), $('#h_firstname').val(), '52');
            li_first_name += $('#h_firstname').val() + '</b></li>';
            
            var li_email = "<li id=\"" + $('#h_email').val() + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement($('#h_email').val(), $('#h_email').val(), '53');
			li_email += $('#h_email').val() + '</b></li>';
        
        
		/*var li_org_name = "<li id=\"" + $("#AC_ADMIN_CD").val() + "_dscr\">";
		var li_admin_cd = "<li id=\"" + $("#AC_ADMIN_CD").val() + "\">";
		if ($('#h_readOnly').val() != 'y') {
			li_org_name += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val() + '_dscr', $('#AC_ADMIN_CD_DESCR').val(), '35');
			li_admin_cd += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val(), $('#AC_ADMIN_CD').val(), '25');
		}
		li_admin_cd += $('#AC_ADMIN_CD').val() + '</li>';
		li_org_name += $('#AC_ADMIN_CD_DESCR').val() + '</li>';*/
        
        $('#HR_LLN_DISP').append(li_last_name).removeClass('hidden');
        $('#HR_LLN_DISP_F').append(li_first_name).removeClass('hidden');
        $('#HR_LLN_DISP_E').append(li_email).removeClass('hidden');
        
        $('#HR_LLN_INPUT_container').addClass('hidden');
		$('#HR_LLN_INPUT').attr('_required', 'false');
	}else{
    	$('#HR_LLN_section_8').addClass('hidden');
    }
    
    $('#HR_LLN_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_F').addClass('hidden').empty();
            $('#HR_LLN_DISP_E').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});
    
    $('#HR_LLN_DISP_F').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP_F').addClass('hidden').empty();
            $('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_E').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});

	$('#HR_LLN_DISP_E').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP_E').addClass('hidden').empty();
            $('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_F').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});

}


var setACAutoComplete = function () {
   
	$('#HR_LLN_INPUT').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchLiaison.do?searchLiaison=' + $('#HR_LLN_INPUT').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       
                        
						return {
							//ac_id: $( 'AC_ID', this ).text(),
							last_name: $( 'LNAME', this ).text(),
							first_name: $( 'FNAME', this ).text(),
							email: $( 'EMAIL', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#HR_LLN_INPUT_noMatch').remove();
				$(this).after("<span id='HR_LLN_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#HR_LLN_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#HR_LLN_INPUT_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_last_name = "<li id=\"" + ui.item.last_name + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement(ui.item.last_name, ui.item.last_name, '51');
            li_last_name += ui.item.last_name + '</b></li>';
            
            var li_first_name = "<li id=\"" + ui.item.first_name + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement(ui.item.first_name, ui.item.first_name, '52');
            li_first_name += ui.item.first_name + '</b></li>';
            
            var li_email = "<li id=\"" + ui.item.email + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement(ui.item.email, ui.item.email, '53');
			li_email += ui.item.email + '</b></li>';

			$('#HR_LLN_DISP').append(li_last_name).removeClass('hidden');
            $('#HR_LLN_DISP_F').append(li_first_name).removeClass('hidden');
            $('#HR_LLN_DISP_E').append(li_email).removeClass('hidden');
			$('#HR_LLN_INPUT_container').addClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'false');
            $('#HR_LLN_section_8').removeClass('hidden');
            $('#h_lastname').val(ui.item.last_name);
            $('#h_firstname').val(ui.item.first_name);
            $('#h_email').val(ui.item.email);
			
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.last_name + ', ' + item.first_name + '">' + item.last_name + ', ' + item.first_name +  '</a>')
			.appendTo(ul);
	};

}

function addComma1(fieldval){
    fieldval = fieldval.replace(/\./g,'');
	var chstr = fieldval.split('');
    var ctext = '';
        
    for ( var i in chstr ) {
     ctext += chstr[i] + '.';
    }
    
    return ctext;
}

var removefunc = {
    autoCompletionBaseURL: '/bizflowwebmaker/whrsc_AUT/',
    
    getAutoCompRemoveIconElement: function (target, targetDescription, tabIndex) {
        var elementString = '<img src="' + removefunc.autoCompletionBaseURL + 'custom/images/delete-icon.png' +
                    '" id="delete-' + target + '" deleteId="' + target +
                    '" title="Remove ' + targetDescription + '" tabindex="' + tabIndex + '" /> ';
        return elementString;
    }
};

