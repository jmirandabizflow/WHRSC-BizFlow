var appointApprovals = function(){

	WHRSCMain.setAlwaysReadonly('AP_DATE_DEU_DECISION');    
    $('#AP_DATE_DEU_DECISION').css('background-color', '#efefef');
    $('#AP_DATE_DEU_DECISION_calendar_anchor').addClass('hidden');
    
    $('#AP_ADD_DEU_SEL_INFO').attr('_type', 'string');
    $('#AP_DEU_SEL_DECISION_COM').attr('_type', 'string');
    
    $('#hidden_group_1').addClass('hidden');
    $('#hidden_group_2').addClass('hidden');
    $('#deu_sel_group').addClass('hidden');
    
    //508
    $('#AP_DATE_RELEASE_REQEST_label').attr('title', 'mm/dd/yyyy');
    $('#AP_APPRO_RELE_DATE_label').attr('title', 'mm/dd/yyyy');
    
    $('#AP_DATE_PKG_SENT_calendar_anchor').attr('tabindex', 21);
    $('#AP_DATE_APP_DEC_REC_calendar_anchor').attr('tabindex', 41);
    $('#AP_DATE_DEU_DECISION_calendar_anchor').attr('tabindex', 81);
    $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').attr('tabindex', 141);
    $('#AP_APPRO_RELE_DATE_calendar_anchor').attr('tabindex', 221);
    $('#AP_DATE_RELEASE_REQEST_calendar_anchor').attr('tabindex', 201);
    $('#AP_FIC_APRO_DATE_calendar_anchor').attr('tabindex', 241);
    $('#AP_VISA_EFFECT_DATE_calendar_anchor').attr('tabindex', 281);
    $('#AP_VISA_EXPIR_DATE_calendar_anchor').attr('tabindex', 301);
    
  
    var actName = WHRSCMain.activityOption.getActivityName();
	//alert (actName);
       if(actName!="DEU Reviews") {

            WHRSCMain.setAlwaysReadonly('AP_DATE_DEU_SEL_DECISION');
            $('#AP_DATE_DEU_SEL_DECISION').css('background-color', '#efefef');
            $('#AP_DATE_DEU_SEL_DECISION').css('width', 400);
            $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').addClass('hidden');
           
            WHRSCMain.setAlwaysReadonly('AP_DEU_SEL_DECISION_COM');
            $('#AP_DEU_SEL_DECISION_COM').css('background-color', '#efefef');
             
           //$('#A_CERTIFICATE_NO').children().remove();
           var tmpseldec = $('#AP_DEU_SEL_DECISION').val();
           WHRSCMain.setAlwaysReadonly('AP_DEU_SEL_DECISION');
           $('#AP_DEU_SEL_DECISION').css('background-color', '#efefef');
           $('#AP_DEU_SEL_DECISION').empty();
           $('#AP_DEU_SEL_DECISION').append('<option value=' + tmpseldec + '>' + tmpseldec + '</option>');
           
           if(tmpseldec == 'Return for Additional Action') {
               
               $('#deu_sel_group').removeClass('hidden');
               
               WHRSCMain.setAlwaysReadonly('AP_ADD_DEU_SEL_INFO');
                $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#efefef');
                
            }
                     
           WHRSCMain.setAlwaysReadonly('AP_ADD_DEU_SEL_INFO');
            $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#efefef');

       }else{
           $('#deu_sel_group').removeClass('hidden');
           //alert ($('#AP_DEU_SEL_DECISION').val());
       		if ($('#AP_DEU_SEL_DECISION').val() == 'Approved' || $('#AP_DEU_SEL_DECISION').val() == 'Disapproved'){
            	$('#AP_DATE_DEU_SEL_DECISION').removeAttr("readonly");
                $('#AP_DATE_DEU_SEL_DECISION').css('background-color', '#ffffff');
                $('#AP_DATE_DEU_SEL_DECISION').css('width', 366);
                $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').removeClass('hidden');
                
                WHRSCMain.setAlwaysReadonly('AP_ADD_DEU_SEL_INFO');
                $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#efefef');
            
            }else if($('#AP_DEU_SEL_DECISION').val() == 'Return for Additional Action'){
                $('#AP_ADD_DEU_SEL_INFO').removeAttr("readonly");
                $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#ffffff');
                
                WHRSCMain.setAlwaysReadonly('AP_DATE_DEU_SEL_DECISION');
                $('#AP_DATE_DEU_SEL_DECISION').css('background-color', '#efefef');
                $('#AP_DATE_DEU_SEL_DECISION').css('width', 400);
                $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').addClass('hidden');
                
           
            }else{
                WHRSCMain.setAlwaysReadonly('AP_ADD_DEU_SEL_INFO');
                $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#efefef');
                
            	WHRSCMain.setAlwaysReadonly('AP_DATE_DEU_SEL_DECISION');
                $('#AP_DATE_DEU_SEL_DECISION').css('background-color', '#efefef');
                $('#AP_DATE_DEU_SEL_DECISION').css('width', 400);
                $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').addClass('hidden');
                
            }
       }
    
    $('#AP_DEU_SEL_DECISION').on('change',function() {
        
        var deusel = $(this).children("option:selected").val();
        
        	if (deusel == 'Approved' || deusel == 'Disapproved'){
                WHRSCMain.setAlwaysReadonly('AP_ADD_DEU_SEL_INFO');
                $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#efefef');
                
            	$('#AP_DATE_DEU_SEL_DECISION').removeAttr("readonly");
                $('#AP_DATE_DEU_SEL_DECISION').css('background-color', '#ffffff');
                $('#AP_DATE_DEU_SEL_DECISION').css('width', 366);
                $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').removeClass('hidden');
            
            }else if(deusel == 'Return for Additional Action') {
                $('#AP_ADD_DEU_SEL_INFO').removeAttr("readonly");
                $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#ffffff');
                
            	WHRSCMain.setAlwaysReadonly('AP_DATE_DEU_SEL_DECISION');
                $('#AP_DATE_DEU_SEL_DECISION').css('background-color', '#efefef');
                $('#AP_DATE_DEU_SEL_DECISION').css('width', 400);
                $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').addClass('hidden');
                $('#AP_DATE_DEU_SEL_DECISION').val('');
            }else{
                WHRSCMain.setAlwaysReadonly('AP_ADD_DEU_SEL_INFO');
                $('#AP_ADD_DEU_SEL_INFO').css('background-color', '#efefef');
                
            	WHRSCMain.setAlwaysReadonly('AP_DATE_DEU_SEL_DECISION');
                $('#AP_DATE_DEU_SEL_DECISION').css('background-color', '#efefef');
                $('#AP_DATE_DEU_SEL_DECISION').css('width', 400);
                $('#AP_DATE_DEU_SEL_DECISION_calendar_anchor').addClass('hidden');
                $('#AP_DATE_DEU_SEL_DECISION').val('');
            }
        
    });
	
	var val = $('#AP_DEU_SEL_APPROVER option:selected').val();
	if(val !='') {
		var uName = $('#AP_DEU_SEL_APPROVER option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrDeSelApproverUName').val(uName);
		$('#h_hrDeSelApproverName').val(fullName);
		$('#h_hrDeSelApprover').val('[U]'+ val);
		if($('#h_hrDeSelApproverEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#AP_DEU_SEL_APPROVER').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrDeSelApproverEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
	}
	else {
		$('#h_hrDeSelApproverUName').val('');
		$('#h_hrDeSelApproverName').val('');
		$('#h_hrDeSelApprover').val('');
		$('#h_hrDeSelApproverEmail').val('');
	}

	$('#AP_DEU_SEL_APPROVER').on('change', function() {
		var val = $('#AP_DEU_SEL_APPROVER option:selected').val();
		if(val !='') {
			var uName = $('#AP_DEU_SEL_APPROVER option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrDeSelApproverUName').val(uName);
			$('#h_hrDeSelApproverName').val(fullName);
			$('#h_hrDeSelApprover').val('[U]'+ val);
			
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#AP_DEU_SEL_APPROVER').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrDeSelApproverEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		else {
			$('#h_hrDeSelApproverUName').val('');
			$('#h_hrDeSelApproverName').val('');
			$('#h_hrDeSelApprover').val('');
			$('#h_hrDeSelApproverEmail').val('');
		}
		
	});
                                

}