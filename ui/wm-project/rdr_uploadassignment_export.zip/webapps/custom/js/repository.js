var base_url = '/bizflowwebmaker/whrsc_AUT/';
var recruitDocRepository = function(){

	LookupManager.init();
    
    $('#hidden_group').addClass('hidden');
    	hyf.util.hideComponent('tab_control_tab_tab2', null, null, null);
        hyf.util.hideComponent('tab_control_tab_tab1', null, null, null);
    	searchForRdr();
    
    /*if ($('#h_Activity_name').val() == 'Initial Upload'){
        
        	hyf.util.hideComponent('tab_control_tab_tab2', null, null, null);
        	hyf.util.hideComponent('tab_control_tab_tab1', null, null, null);
    }else{
        
    }*/
    
    $('#AP_PROGRAM').prop('readonly','true');
	$('#AP_PROGRAM').attr('alwaysReadonly','true');
    $('#AP_PROGRAM').css('background-color', '#efefef');
    //$('#AP_PROGRAM').val('ACF');
    //
    $('#R_PROGRAM').on("change", function(){
        $('#AP_PROGRAM').val($('#R_PROGRAM option:selected').val());
    });
    
	utility.multiSelectFD('R_GRADE',0);
	$("input[type=checkbox][name=R_GRADE_M]").trigger("change");
    
   
    
    /*utility.multiSelectFD('AP_APPROVER1',1);
	$("input[type=checkbox][name=AP_APPROVER1_M]").trigger("change");
    $('#level_button_1').on("click", function(){
  		$('#approver_group_2').removeClass('hidden');
        $('#level_button_1').addClass('hidden');
    });
    
    

    $('#approver_group_2').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER2',0);
	$("input[type=checkbox][name=AP_APPROVER2_M]").trigger("change");
    $('#level_button_2').on("click", function(){
          $('#approver_group_3').removeClass('hidden');
        $('#level_button_2').addClass('hidden');
        $('#delete_button_2').addClass('hidden');
    });
    $('#delete_button_2').on("click", function(){
         $('#approver_group_2').addClass('hidden');
        $('#level_button_1').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER2_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER2 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER2_M' + ij).attr('checked',false); 
		}
    });
    
    $('#approver_group_3').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER3',0);
	$("input[type=checkbox][name=AP_APPROVER3_M]").trigger("change");
    $('#level_button_3').on("click", function(){
          $('#approver_group_4').removeClass('hidden');
        $('#level_button_3').addClass('hidden');
        $('#delete_button_3').addClass('hidden');
    });
    $('#delete_button_3').on("click", function(){
         $('#approver_group_3').addClass('hidden');
        $('#level_button_2').removeClass('hidden');
        $('#delete_button_2').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER3_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER3 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER3_M' + ij).attr('checked',false); 
		}
    });
    
    
    $('#approver_group_4').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER4',0);
	$("input[type=checkbox][name=AP_APPROVER4_M]").trigger("change");
    $('#level_button_4').on("click", function(){
          $('#approver_group_5').removeClass('hidden');
        $('#level_button_4').addClass('hidden');
        $('#delete_button_4').addClass('hidden');
    });
    $('#delete_button_4').on("click", function(){
         $('#approver_group_4').addClass('hidden');
        $('#level_button_3').removeClass('hidden');
        $('#delete_button_3').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER4_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER4 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER4_M' + ij).attr('checked',false); 
		}
    });
    
    $('#approver_group_5').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER5',0);
	$("input[type=checkbox][name=AP_APPROVER5_M]").trigger("change");
    $('#level_button_5').on("click", function(){
          $('#approver_group_6').removeClass('hidden');
        $('#level_button_5').addClass('hidden');
        $('#delete_button_5').addClass('hidden');
    });
    $('#delete_button_5').on("click", function(){
         $('#approver_group_5').addClass('hidden');
        $('#level_button_4').removeClass('hidden');
        $('#delete_button_4').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER5_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER5 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER5_M' + ij).attr('checked',false); 
		}
    });
    
    $('#approver_group_6').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER6',0);
	$("input[type=checkbox][name=AP_APPROVER6_M]").trigger("change");
    $('#level_button_6').on("click", function(){
          $('#approver_group_7').removeClass('hidden');
        $('#level_button_6').addClass('hidden');
        $('#delete_button_6').addClass('hidden');
    });
    $('#delete_button_6').on("click", function(){
         $('#approver_group_6').addClass('hidden');
        $('#level_button_5').removeClass('hidden');
        $('#delete_button_5').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER6_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER6 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER6_M' + ij).attr('checked',false); 
		}
    });
    
    $('#approver_group_7').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER7',0);
	$("input[type=checkbox][name=AP_APPROVER7_M]").trigger("change");
    $('#level_button_7').on("click", function(){
          $('#approver_group_8').removeClass('hidden');
        $('#level_button_7').addClass('hidden');
        $('#delete_button_7').addClass('hidden');
    });
    $('#delete_button_7').on("click", function(){
         $('#approver_group_7').addClass('hidden');
        $('#level_button_6').removeClass('hidden');
        $('#delete_button_6').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER7_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER7 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER7_M' + ij).attr('checked',false); 
		}
    });
    
    $('#approver_group_8').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER8',0);
	$("input[type=checkbox][name=AP_APPROVER8_M]").trigger("change");
    $('#level_button_8').on("click", function(){
          $('#approver_group_9').removeClass('hidden');
        $('#level_button_8').addClass('hidden');
        $('#delete_button_8').addClass('hidden');
    });
    $('#delete_button_8').on("click", function(){
         $('#approver_group_8').addClass('hidden');
        $('#level_button_7').removeClass('hidden');
        $('#delete_button_7').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER8_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER8 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER8_M' + ij).attr('checked',false); 
		}
    });
    
    $('#approver_group_9').addClass('hidden');
    utility.multiSelectFD('AP_APPROVER9',0);
	$("input[type=checkbox][name=AP_APPROVER9_M]").trigger("change");
    $('#level_button_9').on("click", function(){
          $('#approver_group_10').removeClass('hidden');
        $('#level_button_9').addClass('hidden');
        $('#delete_button_9').addClass('hidden');
    });
    $('#delete_button_9').on("click", function(){
         $('#approver_group_9').addClass('hidden');
        $('#level_button_8').removeClass('hidden');
        $('#delete_button_8').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER9_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER9 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER9_M' + ij).attr('checked',false); 
		}
    });
    
    $('#approver_group_10').addClass('hidden');         
    utility.multiSelectFD('AP_APPROVER10',0);
	$("input[type=checkbox][name=AP_APPROVER10_M]").trigger("change"); 
    $('#delete_button_10').on("click", function(){
         $('#approver_group_10').addClass('hidden');
        $('#level_button_9').removeClass('hidden');
        $('#delete_button_9').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER10_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER10 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER10_M' + ij).attr('checked',false); 
		}
    });
    
    $('#R_NUM').on("change", function(){
    });*/
    
}

function searchForRdr(){
    if ($('#h_Activity_name').val() == 'Initial Upload'){
		$('#R_PROGRAM').val('').prop("selected", true);
        $('#R_PAY_PLAN').val('').prop("selected", true);
        $('#R_SERIES').val('').prop("selected", true);
        $('#R_POSITION_TITLE').val('');
    }
        $.ajax({
				url: base_url + 'rdrSearch.do?RdrSearch=' + $('#R_NUM').val(),
				dataType: 'xml',
            	async: false,
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       return {
							r_series: $( 'SERIES', this ).text(),
							r_program: $( 'PROGRAM', this ).text(),
							r_position: $( 'POSITION_TITLE', this ).text(),
                            r_payplan: $( 'PAY_PLAN', this ).text()
						};
					}).get();
					//response(data);
					//
                    if (data != ''){
                        
                       $('#R_PROGRAM').prop('readonly','true');
					   $('#R_PROGRAM').attr('alwaysReadonly','true'); 
                       $('#R_PROGRAM').css('background-color', '#efefef');
                       $('#R_PROGRAM').empty();
                       $('#R_PROGRAM').append('<option value=' + data[0].r_program + '>' + data[0].r_program + '</option>');
                        
                       $('#R_PAY_PLAN').prop('readonly','true');
					   $('#R_PAY_PLAN').attr('alwaysReadonly','true'); 
                       $('#R_PAY_PLAN').css('background-color', '#efefef');
                       $('#R_PAY_PLAN').empty();
                       $('#R_PAY_PLAN').append('<option value=' + data[0].r_payplan + '>' + data[0].r_payplan + '</option>');
                        
                       $('#R_SERIES').prop('readonly','true');
					   $('#R_SERIES').attr('alwaysReadonly','true'); 
                       $('#R_SERIES').css('background-color', '#efefef');
                       $('#R_SERIES').empty();
                       $('#R_SERIES').append('<option value=' + data[0].r_series + '>' + data[0].r_series + '</option>');
                        
                        $('#R_POSITION_TITLE').val(data[0].r_position);
                        $('#R_POSITION_TITLE').prop('readonly','true');
						$('#R_POSITION_TITLE').attr('alwaysReadonly','true');
                        $('#R_POSITION_TITLE').css('background-color', '#efefef');
                    }else{
                        if ($('#h_Activity_name').val() == 'Initial Upload'){
                        $('#R_PROGRAM').empty();
                        $('#R_PAY_PLAN').empty();
                        $('#R_SERIES').empty();
                        
                        $('#R_POSITION_TITLE').val('');
                        $('#R_POSITION_TITLE').removeAttr("readonly");
						$('#R_POSITION_TITLE').attr('alwaysReadonly','false');
                        $('#R_POSITION_TITLE').css('background-color', '#FFFFFF');
                        
                        $('#R_PROGRAM').append($('<option>',{value: "", text: "Select One"}));
                        $("#h_program>option").map(function() {$('#R_PROGRAM').append('<option value=\"' + $(this).val() + '\">' + $(this).text() + '</option>');});
                        $('#R_PROGRAM').removeAttr("readonly");
						$('#R_PROGRAM').attr('alwaysReadonly','false');
                        $('#R_PROGRAM').css('background-color', '#FFFFFF');
                        
                        $('#R_PAY_PLAN').append($('<option>',{value: "", text: "Select One"}));
                        $("#h_payplan>option").map(function() {$('#R_PAY_PLAN').append('<option value=\"' + $(this).val() + '\">' + $(this).text() + '</option>');});
                        $('#R_PAY_PLAN').removeAttr("readonly");
						$('#R_PAY_PLAN').attr('alwaysReadonly','false');
                        $('#R_PAY_PLAN').css('background-color', '#FFFFFF');
                        
                        $('#R_SERIES').append($('<option>',{value: "", text: "Select One"}));
                        $("#h_series>option").map(function() {$('#R_SERIES').append('<option value=\"' + $(this).val() + '\">' + $(this).text() + '</option>');});
                        $('#R_SERIES').removeAttr("readonly");
						$('#R_SERIES').attr('alwaysReadonly','false');
                        $('#R_SERIES').css('background-color', '#FFFFFF');
                        }
                    }
				}
			});
	return true;
}

function submitFormRDR(){
    
    
    var alertMassage = "You must specify a value for the following for the field(s)";
	
    var ret = true;
    var ct_deter =  $("#R_GRADE option").size();
    
    var chkmulti = 0;
    
    var prcid = $('#h_attachedlist').val();
				
	for (var ij = 1 ; ij <= ct_deter - 1; ij++){
					
        if($('#R_GRADE_M' + ij).prop('checked') == true){
            chkmulti = chkmulti + 1;
        }
					
	}             
    /*if($('#R_JOB_CODE').val().length != 6 && $('#R_JOB_CODE').val() != ''){
        	alertMassage = alertMassage + '\n Job code must be a blank or 6 character alphanumeric.';
            ret = false;
    }*/
    
    if($('#R_NUM').val()==''){
			alertMassage = alertMassage + "\n RDR Number";
			ret = false;
		}
    
    if($('#R_PROGRAM').val()==''){
			alertMassage = alertMassage + "\n Program";
			ret = false;
		}
    if($('#R_PAY_PLAN').val()==''){
			alertMassage = alertMassage + "\n Pay Plan";
			ret = false;
		}
    if($('#R_SERIES').val()==''){
			alertMassage = alertMassage + "\n Series";
			ret = false;
		}
    if($('#R_POSITION_TITLE').val()==''){
			alertMassage = alertMassage + "\n Position Title";
			ret = false;
		}
    if(chkmulti == 0){
			alertMassage = alertMassage + "\n Grade";
			ret = false;
		}
    if($('#R_FPL').val()==''){
			alertMassage = alertMassage + "\n FPL";
			ret = false;
		}
                    
    $.ajax({
            url: base_url + 'attChk.do?pid=' + prcid,
            dataType: 'xml',
            cache: false,
            async: false,
            success: function (xmlResponse) {
                
                var data = $('record', xmlResponse ).map(function() {
                return {
                        ATT_COUNT: $( 'CNT', this ).text()
                       };}).get();
                if (data != ''){
 
                    if(data[0].ATT_COUNT == 0){
                            
                            alertMassage = alertMassage + "\n Documents";
                            ret = false;
                       }            
              
                	}              
               
               }
                
     });
    
   
    //Check Activity
    
    /*if ($('#h_Activity_name').val() == 'Initial Upload'){        
        if(ret ==false){
            alert(alertMassage);
            return false;
        }
        else {
            return ret;            
        }
        	
    }else{*/
        //For Approver
        
        if(ret ==false){
            alert(alertMassage);
            return false;
        }else {

                /*

                for (var cmt = 10;cmt >= 1;cmt--){
                    
                    var chkMresult = 0;
                	var nchkMresult = 0;
                    
                    var ncmt = cmt - 1; 
                    chkMresult = chkMselectVal("AP_APPROVER" + cmt + "");

                    if(cmt > 2){
                        if(chkMresult > 0){
                            nchkMresult = chkMselectVal("AP_APPROVER" + ncmt + "");

                            if(nchkMresult == 0){
                                ret = false;
                                break;
                            }else{
                                ret = true;
                            }
                        }
                    }else{
                        if(chkMresult > 0){
                            ret = true;
                        }else{
                            ret = false;
                        }                                
                    }
                }
        
        	if(ret ==false){
                alert('Please select an Approver for all the Levels selected or remove the Levels that are not required');
                return false;
            }
            else{*/
            	var procId =  $('#h_procId').val();
                var rdrNumber = $('#R_NUM').val();
                var fpl = $('#R_FPL').val();
                var program = $('#R_PROGRAM').val();
                var payPlan = $('#R_PAY_PLAN').val();
                var Series =  $('#R_SERIES').val();
                var positionTitle = $('#R_POSITION_TITLE').val();
                var grade = getMselectVal('R_GRADE');//$('#R_GRADE_M').val();
                var approverLevel1 = $('#h_approver_1').val();
                var approverLevel2 = $('#h_approver_2').val();
                var approverLevel3 = $('#h_approver_3').val();
                var approverLevel4 = $('#h_approver_4').val();
                var approverLevel5 = $('#h_approver_5').val();
                var approverLevel6 = $('#h_approver_6').val();
                var approverLevel7 = $('#h_approver_7').val();
                var approverLevel8 = $('#h_approver_8').val();
                var approverLevel9 = $('#h_approver_9').val();
				var approverLevel10 = $('#h_approver_10').val();
              
                $.ajax({
                    url: '/bizflow/solutions/whrsc/createrdr.jsp',
                    method: 'POST',
                    data: {serverid: '0000001001', processid: procId, rdrNumber: rdrNumber, fpl: fpl, program: program,payPlan: payPlan,Series:Series, positionTitle:positionTitle,grade:grade,
                          approverLevel1:approverLevel1,approverLevel2:approverLevel2,approverLevel3:approverLevel3,approverLevel4:approverLevel4,approverLevel5:approverLevel5,approverLevel6:approverLevel6,
                          approverLevel7:approverLevel7,approverLevel8:approverLevel8,approverLevel9:approverLevel9,approverLevel10:approverLevel10},
                    dataType: 'json',
                    cache: false,
                    async: false,
                    success: function (resultObj){
                            if(resultObj.success)
                            {

                            }
                            else
                            {
                                alert(resultObj.message, "error");
                                ret = false;
                            }
                    }
                });
            	//return false;
            	return ret;
            //}
        }
    //} 
                    
}

function chkMselectVal(mselectName){
    
    var ct_deter =  $("#" + mselectName + " option").size();
    
    var chkmulti = 0;
				
	for (var ij = 1 ; ij <= ct_deter - 1; ij++){
					
        if($("#" + mselectName + "_M" + ij).prop('checked') == true){
            chkmulti = chkmulti + 1;
        }
					
	}
    	return chkmulti;   
    
}

function getMselectVal(mselectName){
    
    var ct_deter =  $("#" + mselectName + " option").size();
    
    var chkmulti = 0;
    
    var returnValue = '';
				
	for (var ij = 1 ; ij <= ct_deter - 1; ij++){
					
        if($("#" + mselectName + "_M" + ij).prop('checked') == true){
            chkmulti = chkmulti + 1;
            if(returnValue != ''){
                returnValue = returnValue + ',' + $("#" + mselectName + "_M" + ij).val();
            }else{
                returnValue = $("#" + mselectName + "_M" + ij).val();
            }
            
        }
					
	}
    return returnValue;   
}