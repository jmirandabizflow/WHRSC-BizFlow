/* ===================================================================================================
* WARNING – This file is part of the base implementation for WebMaker, so it should not be edited or changed for any project.
* These files are replaced if a project is re-imported to the WebMaker Studio or migrated to a new version of the product.
* For guidance on 'How do I override or clone Hyfinity webapp files such as CSS & javascript?', please read the following relevant FAQ entry:
* http://www.hyfinity.net/faq/index/solution_id/1113
==================================================================================================== */

/*
 * Copyright 2009 Hyfinity Ltd.
*/

if (typeof(hyf) == 'undefined')
{
    hyf = {
        version: 1.0
    }
}


hyf.editabletable = {
    version: 1.3,
    desc: 'Provides functionality for editting/adding/removing entries in a repeating table.',
    EDIT_ID_END: '_et_edit',
    DISPLAY_ID_END: '_et_display',
    HTML_CONTENT_ID_END: '_et_html_content',

    //an array of class names that can be applied to elements that we should ignore events on
    //eg pressing enter on these shouldnt trigger insert or accepting changes
    allowInteractionClasses: ['datePickerIcon', 'timePickerIcon', 'select2-selection', 'cpBorder'],

    currentRowId: null,  //Stores the ID of the row currently being editted.
    optionsCollection: {},  //links the options collections provided for each table to the table ids
    classes: {
        editRow: 'editabletable_edit_row',
        editBtn: 'editabletable_edit_btn',
        removeBtn: 'editabletable_remove_btn',
        acceptBtn: 'editabletable_accept_btn',
        cancelBtn: 'editabletable_cancel_btn',
        btnContainer: 'editabletable_btn_background',
        insertBtn: 'editabletable_insert_btn',
        insertBtnContainer: 'editabletable_insert_btn_background',
        insertRow: 'editabletable_insert_row',
        insertedRow: 'editabletable_inserted_row',
        highlightBackground: 'highlightBackground',
        reorderUpBtn: 'editabletable_reorder_up_btn',
        reorderDownBtn: 'editabletable_reorder_down_btn',
        displayRow: 'editabletable_display_row',
        displaySpan: 'output',
        clickToEditRow: 'editabletable_click_to_edit',
        controlBtnHeading: 'editabletable_btn_heading',
        table: 'editabletable_table'
    },
    messages: {
        insertBtn: 'Insert',
        insertBtnTitle: 'Insert New Entry',
        editBtn: 'Edit',
        editBtnTitle: 'Edit',
        removeBtn: 'Remove',
        removeBtnTitle: 'Remove',
        acceptBtn: 'Accept',
        acceptBtnTitle: 'Accept Changes',
        cancelBtn: 'Cancel',
        cancelBtnTitle: 'Discard Changes',
        reorderUpBtn: 'Move Up',
        reorderUpBtnTitle: 'Move Up',
        reorderDownBtn: 'Move Down',
        reorderDownBtnTitle: 'Move down',
        clickToEditRowTitle: 'Click to Edit',
        doubleClickToEditRowTitle: 'Double Click to Edit'
    },
    defaultOptions: {
        allow_add: true,
        allow_delete: true,
        allow_edit: true,
        validate: true,
        change_function: null,
        allow_reorder: false,

        show_edit_btn: true,
        single_click_edit: false,
        double_click_edit: false,
        force_accept_btn: true,
        show_insert_row: true
    }
}

/**
 * Initialises the given table, to make it an editable control, with the ability to add, remove and edit entries.
 * @param table {Repeat_Name} The HTML node representing the table to convert
 * @param options {object} (optional) Set of properties that can be used to customize the table:
 *          allow_add :     boolean indicating whether the user can add rows to the table (default true)
 *          allow_delete :  boolean indicating whether the user can delete rows from the table (default true)
 *          allow_edit :    boolean indicating whether the user can edit rows in the table (default true)
 *          allow_reorder : boolean indicating whether the user can reorder rows in the table (default false)
 *                          Alternatively, these four properties can contain a reference to a function that will be
 *                          called dynamically to determine the true or false value.  This function will be passed the id
 *                          of the relevant table, along with the id of the row where appropriate.
 *          validate :      boolean indicating whether the data should be validated before insert/amend (default true)
 *          change_function : function reference (or name) that should be called whenever any change is made
 *                          this function will be passed two parameters, a string indicating the type of
 *                          change - 'insert', 'remove', 'edit', and the id of the row being changed
 *          single_click_edit : booelan indicating whether the user can single click on the displayed values to edit
 *                          them.  Only applies if editing is allowed. (default false)
 *          double_click_edit : booelan indicating whether the user can double click on the displayed values to edit
 *                          them.  Only applies if editing is allowed, and single_click_edit not true. (default false)
 *          show_edit_btn : boolean indicating whether the edit button should be shown.  Could be set to false if
 *                          either click to edit option is enabled. (default true)
 *          force_accept_btn: boolean.  If true, the user must click the accept changes button to store any edits made.  If false
 *                          then changes will be accepted by just clicking elsewhere on the page.  This also changes the behaviour
 *                          of clicking edit on a different row.  If this is true, then changes will be lost, if false the changes
 *                          will be stored. (default true)
 *          show_insert_row: boolean controlling how the insert process will work.  Only applies if adding new rows is allowed.
 *                              if true a row of controls will always be present at the bottom of the table, followed
 *                                      by an insert button that can be used to add the new record once the controls
 *                                      have been filled in. (This is the default)
 *                              if false only the insert button will be visible at the bottom of the table. Clicking this
 *                                      will add a new bloank row to the table which will be shown in edit mode for the user
 *                                      to fill in the details.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.init = function(table, options)
{
    if ((options == null) || (typeof(options) == 'undefined'))
        options = {};

    var defaults = dojo.clone(hyf.editabletable.defaultOptions);

    dojo.mixin(defaults, options);

    //add in the messages and classes collections to the settings
    defaults.messages = dojo.mixin({}, hyf.editabletable.messages, options.messages);
    defaults.classes = dojo.mixin({}, hyf.editabletable.classes, options.classes);

    hyf.editabletable.optionsCollection[table.getAttribute('id')] = defaults;

    hyf.editabletable.optionsCollection[table.getAttribute('id')].initialised = false;

}

/**
 * Initialises any editable tables that have been specified in the given container.
 * This is connected to the contentInserted hook as we need to get the HTML before any dojo
 * widgets have been parsed so we can adjust the ids, and then reparse it to create the widgets
 * for each new row.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.initTables = function(container)
{
    //check if we have any editable tables that have not yet been initialised
    for (tableId in hyf.editabletable.optionsCollection)
    {
        if (hyf.editabletable.optionsCollection[tableId].initialised == false)
        {
            //check if it is contained within the provided container.
            if (dojo.query('#' + tableId, container).length > 0)
            {
                hyf.editabletable.initImpl(tableId);
            }
        }
    }
    hyf.util.fixFlexBoxAlignment(container, true);
}
dojo.connect(hyf.hooks, 'contentInserted', hyf.editabletable.initTables);

/**
 * Actually initialises the editable table for the specified table.
 * @param tableId The ID of the table to initialise
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.initImpl = function(tableId)
{
    var table = document.getElementById(tableId);
    var tbody = document.getElementById(tableId + '_body');

    dojo.addClass(table, hyf.editabletable.optionsCollection[tableId].classes.table);

    //check if reorder should be enabled
    var allowReorder = hyf.editabletable.optionsCollection[tableId].allow_reorder;
    if (typeof(allowReorder) == 'function')
    {
        allowReorder = allowReorder(tableId);
    }
    hyf.editabletable.optionsCollection[tableId].allowReorderResult = allowReorder;

    //loop through each row to convert to display only and add edit/delete buttons
    var rows = tbody.rows;
    for (var i=0; i < rows.length; ++i)
    {
        //remove the 'no data found' row if present
        if (((rows[i].getAttribute('id') == null) || (rows[i].getAttribute('id') == '')) &&
            (rows[i].cells[0].getAttribute('id') == tableId + '_empty'))
        {
            tbody.removeChild(rows[i]);
        }
        else
        {
            hyf.editabletable.processRow(rows[i]);
        }
    }

    //add a header th for the edit/delete/reorder buttons
    var theadRow = table.tHead.rows[0];

    var allowEdit = hyf.editabletable.optionsCollection[tableId].allow_edit;
    var allowDelete = hyf.editabletable.optionsCollection[tableId].allow_delete;
    if ((allowEdit == true) || (typeof(allowEdit) == 'function') || (allowDelete == true) || (typeof(allowDelete) == 'function') || allowReorder)
    {
        var newHeadTh = document.createElement('th');
        var span = 0;
        if ((allowEdit == true) || (typeof(allowEdit) == 'function') || (allowDelete == true) || (typeof(allowDelete) == 'function'))
            span += 2;
        if (allowReorder)
            span += 1;

        newHeadTh.colSpan = span;
        newHeadTh.className = theadRow.cells[0].className + '' + hyf.editabletable.optionsCollection[tableId].classes.controlBtnHeading;
        newHeadTh.innerHTML = '&nbsp;'
        theadRow.appendChild(newHeadTh);
    }

    //find new row body
    var allowAdd = hyf.editabletable.optionsCollection[tableId].allow_add;
    if ((allowAdd == true) || ((typeof(allowAdd) == 'function') && allowAdd(tableId)))
    {
        var newRowBody = document.getElementById(tableId + '_newRowContent');
        if (newRowBody != null)
        {
            var insertTd = document.createElement('td');
            insertTd.setAttribute('id', tableId + '_insert');
            insertTd.colSpan = 2;
            if (allowReorder)
                insertTd.colSpan = 3;
            insertTd.className = newRowBody.rows[0].cells[0].className + ' ' + hyf.editabletable.optionsCollection[tableId].classes.insertBtnContainer;
            insertTd.innerHTML = '<a class="'+hyf.editabletable.optionsCollection[tableId].classes.insertBtn+'" href="#" onclick="hyf.editabletable.insertRow(event, \'' + tableId + '\'); return false;" title="'
                                        + hyf.editabletable.optionsCollection[tableId].messages.insertBtnTitle+'"><span>'+hyf.editabletable.optionsCollection[tableId].messages.insertBtn+'</span></a>';

            hyf.util.showComponent(newRowBody);

            //take a copy of the initial HTML content of each cell to use when recreating the new blank row after an insert
            for (var i = 0; i < newRowBody.rows[0].cells.length; ++i)
            {
                if (newRowBody.rows[0].cells[i].getAttribute('id') == null)
                    newRowBody.rows[0].cells[i].setAttribute('id', tableId + 'BlankEntry_cell' + i);

                var newSpan = document.createElement('input');
                newSpan.type = 'hidden';
                newSpan.setAttribute('id', newRowBody.rows[0].cells[i].getAttribute('id') + hyf.editabletable.HTML_CONTENT_ID_END);
                newSpan.value = newRowBody.rows[0].cells[i].innerHTML;
                newRowBody.rows[0].cells[i].appendChild(newSpan);
            }

            //disable the xpath fields for the new row fields so that we wont try and bind these on submit
            //when a row is inserted these will be enabled for the new row
            dojo.query('input[type="hidden"][name$="_xpath"], input[type="hidden"][name*="_xpath_xga_"]', newRowBody).forEach(function(item){ item.disabled = true; });

            if (hyf.editabletable.optionsCollection[tableId].show_insert_row)
            {
                newRowBody.rows[0].appendChild(insertTd);
                dojo.addClass(newRowBody.rows[0], hyf.editabletable.optionsCollection[tableId].classes.insertRow);

                //add an event handler to allow pressing enter in the insert row fields to insert it
                require(["dojo/query", "dojo/NodeList-traverse"], function(query){
                    hyf.attachEventHandler(newRowBody, 'onkeydown', function(e) {

                            var evt = e || window.event;

                            var source = (evt.target || evt.srcElement);

                            var sourceNL = query.NodeList();
                            sourceNL.push(source);

                            for (var i = 0; i < hyf.editabletable.allowInteractionClasses.length; ++i)
                            {
                                if (sourceNL.closest('.' + hyf.editabletable.allowInteractionClasses[i]).length > 0)
                                    return true;
                            }

                            var keyChar = evt.charCode ? String.fromCharCode(evt.charCode) : '';

                            if ((keyChar == dojo.keys.ENTER) || (evt.keyCode == dojo.keys.ENTER))
                            {
                                //enter key pressed so accept changes
                                hyf.editabletable.insertRow(e, tableId);
                            }
                            return true;
                    });
                });
            }
            else
            {
                hyf.util.hideComponent(newRowBody.rows[0]);

                var btnRow = document.createElement('tr');

                //need to update the colspan on the insert td as it now needs to span all cols in the table
                //base this off the header row, as can't assume there is a data row
                var neededColSpan = 0;
                for (var i = 0; i < theadRow.cells.length; ++i)
                {
                    neededColSpan += theadRow.cells[i].colSpan;
                }
                insertTd.colSpan = neededColSpan;

                btnRow.appendChild(insertTd);
                newRowBody.appendChild(btnRow);
                //dojo.addClass(btnRow, hyf.editabletable.optionsCollection[tableId].classes.insertRow);
            }
        }
    }

    //special handling for multiple checkbox controls
    dojo.query("input[type=checkbox]", table).forEach(function(item){
        if (item.name != item.id)
            item.name = item.id;
    })

    hyf.editabletable.optionsCollection[tableId].initialised = true;
}

/**
 * For the given row in the table, this method hides all the data entry controls,
 * and adds the edit and remove buttons if needed
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.processRow = function(row)
{
    var table = hyf.editabletable.findParentTable(row);
    var options = hyf.editabletable.optionsCollection[table.getAttribute('id')];

    //loop through all the cells in the row
    var cells = row.cells;
    for (var i = 0; i < cells.length; ++i)
    {
        //move all current contents under a new container
        var editSpan = document.createElement('span');
        editSpan.id = row.id + i + hyf.editabletable.EDIT_ID_END;
        var displaySpan = document.createElement('span');
        displaySpan.id = row.id + i + hyf.editabletable.DISPLAY_ID_END;
        displaySpan.className = options.classes.displaySpan;

        while (cells[i].firstChild != null)
            editSpan.appendChild(cells[i].firstChild);

        cells[i].appendChild(editSpan);
        cells[i].appendChild(displaySpan);

        var value = hyf.editabletable.getCellValue(editSpan);
        if (value == null || "undefined" == typeof(value) || value.length == 0)
            value = " ";

        displaySpan.appendChild(document.createTextNode(value));

        //store the current edit HTML string away for future use
        var editHTML = document.createElement('input');
        editHTML.type = 'hidden';
        editHTML.setAttribute('id', row.id + i + hyf.editabletable.HTML_CONTENT_ID_END);
        editHTML.value = editSpan.innerHTML;
        cells[i].appendChild(editHTML);

        hyf.util.hideComponent(editSpan);

    }

    dojo.addClass(row, options.classes.displayRow);


    //add the reorder buttons if required
    if (options.allowReorderResult)
    {
        var reorderTd = document.createElement('td');
        reorderTd.setAttribute('id', row.getAttribute('id') + "_reorder");
        row.appendChild(reorderTd);

        reorderTd.innerHTML = '<a class="'+options.classes.reorderUpBtn+'" href="#" onclick="hyf.editabletable.reorderRow(event, this, \'up\'); return false;" title="'+options.messages.reorderUpBtnTitle+'"><span>'+options.messages.reorderUpBtn+'</span></a>'
                            + '<a class="'+options.classes.reorderDownBtn+'" href="#" onclick="hyf.editabletable.reorderRow(event, this, \'down\'); return false;" title="'+options.messages.reorderDownBtnTitle+'"><span>'+options.messages.reorderDownBtn+'</span></a>';

        reorderTd.className = cells[0].className + ' ' + options.classes.btnContainer;
    }

    //add the new edit/remove buttons

    var allowEdit = options.allow_edit;
    if ((allowEdit == true) || (typeof(allowEdit) == 'function'))
    {
        var editTd = document.createElement('td');
        editTd.setAttribute('id', row.getAttribute('id') + "_edit");
        row.appendChild(editTd);

        if ((allowEdit == true) || ((typeof(allowEdit) == 'function') && allowEdit(table.getAttribute('id'), row.getAttribute('id'))))
        {
            //edit is allowed for this row
            if (options.show_edit_btn)
                editTd.innerHTML = '<a class="'+options.classes.editBtn+'" href="#" onclick="hyf.editabletable.editRow(event, this); return false;" title="'+options.messages.editBtnTitle+'"><span>'+options.messages.editBtn+'</span></a>';
            else
                editTd.innerHTML = '&nbsp;';

            var clickEvt = null;
            if (options.single_click_edit)
                clickEvt = 'onclick';
            else if (options.double_click_edit)
                clickEvt = 'ondblclick';

            if (clickEvt)
            {
                row[clickEvt] = function(e) {

                    var evt = e || window.event;

                    var td = hyf.editabletable.findParentElement((evt.target || evt.srcElement), 'td')

                    hyf.editabletable.editRow(e, this.getAttribute('id'), td);

                }
                if (options.single_click_edit)
                {
                    if (options.messages.clickToEditRowTitle != '')
                        row.title = options.messages.clickToEditRowTitle;
                }
                else
                {
                    if (options.messages.doubleClickToEditRowTitle != '')
                        row.title = options.messages.doubleClickToEditRowTitle;
                }
                if (options.classes.clickToEditRow != '')
                    dojo.addClass(row, options.classes.clickToEditRow);
            }
        }
        else
            editTd.innerHTML = '&nbsp;';

        editTd.className = cells[0].className + ' ' + options.classes.btnContainer;
    }
    var allowDelete = options.allow_delete;
    if ((allowDelete == true) || (typeof(allowDelete) == 'function'))
    {
        var removeTd = document.createElement('td');
        removeTd.setAttribute('id', row.getAttribute('id') + "_remove");
        row.appendChild(removeTd);

        if ((allowDelete == true) || ((typeof(allowDelete) == 'function') && allowDelete(table.getAttribute('id'), row.getAttribute('id'))))
            removeTd.innerHTML = '<a class="'+options.classes.removeBtn+'" href="#" onclick="hyf.editabletable.removeRow(event, this); return false;" title="'+options.messages.removeBtnTitle+'"><span>'+options.messages.removeBtn+'</span></a>';
        else
            removeTd.innerHTML = '&nbsp;';

        removeTd.className = cells[0].className + ' ' + options.classes.btnContainer;
    }
}

/**
 * Takes the provided HTML componenet and looks through it to find data entry controls,
 * eg textboxes etc.  It then returns a string containing the current value of the control
 * @param container The HTML component to look through for data entry controls
 * @param valueType (optional) A string indicating what type of value should be returned
 *          can be either 'data' or 'display' (the default)
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.getCellValue = function(container, valueType)
{
    if (typeof(valueType) == 'undefined')
        valueType = 'display';

    //First check if the td for this cell looks like the container for a single field.
    //If so then try and deligate to our hyf.util.getFieldValue function
    var cellTd = container;
    if (cellTd.tagName.toLowerCase() != 'td')
        cellTd = hyf.editabletable.findParentElement(container, 'td')

    if (cellTd.id && cellTd.id.indexOf('_container', cellTd.id.length - 10) != -1)
    {
        var val = hyf.util.getFieldValue(cellTd.id.substring(0, cellTd.id.length - 10), (valueType == 'display'));
        if (val != null)
        {
            if ((Array.isArray && Array.isArray(val)) || (!Array.isArray && (val instanceof Array)))
                return val.join(', ');
            else
                return val;
        }
    }

    //check for a dojo widget instead of a standard control
    if (hyf.util.hasWidgets(container))
    {
        var widget = hyf.util.getDijitWidgets(container)[0];
        if (valueType == 'display')
        {
            var dv = widget.attr('displayedValue');
            if (dv != null)
                return dv;
        }

        return widget.attr('value');
    }


    var controls = new Array();
    var inputs = container.getElementsByTagName('input');
    for (var i = 0; i < inputs.length; ++i)
        controls[controls.length] = inputs[i];
    inputs = container.getElementsByTagName('select');
    for (var i = 0; i < inputs.length; ++i)
        controls[controls.length] = inputs[i];
    inputs = container.getElementsByTagName('textarea');
    for (var i = 0; i < inputs.length; ++i)
        controls[controls.length] = inputs[i];

    var multiCheckValue = null;

    for (var i = 0; i < controls.length; ++i)
    {
        //look at the type of input
        switch (controls[i].type)
        {
            case 'image'    :   break;
            case 'button'   :   break;
            case 'reset'    :   break;
            case 'submit'   :   break;
            case 'file'     :   break;
            case 'hidden'   :   break;
            case 'password' :   if (valueType == 'data')
                                    return controls[i].value;
                                else
                                {
                                    var stringLength = controls[i].value.length;
                                    var pwdVal = '';
                                    for(var j = 0; j < stringLength; ++j) pwdVal += '*';
                                    return pwdVal;
                                }
            case 'select-one':  if (valueType == 'data')
                                    return controls[i].options[controls[i].selectedIndex].value;
                                else
                                    return controls[i].options[controls[i].selectedIndex].text;
            case 'select-multiple': var returnString = '';
                                    for (var op = 0; op < controls[i].options.length; ++op)
                                    {
                                        if (controls[i].options[op].selected)
                                        {
                                            if (returnString != '')
                                                returnString += ', ';
                                            if (valueType == 'data')
                                                returnString += controls[i].options[op].value;
                                            else
                                                returnString += controls[i].options[op].text;
                                        }
                                    }
                                    return returnString;
            case 'radio'    :   if (controls[i].checked)
                                {
                                    //try and find the matching label
                                    if (valueType == 'display')
                                    {
                                        var labels = container.getElementsByTagName('label');
                                        for (var j = 0; j < labels.length; ++j)
                                        {
                                            var label = labels[j];
                                            if (label.getAttribute('for') == controls[i].id)
                                            {
                                                if (typeof(label.textContent) != 'undefined')
                                                    return label.textContent;
                                                else
                                                    return label.innerText;
                                            }
                                        }
                                    }
                                    //could not find a label so just return control value
                                    return controls[i].value;
                                }
                                //its possible that no radio buttins could yet be selected, so make
                                //sure that we return an empty string in this case, not the text content
                                //of the cell
                                multiCheckValue = '';
                                break;
            case 'checkbox' :   //Check if part of a multi check control
                                if (controls[i].getAttribute('_use') == 'selectMany')
                                {
                                    if (multiCheckValue == null)
                                        multiCheckValue = '';
                                    if (controls[i].checked)
                                    {
                                        if (multiCheckValue != '')
                                            multiCheckValue += ', ';

                                        //try and find the matching label
                                        var labelFound = false;
                                        if (valueType == 'display')
                                        {
                                            var labels = container.getElementsByTagName('label');
                                            for (var j = 0; j < labels.length; ++j)
                                            {
                                                var label = labels[j];
                                                if (label.getAttribute('for') == controls[i].id)
                                                {
                                                    if (typeof(label.textContent) != 'undefined')
                                                        multiCheckValue += label.textContent;
                                                    else
                                                        multiCheckValue += label.innerText;
                                                    labelFound = true;
                                                }
                                            }
                                        }
                                        if (!labelFound)
                                            multiCheckValue += controls[i].value;
                                    }
                                }
                                else
                                {
                                    if (controls[i].checked)
                                        return controls[i].value;
                                    else if (document.getElementById(controls[i].id + '_value_if_not_submitted') != null)
                                        return document.getElementById(controls[i].id + '_value_if_not_submitted').value;
                                    else
                                        return '';
                                }
                                break;
            default         :   return controls[i].value;
        }
    }

    if (multiCheckValue != null)
        return multiCheckValue;

    //if no controls found, then just return the text content of the cell
    if (typeof(container.textContent) != 'undefined')
        return container.textContent;
    else
        return container.innerText;
}

/**
 * Tries to update an editable control in the given container so that it has the provided value.
 * The aim is that for a cell with a single control, calling setCellValue with the output from
 * getCellValue(cell, 'data') above will not affect the HTML.
 * This shoud only be called on cells that contain only base controls, not dojo widgets.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.setCellValue = function(container, valueToSet)
{
    var controls = new Array();
    var inputs = container.getElementsByTagName('input');
    for (var i = 0; i < inputs.length; ++i)
        controls[controls.length] = inputs[i];
    inputs = container.getElementsByTagName('select');
    for (var i = 0; i < inputs.length; ++i)
        controls[controls.length] = inputs[i];
    inputs = container.getElementsByTagName('textarea');
    for (var i = 0; i < inputs.length; ++i)
        controls[controls.length] = inputs[i];

    //ensure that the value is a string
    valueToSet = '' + valueToSet;

    var multiValues = valueToSet.split(', ');


    for (var i = 0; i < controls.length; ++i)
    {
        //look at the type of input
        switch (controls[i].type)
        {
            case 'image'    :   break;
            case 'button'   :   break;
            case 'reset'    :   break;
            case 'submit'   :   break;
            case 'file'     :   break;
            case 'hidden'   :   break;
            case 'select-one':  for(var j = 0; j < controls[i].options.length; ++j)
                                {
                                    if (controls[i].options[j].value == valueToSet)
                                    {
                                        controls[i].options[j].selected = true;
                                        controls[i].options[j].defaultSelected = true;
                                        hyf.util.addHtmlAttribute(controls[i].options[j], 'selected', 'selected');

                                        //make sure the select control no longer has a blank value
                                        //attribute if one has been added
                                        //eg for dojo filtering select to force initial placeholder display
                                        if ((controls[i].getAttribute('dojoType') != null) || (controls[i].getAttribute('data-dojo-type') != null))
                                            hyf.util.removeHtmlAttribute(controls[i], 'value');

                                        //return;
                                    }
                                    else if (controls[i].options[j].getAttribute('selected'))
                                        hyf.util.removeHtmlAttribute(controls[i].options[j], 'selected');
                                }
                                if ((valueToSet == '') && ((controls[i].getAttribute('dojoType') != null) || (controls[i].getAttribute('data-dojo-type') != null)))
                                    hyf.util.addHtmlAttribute(controls[i], 'value', '');


                                break;
            case 'select-multiple':
                                for (var op = 0; op < controls[i].options.length; ++op)
                                {
                                    var match = false;
                                    for(var j = 0; j < multiValues.length; ++j)
                                    {
                                        if (controls[i].options[op].value == multiValues[j])
                                        {
                                            match = true;
                                        }
                                    }
                                    if (match)
                                    {
                                        controls[i].options[op].selected = true;
                                        controls[i].options[op].defaultSelected = true;
                                    }
                                    else
                                    {
                                        controls[i].options[op].selected = false;
                                        controls[i].options[op].defaultSelected = false;
                                    }
                                }
                                return;
            case 'radio'    :   if (controls[i].value == valueToSet)
                                {
                                    controls[i].checked = true;
                                    controls[i].defaultChecked = true;
                                }
                                else
                                {
                                    controls[i].checked = false;
                                    controls[i].defaultChecked = false;
                                }
                                break;
            case 'checkbox' :   //Check if part of a multi check control
                                if (controls[i].getAttribute('_use') == 'selectMany')
                                {
                                    var val = controls[i].value;

                                    var match = false;
                                    for (var j = 0; j < multiValues.length; ++j)
                                    {
                                        if (val == multiValues[j])
                                        {
                                            match = true;
                                        }
                                    }
                                    if (match)
                                    {
                                        controls[i].checked = true;
                                        controls[i].defaultChecked = true;
                                    }
                                    else
                                    {
                                        controls[i].checked = false;
                                        controls[i].defaultChecked = false;
                                    }
                                }
                                else
                                {
                                    if (controls[i].value == valueToSet)
                                    {
                                        controls[i].checked = true;
                                        controls[i].defaultChecked = true;
                                    }
                                    else
                                    {
                                        controls[i].checked = false;
                                        controls[i].defaultChecked = false;
                                    }
                                    return;
                                }
                                break;
            default         :   controls[i].value = valueToSet;
                                controls[i].defaultValue = valueToSet;
                                return;
        }
    }

}


/**
 * Looks through the parent hierarchy of the given object and returns the first 'table' object forund
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.findParentTable = function(obj)
{
    return hyf.editabletable.findParentElement(obj, 'table');
}

hyf.editabletable.findParentElement = function(obj, elemName)
{
    if (!obj || !obj.tagName)
        return null;
    else if (obj.tagName.toLowerCase() == elemName)
        return obj
    else
        return hyf.editabletable.findParentElement(obj.parentNode, elemName);
}

/**
 * Makes the fields in the given row editable so that the user can change the values.
 * @param row The ID of the row to edit, or the HTML element for the row (or a child of it)
 * @param requestedTd (Optional) The TD element that the edit has been requested for.  We will try and put the focus on the
 *                  edit field in this cell if possible
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.editRow = function(e, row, requestedTd)
{
    if (typeof(row) == 'string')
    {
        row = document.getElementById(row);
    }
    else
    {
        row = hyf.editabletable.findParentElement(row, 'tr');
    }
    var rowId = row.getAttribute('id');
    var table = hyf.editabletable.findParentTable(row);

    //make sure this table is not disabled
    if (hyf.editabletable.isDisabled(table.getAttribute('id')))
        return;


    var options = hyf.editabletable.optionsCollection[table.getAttribute('id')];

    if (hyf.editabletable.currentRowId != null)
    {
        //if we are already editing this row then there is nothing to do.
        if (hyf.editabletable.currentRowId == rowId)
            return;

        var currentEditTable = hyf.editabletable.findParentTable(document.getElementById(hyf.editabletable.currentRowId));
        if (hyf.editabletable.optionsCollection[currentEditTable.getAttribute('id')].force_accept_btn)
            hyf.editabletable.cancelChanges(null, hyf.editabletable.currentRowId);
        else
            if (!hyf.editabletable.acceptChanges(null, hyf.editabletable.currentRowId))
                return; //can't close the currently open row so can't edit a different one
    }

    hyf.editabletable.currentRowId = rowId;

    //track whether we have successfully put the focus in an edit field yet
    var focussed = false;

    //hide the display only spans, and make the editable fields visible.
    var spans = row.getElementsByTagName('span');
    for (var i = 0; i < spans.length; ++i)
    {
        var spanId = spans[i].getAttribute('id');
        if ((spanId != null) && (spanId.lastIndexOf(hyf.editabletable.DISPLAY_ID_END) + hyf.editabletable.DISPLAY_ID_END.length == spanId.length))
        {
            hyf.util.hideComponent(spans[i]);
            var editSpan = document.getElementById(spanId.substring(0, spanId.length - hyf.editabletable.DISPLAY_ID_END.length) + hyf.editabletable.EDIT_ID_END);
            hyf.util.showComponent(editSpan);

            var cell = hyf.editabletable.findParentElement(editSpan, 'td')

            //update the hidden field storing the html content with the latest values
            //so that we can revert ok if they choose to cancel any changes made.
            var contentHidden = document.getElementById(spanId.substring(0, spanId.length - hyf.editabletable.DISPLAY_ID_END.length) + hyf.editabletable.HTML_CONTENT_ID_END);

            var hasWidget = false;
            //if we have dojo widgets, we first need to discard these and manually update the current cell html
            //to make sure we have the updated version
            if (hyf.util.hasWidgets(cell))
            {
                var currentValue = hyf.editabletable.getCellValue(editSpan, 'data');
                hyf.util.destroyDojoWidgets(cell);
                editSpan.innerHTML = contentHidden.value;
                hyf.editabletable.setCellValue(editSpan, currentValue);
                hasWidget = true;
            }

            //handle the fact that radio and checkbox controls store there defaultchecked property in the innerHTMl,
            //not the current checked property, which is what we actually want.
            var inputsToCheck = editSpan.getElementsByTagName('input');
            for (var j = 0; j < inputsToCheck.length; ++j)
            {
                if ((inputsToCheck[j].type == 'radio') || (inputsToCheck[j].type == 'checkbox'))
                    inputsToCheck[j].defaultChecked = inputsToCheck[j].checked;
                if (typeof(inputsToCheck[j].defaultValue) != 'undefined')
                    inputsToCheck[j].defaultValue = inputsToCheck[j].value;
            }
            contentHidden.value = editSpan.innerHTML;

            //if we have a wdiget, then need to recreate
            if (hasWidget)
            {
                dojo.parser.parse(cell);
            }


            //now try and focus the control/widget
            if ((!focussed) && ((!requestedTd) || (requestedTd == cell)))
            {
                if (hyf.util.setFocusOnFirstField(cell))
                    focussed = true;
            }
        }
    }

    //reset any left over validation markers from the edit row
    hyf.FMAction.getErrorDisplay().resetDisplay(row);

    //change the edit/remove buttons to accept/cancel
    var editTd = document.getElementById(rowId + '_edit');
    var removeTd = document.getElementById(rowId + '_remove');

    var editBtnHTML = '<a class="'+options.classes.acceptBtn+'" href="#" onclick="hyf.editabletable.acceptChanges(event, \''+rowId+'\'); return false;" title="'+options.messages.acceptBtnTitle+'"><span>'+options.messages.acceptBtn+'</span></a>';
    var removeBtnHTML = '<a class="'+options.classes.cancelBtn+'" href="#" onclick="hyf.editabletable.cancelChanges(event, \''+rowId+'\'); return false;" title="'+options.messages.cancelBtnTitle+'"><span>'+options.messages.cancelBtn+'</span></a>';

    if ((editTd != null) && (removeTd != null))
    {
        editTd.innerHTML = editBtnHTML
        removeTd.innerHTML = removeBtnHTML
    }
    else if (editTd != null)
    {
        //delete must be disabled, so need to add both buttons to edit container
        editTd.innerHTML = editBtnHTML;
        editTd.innerHTML += removeBtnHTML;
    }
    else if (removeTd != null)
    {
        //edit must be disabled, so need to add both buttons to remove container
        //could still get here for insert operation when not showing insert row
        removeTd.innerHTML = editBtnHTML;
        removeTd.innerHTML += removeBtnHTML;
    }
    else
    {
        //both edit and delete disabled so just add the buttons to the end of the last cell
        //This could only happen for an insert operation when not showing insert row.
        row.cells[row.cells.length - 1].innerHTML += '<span id="' + rowId + '_insertControlBtns">' + editBtnHTML + removeBtnHTML + '</span>'
    }

    dojo.addClass(row, options.classes.editRow);
    dojo.removeClass(row, options.classes.displayRow);

    //if we support click to edit, then reset the style chanegs to indicate this behaviour when in edit mode
    if (options.single_click_edit || options.double_click_edit)
    {
        if (options.single_click_edit)
        {
            if (options.messages.clickToEditRowTitle != '')
                row.title = '';
        }
        else
        {
            if (options.messages.doubleClickToEditRowTitle != '')
                row.title = '';
        }
        if (options.classes.clickToEditRow != '')
            dojo.removeClass(row, options.classes.clickToEditRow);
    }

    //initialise a click handler on the document to handle save of changes when you click off
    if (!options.force_accept_btn)
    {
        hyf.editabletable.docClickHandle = hyf.attachEventHandler(document, 'onclick', function(e) {
                var evt = e || window.event;

                var source = (evt.target || evt.srcElement);

                //if the click was initially within a dojo widget, or a calendar popup then we dont want
                //to treat it as a click on the background to accept the changes
                if ((typeof(dijit) != 'undefined') && (typeof(dijit.getEnclosingWidget) == 'function') && (dijit.getEnclosingWidget(source)))
                {
                    //is in a dojo widget so ignore event
                    return;
                }
                if (hyf.util.isParent(source, dojo.byId('calendarDiv')))
                {
                    //is within the calendar so ignore event
                    //(isParent function handles the parent check node possibly being null if there is no calendar)
                    return;
                }

                hyf.editabletable.acceptChanges(evt, hyf.editabletable.currentRowId)
        });
        hyf.editabletable.rowClickHandle = hyf.attachEventHandler(row, 'onclick', function(e) {
                var evt = e || window.event;
                hyf.editabletable.cancelEvent(evt);
        });

        require(["dojo/query", "dojo/NodeList-traverse"], function(query){

            hyf.editabletable.docKeyHandle = hyf.attachEventHandler(document, 'onkeydown', function(e) {

                    var evt = e || window.event;

                    var source = (evt.target || evt.srcElement);

                    var sourceNL = query.NodeList();
                    sourceNL.push(source);

                    for (var i = 0; i < hyf.editabletable.allowInteractionClasses.length; ++i)
                    {
                        if (sourceNL.closest('.' + hyf.editabletable.allowInteractionClasses[i]).length > 0)
                            return true;
                    }

                    var keyChar = evt.charCode ? String.fromCharCode(evt.charCode) : '';

                    if ((keyChar == dojo.keys.ENTER) || (evt.keyCode == dojo.keys.ENTER))
                    {
                        //enter key pressed so accept changes
                        hyf.editabletable.acceptChanges(evt, hyf.editabletable.currentRowId);
                    }
                    else if ((keyChar == dojo.keys.ESCAPE) || (evt.keyCode == dojo.keys.ESCAPE))
                    {
                        //enter key pressed so cancel changes
                        hyf.editabletable.cancelChanges(evt, hyf.editabletable.currentRowId);
                    }

                    return true;
            });
        });


        //stop the current event bubbling and triggering this attached document level event
        if (!e) var e = window.event;
        hyf.editabletable.cancelEvent(e)
    }
}

/**
 * Cancels propagation of the provided event
 * @param evt Event object to cancel propagating.
 */
hyf.editabletable.cancelEvent = function(evt)
{
    if (evt)
    {
        evt.cancelBubble = true;
        if (evt.stopPropagation)
            evt.stopPropagation();
    }
}

/**
 * Stores the changes made to the editable row
 * This updates the displayed spans to contain the new values, and hides the edit boxes.
 * The buttons are also converted back to edit/remove
 * @param rowId The ID of the row being edited.
 * @return success or otherwise of the process.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.acceptChanges = function(e, rowId)
{
    var row = document.getElementById(rowId);

    if (!row)
        return false;

    var success = false;

    //check if we need to validate first
    var table = hyf.editabletable.findParentTable(row);
    if (hyf.editabletable.optionsCollection[table.getAttribute('id')].validate)
    {
        if (hyf.validation.validateContainer(row))
        {
            //if triggered from an input field, blur the field first
            //to avoid issue with events firing after it is hidden, eg validation
            if (e)
            {
                var sourceNode = (e.target || e.srcElement);
                if ((sourceNode.tagName.toLowerCase() == 'input') || (sourceNode.tagName.toLowerCase() == 'textarea') || (sourceNode.tagName.toLowerCase() == 'select'))
                    sourceNode.blur();
            }

            hyf.editabletable.processChanges(rowId, 'accept');
            hyf.editabletable.callChangeFunction(rowId, 'edit');
            success = true;
        }
    }
    else
    {
        //if triggered from an input field, blur the field first
        //to avoid issue with events firing after it is hidden, eg validation
        if (e)
        {
            var sourceNode = (e.target || e.srcElement);
            if ((sourceNode.tagName.toLowerCase() == 'input') || (sourceNode.tagName.toLowerCase() == 'textarea') || (sourceNode.tagName.toLowerCase() == 'select'))
                sourceNode.blur();
        }

        hyf.editabletable.processChanges(rowId, 'accept');
        hyf.editabletable.callChangeFunction(rowId, 'edit');
        success = true;
    }

    hyf.editabletable.cancelEvent(e);

    if ((success) && (hyf.editabletable.currentRowEditMode == 'insert'))
        hyf.editabletable.currentRowEditMode = null;

    return success;
}

/**
 * Discards the changes made to the editable row
 * This reverts the edit boxes back to their old values, and hides them away
 * The buttons are also converted back to edit/remove
 * @param rowId The ID of the row being edited.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.cancelChanges = function(e, rowId)
{
    hyf.editabletable.processChanges(rowId, 'cancel');

    if (hyf.editabletable.currentRowEditMode == 'insert')
    {
        hyf.editabletable.currentRowEditMode = null;
        hyf.editabletable.removeRow(null, rowId);
    }

    hyf.editabletable.cancelEvent(e);
}

/**
 * Function that implments the accept/cancel functionality
 * @param rowId The ID of the row being edited.
 * @param type either 'accept' or 'cancel'.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.processChanges = function(rowId, type)
{
    var row = document.getElementById(rowId);
    var table = hyf.editabletable.findParentTable(row);
    var options = hyf.editabletable.optionsCollection[table.getAttribute('id')];

    //show the display only spans (and update their values), and make the editable fields hidden.
    var spans = row.getElementsByTagName('span');
    for (var i = 0; i < spans.length; ++i)
    {
        var spanId = spans[i].getAttribute('id');
        if ((spanId != null) && (spanId.lastIndexOf(hyf.editabletable.DISPLAY_ID_END) + hyf.editabletable.DISPLAY_ID_END.length == spanId.length))
        {
            var editSpan = document.getElementById(spanId.substring(0, spanId.length - hyf.editabletable.DISPLAY_ID_END.length) + hyf.editabletable.EDIT_ID_END);
            var contentHidden = document.getElementById(spanId.substring(0, spanId.length - hyf.editabletable.DISPLAY_ID_END.length) + hyf.editabletable.HTML_CONTENT_ID_END);

            //hide the edit span first to trigger validation bubble hidding etc
            hyf.util.hideComponent(editSpan);

            if (type == 'cancel')
            {
                var cell = hyf.editabletable.findParentElement(editSpan, 'td')
                //check for dojo widgets
                var hasWidget = false;
                if (hyf.util.hasWidgets(cell))
                {
                    hyf.util.destroyDojoWidgets(cell);
                    hasWidget = true;
                }
                editSpan.innerHTML = contentHidden.value;
                if (hasWidget)
                {
                    dojo.parser.parse(cell);
                }
            }
            else
            {
                var value = hyf.editabletable.getCellValue(editSpan);
                if (value == null || "undefined" == typeof(value) || value.length == 0)
                    value = " ";
                spans[i].innerHTML = '';
                spans[i].appendChild(document.createTextNode(value));
            }

            hyf.util.showComponent(spans[i]);

        }
    }


    //change the accept/cancel buttons back to edit/remove
    var editTd = document.getElementById(rowId + '_edit');
    if (editTd != null)
    {
        if (options.show_edit_btn)
            editTd.innerHTML = '<a class="'+options.classes.editBtn+'" href="#" onclick="hyf.editabletable.editRow(event, this); return false;" title="'+options.messages.editBtnTitle+'"><span>'+options.messages.editBtn+'</span></a>';
        else
            editTd.innerHTML = "&nbsp;";
    }

    var removeTd = document.getElementById(rowId + '_remove');
    if (removeTd != null)
    {
        removeTd.innerHTML = '<a class="'+options.classes.removeBtn+'" href="#" onclick="hyf.editabletable.removeRow(event, this); return false;" title="'+options.messages.removeBtnTitle+'"><span>'+options.messages.removeBtn+'</span></a>';
    }

    if ((editTd == null) && (removeTd == null))
    {
        var btnCont = document.getElementById(rowId + '_insertControlBtns');
        if (btnCont != null)
            btnCont.parentNode.removeChild(btnCont);
    }

    hyf.editabletable.currentRowId = null;
    dojo.removeClass(row, options.classes.editRow);
    dojo.addClass(row, options.classes.displayRow);

    //remove any temporary event handles added to process the edit functionality
    if (hyf.editabletable.docClickHandle)
    {
        hyf.detachEventHandler(hyf.editabletable.docClickHandle)
        hyf.editabletable.docClickHandle = null;
    }
    if (hyf.editabletable.rowClickHandle)
    {
        hyf.detachEventHandler(hyf.editabletable.rowClickHandle)
        hyf.editabletable.rowClickHandle = null;
    }
    if (hyf.editabletable.docKeyHandle)
    {
        hyf.detachEventHandler(hyf.editabletable.docKeyHandle)
        hyf.editabletable.docKeyHandle = null;
    }

    //if we support click to edit, then put the style changes back to indicate this behaviour
    if (options.single_click_edit || options.double_click_edit)
    {
        if (options.single_click_edit)
        {
            if (options.messages.clickToEditRowTitle != '')
                row.title = options.messages.clickToEditRowTitle;
        }
        else
        {
            if (options.messages.doubleClickToEditRowTitle != '')
                row.title = options.messages.doubleClickToEditRowTitle;
        }
        if (options.classes.clickToEditRow != '')
            dojo.addClass(row, options.classes.clickToEditRow);
    }
}

hyf.editabletable.retrieveNumberFromId = function(id, prefix)
{
    if (id.indexOf(prefix) == 0)
    {
        var num = '';
        var remainder = id.substring(prefix.length);
        num = parseInt(remainder);
        return num;
    }
    return null;
}

/**
 * Removes the specified row from the table.
 * @param row The ID of the row to remove, or the HTML element for the row (or a child of it)
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.removeRow = function(e, row)
{
    if (hyf.editabletable.currentRowId != null)
    {
        var currentEditTable = hyf.editabletable.findParentTable(document.getElementById(hyf.editabletable.currentRowId));
        if (hyf.editabletable.optionsCollection[currentEditTable.getAttribute('id')].force_accept_btn)
            hyf.editabletable.cancelChanges(null, hyf.editabletable.currentRowId);
        else
            hyf.editabletable.acceptChanges(null, hyf.editabletable.currentRowId);
    }

    //var row = document.getElementById(rowId);
    if (typeof(row) == 'string')
    {
        row = document.getElementById(row);
    }
    else
    {
        row = hyf.editabletable.findParentElement(row, 'tr');
    }

    var table = hyf.editabletable.findParentTable(row);

    //make sure this table is not disabled
    if (hyf.editabletable.isDisabled(table.getAttribute('id')))
        return;

    //call any pre remove change function to make sure it is allowed
    if (!hyf.editabletable.callChangeFunction(row.getAttribute('id'), 'remove'))
        return;

    //update repeat count field
    hyf.editabletable.manageCount(table, 'remove');

    var rowToAdjust = hyf.util.getNextElementSibling(row);

    //remove row from HTML
    hyf.util.destroyDojoWidgets(row);
    row.parentNode.removeChild(row);

    while (rowToAdjust != null)
    {
        //change IDs of all following rows to reduce repeat number part to prevent future conflicts
        var currentNum = hyf.editabletable.retrieveNumberFromId(rowToAdjust.getAttribute('id'), table.getAttribute('id'));

        hyf.editabletable.adjustRowForNewId(rowToAdjust, currentNum, parseInt(currentNum) - 1);

        rowToAdjust = hyf.util.getNextElementSibling(rowToAdjust);
    }

    hyf.editabletable.callChangeFunction(row.getAttribute('id'), 'remove_complete', table);

    hyf.editabletable.cancelEvent(e);
}

/**
 * Adjusts the provided row as required to change it from being the currentNum row number to
 * be the newNum row number.  This will adjusts all the ids and xpaths etc.
 * @param rowToAdjust The tr object to process.
 * @param currentnum The current row number for this row.
 * @param newNum The required row number for this row/
 * @private
 */
hyf.editabletable.adjustRowForNewId = function(rowToAdjust, currentNum, newNum)
{
    var table = hyf.editabletable.findParentTable(rowToAdjust);
    var currentId = table.getAttribute('id') + currentNum;
    var newId = table.getAttribute('id') + newNum;

    var hasWidget = false;
    //check for any dojo widgets in the row
    if (hyf.util.hasWidgets(rowToAdjust))
    {
        //loop through each cell to check which contains a widget
        for (var i = 0; i < rowToAdjust.cells.length; ++i)
        {
            var cellToAdjust = rowToAdjust.cells[i];

            //check for any dojo widgets in the cell
            if (hyf.util.hasWidgets(cellToAdjust))
            {
                //revert widget to HTML
                var currentValue = hyf.editabletable.getCellValue(cellToAdjust, 'data');
                //Destroy any dojo widgets in the row being inserted before processing
                hyf.util.destroyDojoWidgets(cellToAdjust);

                //find the edit span and adjust the HTML
                var editSpan = document.getElementById(rowToAdjust.id + i + hyf.editabletable.EDIT_ID_END);
                var editHTML = document.getElementById(rowToAdjust.id + i + hyf.editabletable.HTML_CONTENT_ID_END);

                editSpan.innerHTML = editHTML.value;

                //update value in the new HTML
                hyf.editabletable.setCellValue(cellToAdjust, currentValue);
                hasWidget = true;
            }
        }
    }

    hyf.editabletable.changeIds(rowToAdjust, currentId, newId);

    //change all row binding xpaths to reduce position number
    var spans = rowToAdjust.getElementsByTagName('span');
    for (var i = 0; i < spans.length; ++i)
    {
        var spanId = spans[i].getAttribute('id');
        if ((spanId != null) && (spanId.lastIndexOf(hyf.editabletable.EDIT_ID_END) + hyf.editabletable.EDIT_ID_END.length == spanId.length))
        {
            var editSpan = spans[i];
            hyf.editabletable.processXPath(table, editSpan, newNum);

            //update the hidden field storing the edit HTML so that it will include the new xpath values etc
            var contentHidden = dojo.query('input[id$="' + hyf.editabletable.HTML_CONTENT_ID_END + '"]', editSpan.parentNode)[0];
            if (contentHidden)
            {
                contentHidden.value = editSpan.innerHTML;
            }
        }
    }

    //reparse any dojo widgets if needed
    if (hasWidget)
    {
        dojo.parser.parse(rowToAdjust);
    }

}

/**
 * Moves the specified row one place in the speciifed direction.
 * @param row The id of the row to move, or an HTML element within the row
 * @param direction either 'up' or 'down' to indicate which way to move the row.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.reorderRow = function(e, row, direction)
{
    if (hyf.editabletable.currentRowId != null)
    {
        var currentEditTable = hyf.editabletable.findParentTable(document.getElementById(hyf.editabletable.currentRowId));
        if (hyf.editabletable.optionsCollection[currentEditTable.getAttribute('id')].force_accept_btn)
            hyf.editabletable.cancelChanges(null, hyf.editabletable.currentRowId);
        else
            if (!hyf.editabletable.acceptChanges(null, hyf.editabletable.currentRowId))
                return; //can't close the currently open row so dont want to reorder yet
    }

    if (typeof(row) == 'string')
    {
        row = document.getElementById(row);
    }
    else
    {
        row = hyf.editabletable.findParentElement(row, 'tr');
    }

    var table = hyf.editabletable.findParentTable(row)

    var currentNum = hyf.editabletable.retrieveNumberFromId(row.getAttribute('id'), table.getAttribute('id'));

    var firstRow, secondRow;
    var firstRowNum, secondRowNum;

    if (direction == 'up')
    {
        if (currentNum == 1)
        {
            hyf.editabletable.cancelEvent(e);
            return;
        }
        firstRow = hyf.util.getPreviousElementSibling(row);
        secondRow = row;
        firstRowNum = Number(currentNum) - 1;
        secondRowNum = currentNum;
    }
    else
    {
        if (currentNum == hyf.editabletable.manageCount(table, 'get'))
        {
            hyf.editabletable.cancelEvent(e);
            return;
        }
        firstRowNum = currentNum;
        secondRowNum = Number(currentNum) + 1;
        firstRow = row;
        secondRow = hyf.util.getNextElementSibling(row);
    }

    //switch the HTML ordering
    secondRow.parentNode.insertBefore(secondRow, firstRow);

    //update the first row to a temporary id initially so as it wont conflict with the second row
    //eg could otherwise get dojo errors due to multiple widgets with the same names
    hyf.editabletable.adjustRowForNewId(firstRow, firstRowNum, secondRowNum + 'ET_TEMP');

    //now update the second row to the correct new ids
    hyf.editabletable.adjustRowForNewId(secondRow, secondRowNum, firstRowNum);

    //finally put the alrady updatd first row tot he correct value.  This now wont clash as the
    //original second row has already been converted.
    hyf.editabletable.adjustRowForNewId(firstRow, secondRowNum + 'ET_TEMP', secondRowNum);

    hyf.editabletable.callChangeFunction(row.getAttribute('id'), 'reorder_' + direction);

    hyf.editabletable.cancelEvent(e);
}

/** Stores the name of event handlers that we will process when chaining id values for an element.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.eventNames = ['onclick', 'onfocus', 'onblur', 'onmouseover', 'onmouseout', 'onmousedown', 'onmouseup', 'onmousemove', 'onkeypress', 'onkeyup', 'onkeydown', 'onchange'];

/**
 * Changes the name/ids etc of every HTML component in the given element
 * so that references to oldId in the strings are replaced with newId.
 * @param deep Optional Set whether to process all child nodes. Default true.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.changeIds = function(elem, oldId, newId, deep)
{
    if (elem.nodeType == 1)
    {
        //QUESTION: Should we just check all attributes?
        if (elem.getAttribute('id') != null)
            elem.setAttribute('id', hyf.editabletable.replaceString(elem.getAttribute('id'), oldId, newId));
        if (elem.getAttribute('name') != null)
        {
            if ((dojo.isIE < 8) && ((elem.tagName.toLowerCase() == 'input') || (elem.tagName.toLowerCase() == 'a') || (elem.tagName.toLowerCase() == 'select') || (elem.tagName.toLowerCase() == 'textarea')))
            {
                //IE versions before 8 do not support dynamicaly changing the name attribute properly, so instead need to recreate the element with the new name

                //We use the outerHTML IE property below, but that will not include any events that wern't in the original HTML string.
                //Also, if any events have been added to via dojo.connect the initial content will no longer be present.
                //Therefore, for now we just check for this scenario to try and restore the original event content
                //This still means that events added to this element could be lost.
                //This code doesnt work with the dojo version we now use as there is no way to get the original event script
                //Are we worried about supporting IE < 8 anymore??
                /*for (var i = 0; i < hyf.editabletable.eventNames.length; ++i)
                {
                    var eventName = hyf.editabletable.eventNames[i];
                    if (elem[eventName] && (typeof(elem[eventName].target) != 'undefined') && (elem[eventName].target != null))
                    {
                        var funcString = '' + dojo._ie_listener.handlers[elem[eventName].target];
                        funcString = dojo.trim(funcString.substring(funcString.indexOf('{') +1, funcString.lastIndexOf('}')));
                        elem.setAttribute(eventName, funcString);
                    }
                }*/

                var newHTML = hyf.editabletable.replaceString(elem.outerHTML, oldId, newId);
                var tempDiv = document.createElement('div');
                tempDiv.innerHTML = newHTML;
                newElem = tempDiv.firstChild;
                elem.parentNode.replaceChild(newElem, elem);
                elem = newElem;
            }
            else
                elem.setAttribute('name', hyf.editabletable.replaceString(elem.getAttribute('name'), oldId, newId));
        }
        //Older IE versions seem to make the img src attribute available to get via href, but throw an error
        //if you try and set it, so only do this for anchor tags.
        if ((elem.tagName.toLowerCase() == 'a') && (elem.getAttribute('href') != null))
            elem.setAttribute('href', hyf.editabletable.replaceString(elem.getAttribute('href'), oldId, newId));


        if (elem.getAttribute('for') != null)
            elem.setAttribute('for', hyf.editabletable.replaceString(elem.getAttribute('for'), oldId, newId));
        if (elem.getAttribute('htmlFor') != null)
            elem.setAttribute('htmlFor', hyf.editabletable.replaceString(elem.getAttribute('htmlFor'), oldId, newId));
        if (elem.getAttribute('_element') != null)
            elem.setAttribute('_element', hyf.editabletable.replaceString(elem.getAttribute('_element'), oldId, newId));

        //hanlde updating the custom WM repeatId attribute
        if (hyf.util.getWebMakerAttribute(elem, 'repeatId'))
            hyf.util.setWebMakerAttribute(elem, 'repeatId', hyf.editabletable.replaceString(hyf.util.getWebMakerAttribute(elem, 'repeatId'), oldId, newId))

        //if this is a hidden field storing the html content, then we need to update this html string value
        //to contain the new id where needed
        if ((elem.tagName.toLowerCase() == 'input') && (elem.type == 'hidden') &&
            (elem.id.lastIndexOf(hyf.editabletable.HTML_CONTENT_ID_END) + hyf.editabletable.HTML_CONTENT_ID_END.length == elem.id.length))
        {
            elem.value = hyf.editabletable.replaceString(elem.value, oldId, newId);
        }

        if ((typeof(deep) == 'undefined') || (deep))
        {
            //now process any children elements
            for (var i = 0 ;i < elem.childNodes.length; ++i)
            {
                hyf.editabletable.changeIds(elem.childNodes.item(i), oldId, newId);
            }
        }
    }
}

/** Function process xpath
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.processXPath = function(table, container, predicateValue)
{
    var inputs = container.getElementsByTagName('input');
    for (var i = 0; i < inputs.length; ++i)
    {
        if (inputs[i].type == 'hidden')
        {
            /*if ((inputs[i].name == (fieldID + '_xpath')) ||
                (inputs[i].name.indexOf('xgf_' + fieldID + '_xpath') == 0))*/
            if (inputs[i].name.lastIndexOf('_xpath') == inputs[i].name.length - 6)
            {
                inputs[i].value = hyf.editabletable.processXPathString(table, inputs[i].value, predicateValue, null);
            }
            else if ((inputs[i].name.lastIndexOf('_xpath') == inputs[i].name.length - 6) ||
                (inputs[i].name.indexOf('xgf_') == 0 && inputs[i].name.indexOf('_xpath_') != -1))
            {
                inputs[i].value = hyf.editabletable.processXPathString(table, inputs[i].value, predicateValue, inputs[i].name.substr(inputs[i].name.lastIndexOf('_xpath_') + 6));
            }
        }
    }
}

/** Function process xpath string
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.processXPathString = function(table, xpathString, predicateValue, action)
{
    //find the context xpath for the repeat
    var contextXPath;
    var possibleContexts = table.parentNode.getElementsByTagName('input');
    for (var i = 0; i< possibleContexts.length; ++i)
    {
        if ((possibleContexts[i].type == 'hidden') &&
            (possibleContexts[i].name.indexOf('hyfrepeat-') == 0) &&
            (possibleContexts[i].name.lastIndexOf('-location') + 9 == possibleContexts[i].name.length) &&
            (action == null))
        {
            //is the context field
            contextXPath = possibleContexts[i].value;
            break;
        }
        else if ((possibleContexts[i].type == 'hidden') &&
            (possibleContexts[i].name.indexOf('xgf_hyfrepeat-') == 0) &&
            (possibleContexts[i].name.lastIndexOf('-location' + action) + (action.length) + 9 == possibleContexts[i].name.length) &&
            (action != null))
        {
            //is the context field
            contextXPath = possibleContexts[i].value;
            break;
        }
    }

    var newXPath = xpathString;

    //can only adjust if xpath starts with context
    if (xpathString.indexOf(contextXPath) == 0)
    {
        var remainder = xpathString.substring(contextXPath.length);
        if (remainder.indexOf('[') == 0)
        {
            var closingIndex = remainder.indexOf(']');

            if (typeof(predicateValue) == 'undefined')
            {
                var number = remainder.substring(1, closingIndex);
                number = parseInt(number) - 1;
                newXPath = contextXPath + '[' + number + remainder.substring(closingIndex);
            }
            else
            {
                newXPath = contextXPath + '[' + predicateValue + remainder.substring(closingIndex);
            }

            //alert(xpathString + '\n' + newXPath);
        }
    }

    return newXPath;
}

/**
 * Updates the value of the repeat count hidden field for the given table,
 * by either adding or removing 1 from the current value.
 * @param table The HTML table object representing the repeat to adjust the count for.
 * @param change either 'add' or 'remove' to indicate whetehr to add 1 to the count, or to reduce it by 1.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.manageCount = function(table, change)
{
    var possibleCounts = table.parentNode.getElementsByTagName('input');
    for (var i = 0; i< possibleCounts.length; ++i)
    {
        if ((possibleCounts[i].type == 'hidden') &&
            (possibleCounts[i].name.indexOf('hyfrepeat-') == 0) &&
            (possibleCounts[i].name.lastIndexOf('-count') + 6 == possibleCounts[i].name.length))
        {
            //is the count field
            var currentCount = parseInt(possibleCounts[i].value);
            if (change == 'get')
                return currentCount;
            else if (change == 'add')
                currentCount++;
            else
                currentCount--;

            possibleCounts[i].value = currentCount;
            break;
        }
    }
}

/**
 * Inserts a new row into the table using the contents of the new row fields.
 * @param tableId The ID of the table to insert the new row into.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.insertRow = function(e, tableId)
{
    if (hyf.editabletable.currentRowId != null)
    {
        var currentEditTable = hyf.editabletable.findParentTable(document.getElementById(hyf.editabletable.currentRowId));
        if (hyf.editabletable.optionsCollection[currentEditTable.getAttribute('id')].force_accept_btn)
            hyf.editabletable.cancelChanges(null, hyf.editabletable.currentRowId);
        else
            if (!hyf.editabletable.acceptChanges(null, hyf.editabletable.currentRowId))
                return; //can't close the currently open row so can't add a new one in
    }

    //make sure this table is not disabled
    if (hyf.editabletable.isDisabled(tableId))
        return;

    var newRow = document.getElementById(tableId + '_newRowContent').rows[0];

    //check if we need to validate first
    if ((hyf.editabletable.optionsCollection[tableId].show_insert_row) && (hyf.editabletable.optionsCollection[tableId].validate))
    {
        if (hyf.validation.validateContainer(newRow))
        {
            hyf.editabletable.insertRowImpl(tableId);
        }
    }
    else
    {
        var newRowId = hyf.editabletable.insertRowImpl(tableId);

        if (!hyf.editabletable.optionsCollection[tableId].show_insert_row)
        {
            //make sure the newly inserted row is visible, and editable
            hyf.util.showComponent(newRowId);
            hyf.editabletable.editRow(null, newRowId);
            hyf.editabletable.currentRowEditMode = 'insert';
        }
    }


    hyf.editabletable.cancelEvent(e)
}

/**
 * Actual implementaion of the insertRow functionality
 * @param tableId The ID of the table to insert the new row into.
 * @return The newly inserted row ID
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.insertRowImpl = function(tableId)
{
    var table = document.getElementById(tableId);
    var options = hyf.editabletable.optionsCollection[table.getAttribute('id')];

    var currentCount = hyf.editabletable.manageCount(table, 'get');
    var newCount = parseInt(currentCount) + 1;
    var existingIdPrefix = tableId + 'BlankEntry';
    var newIdPrefix = tableId + newCount;

    var newRow = document.getElementById(tableId + '_newRowContent').rows[0];

    //temporarily remove the disabled setting for the binding xpaths
    //so that they will be enabled in the newly inserted row
    dojo.query('input[type="hidden"][name$="_xpath"], input[type="hidden"][name*="_xpath_xga_"]', newRow).forEach(function(item){ item.disabled = false; });

    //create new HTML row - this will become the new blank insert row
    var blankRow = newRow.cloneNode(false);
    //document.createElement('tr');
    blankRow.setAttribute('id', newRow.getAttribute('id'));
    //newRow.setAttribute('id', hyf.editabletable.replaceString(newRow.getAttribute('id'), existingIdPrefix, newIdPrefix));
    blankRow.className = newRow.className;

    hyf.editabletable.changeIds(newRow, existingIdPrefix, newIdPrefix, false);

    dojo.removeClass(newRow, options.classes.insertRow);
    dojo.addClass(newRow, options.classes.insertedRow);
    dojo.removeClass(newRow, options.classes.highlightBackground);

    //special handling for radio/checkbox controls in IE6 to ensure the values do not get lost on insert
    if (dojo.isIE < 8)
    {
        dojo.query("input[type=radio], input[type=checkbox]", newRow).forEach(function(node) {
            if (node.checked)
                node.defaultChecked = true;
        });
    }

    //position both rows in the correct location in the HTML
    document.getElementById(tableId + '_body').appendChild(newRow);
    document.getElementById(tableId + '_newRowContent').insertBefore(blankRow, document.getElementById(tableId + '_newRowContent').firstChild);

    for (var i = 0; i < newRow.cells.length; ++i)
    {
        var existingCell = newRow.cells[i];
        if (existingCell.getAttribute('id') != tableId + '_insert')
        {
            var newCell = document.createElement('td');
            for (var att = 0; att < existingCell.attributes.length; ++att)
            {
                var attObj = existingCell.attributes[att];
                if ((attObj.nodeName == 'class') && (dojo.isIE < 8))
                    newCell.className = attObj.nodeValue;
                else
                    newCell.setAttribute(attObj.nodeName, attObj.nodeValue);
            }
            newCell.cssText = existingCell.cssText;

            var cellId = existingCell.getAttribute('id')

            var ihHidden = document.getElementById(cellId + hyf.editabletable.HTML_CONTENT_ID_END);
            var ihClone = ihHidden.cloneNode(true);


            //if there are any dojo widgets we need to revert back to standard HTML before trying to change ids
            if (hyf.util.hasWidgets(existingCell))
            {
                //revert widget to HTML
                var currentValue = hyf.editabletable.getCellValue(existingCell, 'data');
                //Destroy any dojo widgets in the row being inserted before processing
                hyf.util.destroyDojoWidgets(existingCell);
                existingCell.innerHTML = ihHidden.value;
                //update value in the new HTML
                hyf.editabletable.setCellValue(existingCell, currentValue);
            }
            else
                ihHidden.parentNode.removeChild(ihHidden);


            hyf.editabletable.changeIds(existingCell, existingIdPrefix, newIdPrefix);

            blankRow.appendChild(newCell);

            //update the content of the blank row cell to revert to the intitial HTML
            if (ihClone != null)
            {
                newCell.innerHTML = ihClone.value;
                newCell.appendChild(ihClone);
            }
        }
        else
            blankRow.appendChild(existingCell);
    }

    //call the content inserted hook for the newly created row
    hyf.hooks.contentInserted(blankRow);

    //Create any dojo widgets in the new blank row.
    dojo.parser.parse(blankRow);
    //redisable any xpath fields for the blank row to stop failed binding
    dojo.query('input[type="hidden"][name$="_xpath"], input[type="hidden"][name*="_xpath_xga_"]', blankRow).forEach(function(item){ item.disabled = true; });

    //set binding field xpaths for the new row
    for (var i = 0; i < newRow.cells.length; ++i)
    {
        hyf.editabletable.processXPath(table, newRow.cells[i], newCount);
    }

    //convert new row to display only
    hyf.editabletable.processRow(newRow);

    //Recreate any dojo widgets in the new inserted row.
    dojo.parser.parse(newRow);
    //update the display only values for those cells that contain dojo widgets now they have been parsed
    if (hyf.util.hasWidgets(newRow))
    {
        var widgets = hyf.util.getDijitWidgets(newRow);
        for(var i = 0; i < widgets.length; ++i)
        {
            hyf.editabletable.updateDisplayOnlyValue(hyf.editabletable.findParentElement(widgets[i].domNode, 'td'));
        }
    }

    //increase repeat count field
    hyf.editabletable.manageCount(table, 'add');

    hyf.editabletable.callChangeFunction(newRow.getAttribute('id'), 'insert');

    return newRow.getAttribute('id');
}

/**
 * Calls the change function defined for this table (if any) passing through the details of the change
 * @param rowId The id of the row in question
 * @param type The type of change, 'insert', 'edit', 'remove', 'remove_complete', 'reorder_up', 'reorder_down'
 * @param table (Optional) The table object this change applies to.  If not provided, will be found from given rowId.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.callChangeFunction = function(rowId, type, table)
{
    if (!table)
    {
        var row = document.getElementById(rowId);
        if (row != null)
        {
            var table = hyf.editabletable.findParentTable(row);
        }
    }

    if (table)
    {
        var cf = hyf.editabletable.optionsCollection[table.getAttribute('id')].change_function;
        if (cf != null)
        {
            var resp;
            if (typeof(cf) == 'string')
            {
                var evalString = cf + '("' + type + '", "' + rowId + '")';
                resp = eval(evalString);
            }
            else if (typeof(cf) == 'function')
            {
                resp = cf(type, rowId);
            }

            if (typeof(resp) == 'boolean' && resp == false)
                return false;
            else
                return true;
        }
    }
    return true;
}

/**
 * Replaces all of the occurances of the 'match' string in the 'str' string
 * with the contents of the 'replace' string.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.replaceString = function(str, match, replace)
{
    //alert('replacing string ' + match + ' with ' + replace + ' in ' + str);
    var re = new RegExp(match, 'g');
    return str.replace(re, replace);
}

/**
 * Finds the last table object that has been output to the document.
 * This is used as the page is being rendered to initialise any ediatbale tables
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.getLastTableOutput = function()
{
    var elem = document.lastChild;
    while (elem.lastChild != null)
    {
        elem = elem.lastChild;
    }
    if (elem.nodeType != 1)
    {
        var prevElem = hyf.util.getPreviousElementSibling(elem);
        if (prevElem == null)
        {
            elem = elem.parentNode;
        }
        else
        {
            elem = prevElem;
        }
    }

    //at this point elem should be the script tag containing the init script.
    //For old style containers, the table should be the previous element, so jst
    //find the tbale within the parentNode.
    //for new style groups need to find the preceding layoutContainerContent element
    //which should have the table within it.
    var table = null;
    if (dojo.hasClass(elem.parentNode, 'layoutContainerContent'))
    {
        var prevElem = hyf.util.getPreviousElementSibling(elem.parentNode);
        while (prevElem != null && !dojo.hasClass(prevElem, 'layoutContainerContent'))
        {
            prevElem = hyf.util.getPreviousElementSibling(prevElem);
        }
        if (prevElem != null)
            table = prevElem.parentNode.getElementsByTagName('table')[0];
    }
    else
        table = elem.parentNode.getElementsByTagName('table')[0];

    return table;
}



/**
 * Checks if the given field is actually contained with an insert new entry row
 * for an editable table control.
 * @param field The HTML field to check
 * @param className (Optional) The class name to check for to indicate the insert row.
 *              This should not normally be provided, as it will be determined automatically.
 * @return boolean value, true of the field is within a new entry row, false otherwise.
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.checkNewRowField = function(field, className)
{
    //work out the class name to check for
    if ((typeof(className) == 'undefined') || (className == null))
    {
        var parentTable = hyf.editabletable.findParentTable(field);
        while (parentTable && !hyf.editabletable.optionsCollection[parentTable.getAttribute('id')])
        {
            parentTable = hyf.editabletable.findParentTable(parentTable.parentNode);
        }

        if (!parentTable)
            return false;

        className = hyf.editabletable.optionsCollection[parentTable.getAttribute('id')].classes.insertRow;

    }

    if (dojo.hasClass(field, className))
    {
        return true;
    }
    else if (field.parentNode != null)
    {
        return hyf.editabletable.checkNewRowField(field.parentNode, className);
    }
    else
    {
        return false;
    }
}



/**
 * When first displayed, any dojo widgets will not yet have been rendered.
 * Therefore, the display only value shown will not have been converted by the widget
 * eg The currency widget adds the $ sign at the start, and formats the number.
 * This method goes through all the tables found in the given container,
 * and updates the displayed value for any widget found.
 * This is connected to the widgetsParsed hook to make sure it happens after dojo parsing
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.processInitialValues = function(container)
{
    if ((typeof(dijit) != 'undefined') && (typeof(dijit.findWidgets) == 'function'))
    {
        for (tableId in hyf.editabletable.optionsCollection)
        {
            //check if it is contained within the provided container.
            if (dojo.query('#' + tableId, container).length > 0)
            {
                var table = document.getElementById(tableId);

                hyf.editabletable.processInitialValuesForTable(table);
            }
        }
    }
}
dojo.connect(hyf.hooks, 'widgetsParsed', hyf.editabletable.processInitialValues);



hyf.editabletable.processInitialValuesForTable = function(table)
{
    var widgets = hyf.util.getDijitWidgets(table);

    for (var i = 0; i < widgets.length; ++i)
    {
        var w = widgets[i];

        var td = hyf.editabletable.findParentElement(w.domNode, 'td');

        hyf.editabletable.updateDisplayOnlyValue(td);
    }
}

/**
 * This method updates the display only value in the given cell to make
 * sure that it matches that stored in the editable control in the cell.
 * This assumes that the cell has already been processed by the processRow method
 * above to create the editable and display only spans.
 * @param cell The td representing the cell to update
 * @private
 * @author Hyfinity Limited
 */
hyf.editabletable.updateDisplayOnlyValue = function(cell)
{
    var displayValue = hyf.editabletable.getCellValue(cell);
    if (displayValue == null || "undefined" == typeof(displayValue) || displayValue.length == 0)
        displayValue = " ";

    //find the display span for this cell
    var spans = cell.getElementsByTagName('span');
    for (var i = 0; i < spans.length; ++i)
    {
        var spanId = spans[i].getAttribute('id');
        if ((spanId != null) && (spanId.lastIndexOf(hyf.editabletable.DISPLAY_ID_END) + hyf.editabletable.DISPLAY_ID_END.length == spanId.length))
        {
            spans[i].innerHTML = '';
            spans[i].appendChild(document.createTextNode(displayValue));
            break;
        }
    }
}


/**
 * Checks if the editable table with the given id should currently be disabled.
 * @param tableId The ID of the editable table to check.
 * @return boolean true if this table should be disabled..
 */
require(["dojo/query", "dojo/NodeList-traverse"], function(query){
    hyf.editabletable.isDisabled = function(tableId)
    {
        if (hyf.editabletable.optionsCollection[tableId])
        {
            var tableElem = document.getElementById(tableId);

            var tableNL = query.NodeList();
            tableNL.push(tableElem);

            if (dojo.hasClass(tableElem, 'isDisabled') || (tableNL.closest('.isDisabled').length > 0))
            {
                return true;
            }
        }

        return false;
    }
});


