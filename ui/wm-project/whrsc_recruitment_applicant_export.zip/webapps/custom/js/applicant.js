var applicantRating = function(){
    
	var cnt = $('#h_applicant_count').val();
    var vinnum = ["00000000"];
	var virtualCnt = cnt;
	
	var getRestData = $('#h_form_data').val();
 	if(getRestData!='') {
		var x2js = new X2JS();
		var getRestDataXML =  x2js.xml_str2json(getRestData);
	}

	if(cnt=="") {
		virtualCnt = 1;
		hyf.util.disableComponent('applicants_group');

	}	

	for (var index = 1; index <= virtualCnt; index++) {
        
		var vnnNumber =  $('#record_repeat' + index + 'A_AN').val();
		var savedCnt = "";
		if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB!=undefined) {
			if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT!=undefined) {
				if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT.APPLICANT!=undefined) {
					var applicants = getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT.APPLICANT;
					savedCnt = applicants.status.record_count;	
					if(savedCnt=="0") {
						//do nothing
					}
					else if(savedCnt=="1") {
						if(vnnNumber==applicants.record.ANN_NUMBER) {
							$('#record_repeat' + index + 'A_EM').val(applicants.record.EVALUATION_METHOD);
							var raters = applicants.record.RATER;
							var split = raters.split(',');
							for(var sIndx=0;sIndx < split.length;sIndx++) {
								$('input[type=checkbox][name=record_repeat'+ index + 'A_R_M][value=\"' + split[sIndx] + '\"]').prop("checked", true);					
							}			
							
							
							var aDmq = applicants.record.A_DMQ;
							if(aDmq!='') {
								aDmq = new Date(aDmq);
								$('#record_repeat' + index + 'A_DMQ').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, aDmq));
							}
							var aDas = applicants.record.DATE_APPS_TO_SME_QRB;
							if(aDas!='') {
								aDas = new Date(aDas);
								$('#record_repeat' + index + 'A_DAS').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDas));
							}
							var aDae = applicants.record.DATE_APPS_RECD_SME_QRB;
							if(aDae!='') {
								aDae = new Date(aDae);
								$('#record_repeat' + index + 'A_DAE').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDae));
							}
						}	
					}
					else { 
						for (var indx =0; indx < savedCnt; indx++) {
							if(vnnNumber==applicants.record[indx].ANN_NUMBER) {
								$('#record_repeat' + index + 'A_EM').val(applicants.record[indx].EVALUATION_METHOD);
								var raters = applicants.record[indx].RATER;
								var split = raters.split(',');
								for(var sIndx=0;sIndx < split.length;sIndx++) {
									$('input[type=checkbox][name=record_repeat'+ index + 'A_R_M][value=\"' + split[sIndx] + '\"]').prop("checked", true);					
								}			
								
								
								var aDmq = applicants.record[indx].A_DMQ;
								if(aDmq!='') {
									aDmq = new Date(aDmq);
									$('#record_repeat' + index + 'A_DMQ').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, aDmq));
								}
								var aDas = applicants.record[indx].DATE_APPS_TO_SME_QRB;
								if(aDas!='') {
									aDas = new Date(aDas);
									$('#record_repeat' + index + 'A_DAS').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDas));
								}
								var aDae = applicants.record[indx].DATE_APPS_RECD_SME_QRB;
								if(aDae!='') {
									aDae = new Date(aDae);
									$('#record_repeat' + index + 'A_DAE').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDae));
								}
							}
						}	
					}
				}
			}
		}
		
		
		
		
		//calendar icon tabindex
        $('#record_repeat' + index + 'A_DMQ_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DAN_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DANR_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DAS_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DAE_calendar_anchor').attr('tabindex', 830);
        
        vinnum[index] = $('#record_repeat' + index + 'A_VIN').val();
        		
        
        $("[id^=record_repeat" + index + "A_USASTAFF]").on('click', function(event){ 
            var id = $(this).attr("id");
             
            if(id.indexOf("_container") == -1){
                var num = id.replace(/[^0-9]/g,"");
                window.open('https://usastaffing.gov/applicant/applicantoverview/edit/' + vinnum[num] + '','_blank');
             	//alert(vinnum[num]);
            }

        });
        
        $("[id^=record_repeat" + index + "A_ROSTER]").on('click', function(event){ 
			if(cnt!="") {
				var id = $(this).attr("id");
				
				 if(id.indexOf("_container") == -1){
					var num = id.replace(/[^0-9]/g,"");
					window.open('/usasrwsc/usas/reportHTML/applicantroster/' + vinnum[num] + '','_blank');
				 
				}
			}

        });
        
        $("[id^=record_repeat" + index + "A_NOTIFI]").on('click', function(event){ 
            if(cnt!="") {
				var id = $(this).attr("id");
				
				 if(id.indexOf("_container") == -1){
					var num = id.replace(/[^0-9]/g,"");
					window.open('/usasrwsc/usas/reportHTML/applicantnotification/' + vinnum[num] + '','_blank');
					//alert(vinnum[num]);
				}
			}
        });
        
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_AN');
        $('#record_repeat' + index + 'A_AN').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_TNA');
        $('#record_repeat' + index + 'A_TNA').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_TNQA');
        $('#record_repeat' + index + 'A_TNQA').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_TNR');
        $('#record_repeat' + index + 'A_TNR').css('background-color', '#efefef');
		//WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_DMQ');
		//$('#record_repeat' + index + 'A_DMQ_calendar_anchor').addClass('hidden');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_DAN');
        $('#record_repeat' + index + 'A_DAN').css('background-color', '#efefef');
		$('#record_repeat' + index + 'A_DAN_calendar_anchor').addClass('hidden');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_DANR');
        $('#record_repeat' + index + 'A_DANR').css('background-color', '#efefef');
		$('#record_repeat' + index + 'A_DANR_calendar_anchor').addClass('hidden');

		$("#record_repeat" + index + "A_EM").attr("_required", "false");
		
		
		//inidtRater(index);
        
        utility.multiSelectFD('record_repeat' + index+ 'A_R',1);

		$("input[type=checkbox][name=record_repeat"+ index+ "A_R_M]").trigger("change");
        
        $('#record_repeat' + index+ 'A_R').attr("title", "Please select using space and arrows key.");
        
        $("#record_repeat" + index + "A_EM").on('change', function() {
            if($("#record_repeat" + index + "A_EM").val() =="")
            {
                $("#record_repeat" + index + "A_EM").attr("_required", "true");
            }
            else
                $("#record_repeat" + index + "A_EM").attr("_required", "false");
        });

	}
    
    

}
