var applicantRating = function(){
    
	var cnt = $('#h_applicant_count').val();
    var vinnum = ["00000000"];
	var virtualCnt = cnt;
	
	var getRestData = $('#h_form_data').val();
 	if(getRestData!='') {
		var x2js = new X2JS();
		var getRestDataXML =  x2js.xml_str2json(getRestData);
	}

	if(cnt=="") {
		virtualCnt = 1;
		hyf.util.disableComponent('applicants_group');

	}
    
    var actName = WHRSCMain.activityOption.getActivityName();
	

	for (var index = 1; index <= virtualCnt; index++) {
        
		var vnnNumber =  $('#record_repeat' + index + 'A_AN').val();
		var savedCnt = "";
		if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB!=undefined) {
			if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT!=undefined) {
				if(getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT.APPLICANT!=undefined) {
					var applicants = getRestDataXML.FORM_DATA.FIELD_DATA_CLOB.DOCUMENT.APPLICANT;
					savedCnt = applicants.status.record_count;	
					if(savedCnt=="0") {
						//do nothing
					}
					else if(savedCnt=="1") {
						if(vnnNumber==applicants.record.ANN_NUMBER) {
							$('#record_repeat' + index + 'A_EM').val(applicants.record.EVALUATION_METHOD);
							var raters = applicants.record.RATER;
							var split = raters.split(',');
							for(var sIndx=0;sIndx < split.length;sIndx++) {
								$('input[type=checkbox][name=record_repeat'+ index + 'A_R_M][value=\"' + split[sIndx] + '\"]').prop("checked", true);					
							}			
							
							
							var aDmq = applicants.record.A_DMQ;
							if(aDmq!='') {
								aDmq = new Date(aDmq);
								$('#record_repeat' + index + 'A_DMQ').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, aDmq));
							}
							var aDas = applicants.record.DATE_APPS_TO_SME_QRB;
							if(aDas!='') {
								aDas = new Date(aDas);
								$('#record_repeat' + index + 'A_DAS').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDas));
							}
							var aDae = applicants.record.DATE_APPS_RECD_SME_QRB;
							if(aDae!='') {
								aDae = new Date(aDae);
								$('#record_repeat' + index + 'A_DAE').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDae));
							}
                            //New Added Fields
                            var aDqsd = applicants.record.DATE_QUAL_SENT_DEU;
							if(aDqsd!='') {
								aDqsd = new Date(aDqsd);
								$('#record_repeat' + index + 'A_DQSD').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDqsd));
							}
                            var aDqa = applicants.record.DATE_QUAL_APPROVED;
							if(aDqa!='') {
								aDqa = new Date(aDqa);
								$('#record_repeat' + index + 'A_DQA').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDqa));
							}
                            $('#record_repeat' + index + 'A_QRN').val(applicants.record.QUAL_REVIEW_NOTES);							
						}	
					}
					else { 
						for (var indx =0; indx < savedCnt; indx++) {
							if(vnnNumber==applicants.record[indx].ANN_NUMBER) {
								$('#record_repeat' + index + 'A_EM').val(applicants.record[indx].EVALUATION_METHOD);
								var raters = applicants.record[indx].RATER;
								var split = raters.split(',');
								for(var sIndx=0;sIndx < split.length;sIndx++) {
									$('input[type=checkbox][name=record_repeat'+ index + 'A_R_M][value=\"' + split[sIndx] + '\"]').prop("checked", true);					
								}			
								var aDmq = applicants.record[indx].A_DMQ;
								if(aDmq!='') {
									aDmq = new Date(aDmq);
									$('#record_repeat' + index + 'A_DMQ').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, aDmq));
								}
								var aDas = applicants.record[indx].DATE_APPS_TO_SME_QRB;
								if(aDas!='') {
									aDas = new Date(aDas);
									$('#record_repeat' + index + 'A_DAS').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDas));
								}
								var aDae = applicants.record[indx].DATE_APPS_RECD_SME_QRB;
								if(aDae!='') {
									aDae = new Date(aDae);
									$('#record_repeat' + index + 'A_DAE').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDae));
								}
                                //New Added Fields
                                var aDqsd = applicants.record[indx].DATE_QUAL_SENT_DEU;
                                if(aDqsd!='') {
                                    aDqsd = new Date(aDqsd);
                                    $('#record_repeat' + index + 'A_DQSD').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDqsd));
                                }
                                var aDqa = applicants.record[indx].DATE_QUAL_APPROVED;
                                if(aDqa!='') {
                                    aDqa = new Date(aDqa);
                                    $('#record_repeat' + index + 'A_DQA').val(utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'},aDqa));
                                }
                                $('#record_repeat' + index + 'A_QRN').val(applicants.record[indx].QUAL_REVIEW_NOTES);		
							}
						}	
					}
				}
			}
		}
		
		//508 setup 
    	$('#record_repeat' + index + 'A_EM_label').attr('title', 'Asterisk denotes a required field');
		
		
		//calendar icon tabindex
        $('#record_repeat' + index + 'A_DMQ_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DAN_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DANR_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DAS_calendar_anchor').attr('tabindex', 830);
        $('#record_repeat' + index + 'A_DAE_calendar_anchor').attr('tabindex', 830);
        
        $('#record_repeat' + index + 'A_DMQ_label').attr('title', 'mm/dd/yyyy');
        $('#record_repeat' + index + 'A_DAS_label').attr('title', 'mm/dd/yyyy');
        $('#record_repeat' + index + 'A_DAE_label').attr('title', 'mm/dd/yyyy');
        
        vinnum[index] = $('#record_repeat' + index + 'A_VIN').val();
        
        if(actName!="DEU Reviews/ Approves/Creates Vacancy/Cert") {
            WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_QRN');
            $('#record_repeat' + index + 'A_QRN').css('background-color', '#efefef');
        }
        		
        
        $("[id^=record_repeat" + index + "A_USASTAFF]").on('click', function(event){ 
            var id = $(this).attr("id");
             
            if(id.indexOf("_container") == -1){
                var num = id.replace(/[^0-9]/g,"");
                window.open('https://usastaffing.gov/applicant/applicantoverview/edit/' + vinnum[num] + '','_blank');
             	//alert(vinnum[num]);
            }

        });
        
        $("[id^=record_repeat" + index + "A_ROSTER]").on('click', function(event){ 
			if(cnt!="") {
				var id = $(this).attr("id");
				
				 if(id.indexOf("_container") == -1){
					var num = id.replace(/[^0-9]/g,"");
					window.open('/usasrwsc/usas/reportHTML/applicantroster/' + vinnum[num] + '','_blank');
				 
				}
			}

        });
        
        $("[id^=record_repeat" + index + "A_NOTIFI]").on('click', function(event){ 
            if(cnt!="") {
				var id = $(this).attr("id");
				
				 if(id.indexOf("_container") == -1){
					var num = id.replace(/[^0-9]/g,"");
					window.open('/usasrwsc/usas/reportHTML/applicantnotification/' + vinnum[num] + '','_blank');
					//alert(vinnum[num]);
				}
			}
        });
        
        $('#record_repeat' + index + 'A_QRN').attr('_type', 'text');
        
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_AN');
        $('#record_repeat' + index + 'A_AN').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_TNA');
        $('#record_repeat' + index + 'A_TNA').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_TNQA');
        $('#record_repeat' + index + 'A_TNQA').css('background-color', '#efefef');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_TNR');
        $('#record_repeat' + index + 'A_TNR').css('background-color', '#efefef');
		//WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_DMQ');
		//$('#record_repeat' + index + 'A_DMQ_calendar_anchor').addClass('hidden');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_DAN');
        $('#record_repeat' + index + 'A_DAN').css('background-color', '#efefef');
		$('#record_repeat' + index + 'A_DAN_calendar_anchor').addClass('hidden');
		WHRSCMain.setAlwaysReadonly('record_repeat' + index + 'A_DANR');
        $('#record_repeat' + index + 'A_DANR').css('background-color', '#efefef');
		$('#record_repeat' + index + 'A_DANR_calendar_anchor').addClass('hidden');

		$("#record_repeat" + index + "A_EM").attr("_required", "false");
		
		
		//inidtRater(index);
        
        mSelchk('record_repeat' + index+ 'A_R',1);

		$("input[type=checkbox][name=record_repeat"+ index+ "A_R_M]").trigger("change");
        
        changeAcronyms('record_repeat' + index+ 'A_R');
        
        $('#record_repeat' + index+ 'A_R').attr("title", "Please select using space and arrows key.");
        
        

        
        
	}
    
    /*$("input[type=checkbox][name=multi_check]").on("change", function(){
            if (!$(this).prop("checked")) {
                //$(this).parent().parent().hide();  // hide parent/parent <tr><td><input ...
                alert ($(this).label());
            }
    });*/

}
function changeAcronyms(fieldval){
	var arr = new Array();
    var selData = $('#' + fieldval).val();
    
    $('#' + fieldval).find('option').each(function() {
        //alert($(this).val() + '|' + $(this).text());
        arr.push($(this).val());
    });
    $('#' + fieldval).empty();
    $('#' + fieldval).append($('<option>',{value: "", text: "Select One"}));
    
    $.each(arr, function( index, value ) {
      
      var chstr = value.split('');
      var ctext = '';
        if(value != 'N/A'){
          for ( var i in chstr ) {

                    ctext += chstr[i] + '.';
          }
        }else{
            ctext = value;
        }
      if (value != ''){
          if (selData == value){
            $('#' + fieldval).append('<option selected value=\"' + value + '\">' + ctext + '</option>');
          }else{
      		$('#' + fieldval).append('<option value=\"' + value + '\">' + ctext + '</option>');
          }
      }
    });
}

function mSelchk(mfieldnm, mCheck){
	
        $("input[type=checkbox][name=" + mfieldnm + "_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().show();
        $("input[type=checkbox][name=" + mfieldnm + "_M]").filter(function(){ return !$(this).prop("checked"); }).parent().parent().hide();

        // add event handler to the selectbox - whenever selection is made, it should be synced up in the "Selected Item" data element
        $("#" + mfieldnm).on("change", function(){
            var selVal = $(this).children("option:selected").val();
            //alert (selVal);
            //
            var selectedcnt = utility.chkMselectValuee(mfieldnm);
                       
                if (selVal != '') {
                    //selVal = encodeURl(selVal);
                    // capture the selected item and set the multiselect checkbox area
                    var selChkElms = $('input[type=checkbox][name=' + mfieldnm + '_M][value=\"' + selVal + '\"]');

                    if (selChkElms.length > 0) {  // the length should really be 1 if correctly identified
                        selChkElms.prop("checked", true);
                        $("label[for=" + selChkElms[0].id + "]").parent().removeClass("selected");
                        $("label[for=" + selChkElms[0].id + "]").parent().addClass("selected");
                        selChkElms.parent().parent().show();  // show parent/parent <tr><td><input ...
                    }
                    $("input[type=checkbox][name=" + mfieldnm + "_M]").trigger("change");
                }
            
            // after select propagation is done to selected item checkbox list, clear current select from dropdown
            $(this).val("");
        });

        // add event handler to the selected item element - whenever checkbox is unched, it should be hidden from the "Selected Item" display
        $("input[type=checkbox][name=" + mfieldnm + "_M]").on("change", function(){
            if (!$(this).prop("checked")) {
                $(this).parent().parent().hide();  // hide parent/parent <tr><td><input ...
            }

            // if no selected items left, set attribute for error check.  Otherwise, unset attribute to avoid error.
            // Madetory field check default = 0 
            if (mCheck > 0){
                if ($("input[type=checkbox][name=" + mfieldnm + "_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
                    $("#" + mfieldnm).attr("_required", "true");
                } else {
                    $("#" + mfieldnm).attr("_required", "false");
                }
            }
        });
}
function dateCompare(){
    var cnt = $('#h_applicant_count').val();
    
	var virtualCnt = cnt;
    if(cnt=="") {
		virtualCnt = 1;
	}
    
    for (var index = 1; index <= virtualCnt; index++) {
    	var startDate = $('#record_repeat' + index + 'A_DQSD').val();
        
        if (startDate != ''){
        var startDateArr = startDate.split('/');
         
        var endDate = $('#record_repeat' + index + 'A_DQA').val();
        var endDateArr = endDate.split('/');
                 
        var startDateCompare = new Date(startDateArr[2], startDateArr[0], parseInt(startDateArr[1])-1);
        var endDateCompare = new Date(endDateArr[2], endDateArr[0], parseInt(endDateArr[1])-1);
        
        if(startDateCompare.getTime() > endDateCompare.getTime()) {
             
            alert("Date Qualifications Approved must be greater than or equal to Date Qualifications sent to DEU.");
            $('#record_repeat' + index + 'A_DQA').val('');
            return;
        }
        }
    }
    //alert ('!!!');
}