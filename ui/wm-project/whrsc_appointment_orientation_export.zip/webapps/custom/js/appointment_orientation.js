var appointOrientation = function(){
    $('#O_OD_calendar_anchor').attr('tabindex', 41);
    $('#O_DOO_calendar_anchor').attr('tabindex', 121);
	$('#O_AEA_label_hint_container').attr('tabindex', 79);
    //508 setup
    $('#O_AO_label').attr('title', 'Asterisk denotes a required field');
    $('#O_DOO_label').attr('title', 'Asterisk denotes a required field');
    
    $('#O_AEA').on("change", function(){
       
        if($('#O_AEA').val().indexOf(".gov") != -1 || $('#O_AEA').val().indexOf(".mil") != -1){
          alert ("Appointee’s email ends in .gov or .mil \nTo ensure that we can contact the appointee throughout the onboarding process, please have the appointee provide a personal email instead of a government issued address.");   
        }

    });
}