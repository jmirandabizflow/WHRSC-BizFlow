var base_url = '/bizflowwebmaker/whrsc_AUT/';
var certificateInfo = function(){
    var h_transactionID = $('#h_transactionID').val();
    //var h_AnNumber = $('#h_AnNumber').val(); 
	//var h_certNumber = $('#h_certNumber').val(); 
	var getRestData = $('#h_usas_data').val();
    var alert_vinnum = '';
	if(getRestData!='') {
		var x2js = new X2JS();
		var getRestDataXML =  x2js.xml_str2json(getRestData);
		var annCount = getRestDataXML.USAStaffing_Recruitment._VacancyCount;
		var vanNumber = "";
		var certCount ="";
		
		var anns = getRestDataXML.USAStaffing_Recruitment.Vacancies;
		
		$('#C_AN').append($('<option>',{value: "", text: "Select One"}));
		for (var idx =0;idx < annCount;idx++ )
		{
			if(annCount==1) {
				var val = anns.record.Vacancy_Announcement_Number;
				$('#C_AN').append($('<option>',{value: val , text: val}));
			}
			else {
				var val = anns.record[idx].Vacancy_Announcement_Number;
				$('#C_AN').append($('<option>',{value: val , text: val}));
			}
			
			
		}

		/* if($('#h_AnNumber')!='') {
			$('#C_AN').val(h_AnNumber);

			$('#C_CN').children().remove();
			$('#C_CN').append($('<option>',{value: "", text: "Select One"}));
			for (var idx =0;idx < annCount;idx++ )
			{
				var valVan = anns.ANNOUNCEMENT[idx].V_VAN;
				if(valVan==h_AnNumber) {
					certCount = anns.ANNOUNCEMENT[idx].CERTIFICATES.CERTIFICATE.length;
					//if(certCount!='undefined' && certCount!=0)
					//{
					//	$('#h_certCount').val(certCount);
					//}	
					for(var idxCert=0;idxCert<certCount;idxCert++) {
						var valCert = anns.ANNOUNCEMENT[idx].CERTIFICATES.CERTIFICATE[idxCert].CERT_NUMBER;
						$('#C_CN').append($('<option>',{value: valCert , text: valCert}));
					}
					break;
				}	
				
			}

		}	
		*/
		/*
		if($('#h_certNumber')!='') {
			$('#C_CN').val(h_certNumber);
		}
		*/
		
		$('#C_AN').on("change", function(){

			$('#C_CN').children().remove();
		
			$('#C_ANT').val('');

			$('#C_CT').val('');

			$('#C_CI').val('');

			$('#C_DL').val('');

			$('#C_PT').val('');

			$('#C_PP').val('');

			$('#C_S').val('');

			$('#C_G').val('');

			$('#C_DCI').val('');

			$('#C_DCS').val('');

			$('#C_DCE').val('');

			$('#C_SM').val('');

			$('#C_AT').val('');

			$('#C_DHD').val('');

			$('#C_DHC').val('');

			$('#C_DFAS').val('');

			$('#C_DAC').val('');

			$('#C_PEWR').val('');
		
			$('#C_VIN').val('');
		
			alert_vinnum = '';
		
			$("#C_CE").val('No').prop("selected", true);
			$('#C_NCED').val('');
			$('#C_DIRC').val('');
			$("#C_CC").val('No').prop("selected", true);
			$("#C_CRU").val('').prop("selected", true);
			$('#C_DCR').val('');
			$('#C_CRUR').val('');

			if($('#C_AN option:selected').val()!='') {
				vanNumber = $('#C_AN option:selected').val();
				
				$('#C_CN').children().remove();
				$('#C_CN').append($('<option>',{value: "", text: "Select One"}));
				for (var idx =0;idx < annCount;idx++ ) {
					if(annCount==1) {
						var valVan = anns.record.Vacancy_Announcement_Number;
						if(valVan==vanNumber) {
							if(anns.record.Certificates!=undefined && anns.record.Certificates.record!=undefined) {
								if(anns.record.Certificates.record.length!=undefined) {
									certCount = anns.record.Certificates.record.length;
									for(var idxCert=0;idxCert<certCount;idxCert++) {
										var valCert = anns.record.Certificates.record[idxCert].Certificate_Number;
										$('#C_CN').append($('<option>',{value: valCert , text: valCert}));
									}
								}
								else {
									//certCount = 1;
									var valCert = anns.record.Certificates.record.Certificate_Number;
									$('#C_CN').append($('<option>',{value: valCert , text: valCert}));	
								}
							}
						}					
					}
					else {
						var valVan = anns.record[idx].Vacancy_Announcement_Number;
						if(valVan==vanNumber) {
							if(anns.record[idx].Certificates!=undefined && anns.record[idx].Certificates.record!=undefined) {
								if(anns.record[idx].Certificates.record.length!=undefined) {
									certCount = anns.record[idx].Certificates.record.length;
									for(var idxCert=0;idxCert<certCount;idxCert++) {
										var valCert = anns.record[idx].Certificates.record[idxCert].Certificate_Number;
										$('#C_CN').append($('<option>',{value: valCert , text: valCert}));
									}
								}
								else {
									var valCert = anns.record[idx].Certificates.record.Certificate_Number;
									$('#C_CN').append($('<option>',{value: valCert , text: valCert}));	
								}
							}
							break;
							
						}	
					}
					
				}
			}
			else {
				$('#C_CN').children().remove();
            
                $('#C_ANT').val('');

                $('#C_CT').val('');

                $('#C_CI').val('');

                $('#C_DL').val('');

                $('#C_PT').val('');

                $('#C_PP').val('');

                $('#C_S').val('');

                $('#C_G').val('');

                $('#C_DCI').val('');

                $('#C_DCS').val('');

                $('#C_DCE').val('');

                $('#C_SM').val('');

                $('#C_AT').val('');

                $('#C_DHD').val('');

                $('#C_DHC').val('');

                $('#C_DFAS').val('');

                $('#C_DAC').val('');

                $('#C_PEWR').val('');
                
                $('#C_VIN').val('');
                
                alert_vinnum = '';
                
                $("#C_CE").val('No').prop("selected", true);
                $('#C_NCED').val('');
                $('#C_DIRC').val('');
                $("#C_CC").val('No').prop("selected", true);
                $("#C_CRU").val('').prop("selected", true);
                $('#C_DCR').val('');
                $('#C_CRUR').val('');
			}
		});

		$('#C_CN').on("change", function(){
			if($('#C_CN option:selected').val()!='') {
				vanNumber = $('#C_AN option:selected').val();
				var certNumber = $('#C_CN option:selected').val();

				for (var idx =0;idx < annCount;idx++ )
				{
					if(annCount==1) {
						var valVan = anns.record.Vacancy_Announcement_Number;
						if(valVan==vanNumber) {
							if(anns.record.Certificates!=undefined && anns.record.Certificates.record!=undefined) {
								if(anns.record.Certificates.record.length!=undefined) {
									certCount = anns.record.Certificates.record.length;
									for(var idxCert=0;idxCert<certCount;idxCert++) {
										var valCert = anns.record.Certificates.record[idxCert].Certificate_Number;
										if(valCert==certNumber) {
											certNumber = valCert;
											
											//var C_ANT = anns.record.Certificates.record[idxCert].C_ANT;
											var C_ANT = anns.record.Announcement_Type;
											var C_CT = anns.record.Certificates.record[idxCert].Certificate_Type;
											//var C_CI = anns.record.Certificates.record[idxCert].C_CI;
											var C_DL = anns.record.Certificates.record[idxCert].Duty_Location;
											var C_PT = anns.record.Certificates.record[idxCert].Position_Title;
											//var C_PP = anns.record.Certificates.record[idxCert].C_PP;
											var C_S = anns.record.Certificates.record[idxCert].Series;
											var C_G = anns.record.Certificates.record[idxCert].Grade;
											var C_DCI = anns.record.Certificates.record[idxCert].Date_Certificate_Issued;											
											if(C_DCI!='') {
												C_DCI = new Date(C_DCI);
												var C_DCE = new Date(C_DCI.getTime() + 120*24*60*60*1000);
												C_DCI = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCI);
												C_DCE = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCE);
											}
											var C_DCS = anns.record.Certificates.record[idxCert].Date_Certificate_Sent_To_SO;
											if(C_DCS!='') {
												C_DCS = new Date(C_DCS);
												C_DCS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCS);
											}
											//var C_DCE = anns.record.Certificates.record[idxCert].C_DCE;
											var C_SM  = anns.record.Certificates.record[idxCert].Selection_Made;
											var C_AT = anns.record.Certificates.record[idxCert].Action_Taken;
											//var C_DHD = anns.record.Certificates.record[idxCert].C_DHD;
											//if(C_DHD!='') {
											//	C_DHD = new Date(C_DHD);
											//	C_DHD = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHD);
											//}
											var C_DHC = anns.record.Certificates.record[idxCert].Date_Hiring_Decision_Received_In_HR;
											if(C_DHC!='') {
												C_DHC = new Date(C_DHC);
												C_DHC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHC);
											}
											var C_DFAS = anns.record.Certificates.record[idxCert].Date_Final_Applicant_Statuses_Set;
											if(C_DFAS!='') {
												C_DFAS = new Date(C_DFAS);
												C_DFAS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DFAS);
											}
											var C_DAC = anns.record.Certificates.record[idxCert].Date_Audit_Completed;
											if(C_DAC!='') {
												C_DAC = new Date(C_DAC);
												C_DAC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DAC);
											}
											//var C_PEWR = anns.record.Certificates.record[idxCert].C_PEWR;
											//var C_VIN = anns.record.Certificates.record[idxCert].C_VIN;  Vacancy_Identification_Number
											var C_VIN = anns.record.Vacancy_Identification_Number;
											
											$('#C_CN option:selected').val(certNumber);
											
											$('#C_ANT').val(C_ANT);

											$('#C_CT').val(C_CT);

											//$('#C_CI').val(C_CI);

											$('#C_DL').val(C_DL);

											$('#C_PT').val(C_PT);

											//$('#C_PP').val(C_PP);

											$('#C_S').val(C_S);

											$('#C_G').val(C_G);

											$('#C_DCI').val(C_DCI);
											
											

											$('#C_DCS').val(C_DCS);

											$('#C_DCE').val(C_DCE);

											$('#C_SM').val(C_SM);

											$('#C_AT').val(C_AT);

											//$('#C_DHD').val(C_DHD);

											$('#C_DHC').val(C_DHC);

											$('#C_DFAS').val(C_DFAS);

											$('#C_DAC').val(C_DAC);

											//$('#C_PEWR').val(C_PEWR);
											
											$('#C_VIN').val(C_VIN);
											
											alert_vinnum = C_VIN;		
											
											$.ajax({
												url: base_url + 'certSearch.do?CertSearch=' + certNumber + '&AnSearch=' + vanNumber + '&TrSearch=' + h_transactionID,
												dataType: 'xml',
												cache: false,
												success: function (xmlResponse) {
													var data = $('record', xmlResponse ).map(function() {
														return {
															C_CE: $( 'CERT_EXTENDED', this ).text(),
															C_NCED: $( 'DATE_NEW_CERT_EXPIRES', this ).text(),
															C_DIRC: $( 'DATE_INTERNAL_REVIEW_COMPLETED', this ).text(),
															C_CC: $( 'CERT_USED', this ).text(),
															C_CRU: $( 'CERT_RET_UNUSED_REASON', this ).text(),
															C_DCR: $( 'DT_CERT_RTN_TO_DEU_FNL_AUDIT', this ).text(),
															C_CRUR: $( 'CERT_RET_UNUSED_REASON_OTHER', this ).text()
														};
													}).get();
													//response(data);
													if (data == ''){
														$("#C_CE").val('No').prop("selected", true);
														$('#C_NCED').val('');
														$('#C_DIRC').val('');
														$("#C_CC").val('No').prop("selected", true);
														$("#C_CRU").val('').prop("selected", true);
														$('#C_DCR').val('');
														$('#C_CRUR').val('');
														
														WHRSCMain.setAlwaysReadonly('C_NCED');
														$('#C_NCED').css('background-color', '#efefef');
														$('#C_NCED_calendar_anchor').addClass('hidden');
														WHRSCMain.setAlwaysReadonly('C_CRUR');
														$('#C_CRUR').css('background-color', '#efefef');
														$('#C_CRUR').val('');
													}else{
														$("#C_CE").val(data[0].C_CE).prop("selected", true);
														$('#C_NCED').val(data[0].C_NCED);
														$('#C_DIRC').val(data[0].C_DIRC);
														$("#C_CC").val(data[0].C_CC).prop("selected", true);
														$("#C_CRU").val(data[0].C_CRU).prop("selected", true);
														$('#C_DCR').val(data[0].C_DCR);
														$('#C_CRUR').val(data[0].C_CRUR);
														
														if (data[0].C_CE == 'No'){
															WHRSCMain.setAlwaysReadonly('C_NCED');
															$('#C_NCED').css('background-color', '#efefef');
															$('#C_NCED_calendar_anchor').addClass('hidden');
														}else{
															$('#C_NCED').removeAttr("readonly");
															$('#C_NCED').attr('alwaysDisabled','false');
															$('#C_NCED_calendar_anchor').removeClass('hidden');
															$('#C_NCED').css('background-color', '#FFFFFF');
														}
														if (data[0].C_CRU != 'Unused - Other'){
															WHRSCMain.setAlwaysReadonly('C_CRUR');
															$('#C_CRUR').css('background-color', '#efefef');
															$('#C_CRUR').val('');
															
														}else{
															$('#C_CRUR').removeAttr("readonly");
															$('#C_CRUR').css('background-color', '#FFFFFF');
														}
													}
													
													
													
													
												}
											});
											break;	
										}
										
										
										
									}
								}
								else {
									//certCount = 1;
									var valCert = anns.record.Certificates.record.Certificate_Number;
									if(valCert==certNumber) {
										certNumber = valCert;
										
										//var C_ANT = anns.record.Certificates.record.C_ANT;
										var C_ANT = anns.record.Announcement_Type;
										var C_CT = anns.record.Certificates.record.Certificate_Type;
										//var C_CI = anns.record.Certificates.record.C_CI;
										var C_DL = anns.record.Certificates.record.Duty_Location;
										var C_PT = anns.record.Certificates.record.Position_Title;
										//var C_PP = anns.record.Certificates.record.C_PP;
										var C_S = anns.record.Certificates.record.Series;
										var C_G = anns.record.Certificates.record.Grade;
										var C_DCI = anns.record.Certificates.record.Date_Certificate_Issued;
										if(C_DCI!='') {
												C_DCI = new Date(C_DCI);
												var C_DCE = new Date(C_DCI.getTime() + 120*24*60*60*1000);
												C_DCI = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCI);
												C_DCE = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCE);
										}
										var C_DCS = anns.record.Certificates.record.Date_Certificate_Sent_To_SO;
										if(C_DCS!='') {
											C_DCS = new Date(C_DCS);
											C_DCS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCS);
										}
										//var C_DCE = anns.record.Certificates.record.C_DCE;
										var C_SM  = anns.record.Certificates.record.Selection_Made;
										var C_AT = anns.record.Certificates.record.Action_Taken;
										//var C_DHD = anns.record.Certificates.record.C_DHD;
										//if(C_DHD!='') {
										//	C_DHD = new Date(C_DHD);
										//	C_DHD = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHD);
										//}
										var C_DHC = anns.record.Certificates.record.Date_Hiring_Decision_Received_In_HR;
										if(C_DHC!='') {
											C_DHC = new Date(C_DHC);
											C_DHC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHC);
										}
										var C_DFAS = anns.record.Certificates.record.Date_Final_Applicant_Statuses_Set;
										if(C_DFAS!='') {
											C_DFAS = new Date(C_DFAS);
											C_DFAS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DFAS);
										}
										var C_DAC = anns.record.Certificates.record.Date_Audit_Completed;
										if(C_DAC!='') {
											C_DAC = new Date(C_DAC);
											C_DAC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DAC);
										}
										//var C_PEWR = anns.record.Certificates.record.C_PEWR;
										var C_VIN = anns.record.Certificates.record.C_VIN;
										
										$('#C_CN option:selected').val(certNumber);
										
										$('#C_ANT').val(C_ANT);

										$('#C_CT').val(C_CT);

										//$('#C_CI').val(C_CI);

										$('#C_DL').val(C_DL);

										$('#C_PT').val(C_PT);

										//$('#C_PP').val(C_PP);

										$('#C_S').val(C_S);

										$('#C_G').val(C_G);

										$('#C_DCI').val(C_DCI);

										$('#C_DCS').val(C_DCS);

										$('#C_DCE').val(C_DCE);

										$('#C_SM').val(C_SM);

										$('#C_AT').val(C_AT);

										//$('#C_DHD').val(C_DHD);

										$('#C_DHC').val(C_DHC);

										$('#C_DFAS').val(C_DFAS);

										$('#C_DAC').val(C_DAC);

										//$('#C_PEWR').val(C_PEWR);
										
										$('#C_VIN').val(C_VIN);
										
										alert_vinnum = C_VIN;
											
										$.ajax({
											url: base_url + 'certSearch.do?CertSearch=' + certNumber + '&AnSearch=' + vanNumber + '&TrSearch=' + h_transactionID,
											dataType: 'xml',
											cache: false,
											success: function (xmlResponse) {
												var data = $('record', xmlResponse ).map(function() {
													return {
														C_CE: $( 'CERT_EXTENDED', this ).text(),
														C_NCED: $( 'DATE_NEW_CERT_EXPIRES', this ).text(),
														C_DIRC: $( 'DATE_INTERNAL_REVIEW_COMPLETED', this ).text(),
														C_CC: $( 'CERT_USED', this ).text(),
														C_CRU: $( 'CERT_RET_UNUSED_REASON', this ).text(),
														C_DCR: $( 'DT_CERT_RTN_TO_DEU_FNL_AUDIT', this ).text(),
														C_CRUR: $( 'CERT_RET_UNUSED_REASON_OTHER', this ).text()
													};
												}).get();
												//response(data);
												if (data == ''){
													$("#C_CE").val('No').prop("selected", true);
													$('#C_NCED').val('');
													$('#C_DIRC').val('');
													$("#C_CC").val('No').prop("selected", true);
													$("#C_CRU").val('').prop("selected", true);
													$('#C_DCR').val('');
													$('#C_CRUR').val('');
													
													WHRSCMain.setAlwaysReadonly('C_NCED');
													$('#C_NCED').css('background-color', '#efefef');
													$('#C_NCED_calendar_anchor').addClass('hidden');
													WHRSCMain.setAlwaysReadonly('C_CRUR');
													$('#C_CRUR').css('background-color', '#efefef');
													$('#C_CRUR').val('');
												}else{
													$("#C_CE").val(data[0].C_CE).prop("selected", true);
													$('#C_NCED').val(data[0].C_NCED);
													$('#C_DIRC').val(data[0].C_DIRC);
													$("#C_CC").val(data[0].C_CC).prop("selected", true);
													$("#C_CRU").val(data[0].C_CRU).prop("selected", true);
													$('#C_DCR').val(data[0].C_DCR);
													$('#C_CRUR').val(data[0].C_CRUR);
													
													if (data[0].C_CE == 'No'){
														WHRSCMain.setAlwaysReadonly('C_NCED');
														$('#C_NCED').css('background-color', '#efefef');
														$('#C_NCED_calendar_anchor').addClass('hidden');
													}else{
														$('#C_NCED').removeAttr("readonly");
														$('#C_NCED').attr('alwaysDisabled','false');
														$('#C_NCED_calendar_anchor').removeClass('hidden');
														$('#C_NCED').css('background-color', '#FFFFFF');
													}
													if (data[0].C_CRU != 'Unused - Other'){
														WHRSCMain.setAlwaysReadonly('C_CRUR');
														$('#C_CRUR').css('background-color', '#efefef');
														$('#C_CRUR').val('');
														
													}else{
														$('#C_CRUR').removeAttr("readonly");
														$('#C_CRUR').css('background-color', '#FFFFFF');
													}
												}
												
												
												
												
											}
										});
											
									}
									
								}
							}
						}
					}
					else {
						var valVan = anns.record[idx].Vacancy_Announcement_Number;
						if(valVan==vanNumber) {
							if(anns.record[idx].Certificates!=undefined && anns.record[idx].Certificates.record!=undefined) {
								if(anns.record[idx].Certificates.record.length!=undefined) {
									certCount = anns.record[idx].Certificates.record.length;
									for(var idxCert=0;idxCert<certCount;idxCert++) {
										var valCert = anns.record[idx].Certificates.record[idxCert].Certificate_Number;
										if(valCert==certNumber) {
											certNumber = valCert;
											
											//var C_ANT = anns.record[idx].Certificates.record[idxCert].C_ANT;
											var C_ANT = anns.record[idx].Announcement_Type;
											var C_CT = anns.record[idx].Certificates.record[idxCert].Certificate_Type;
											//var C_CI = anns.record[idx].Certificates.record[idxCert].C_CI;
											var C_DL = anns.record[idx].Certificates.record[idxCert].Duty_Location;
											var C_PT = anns.record[idx].Certificates.record[idxCert].Position_Title;
											//var C_PP = anns.record[idx].Certificates.record[idxCert].C_PP;
											var C_S = anns.record[idx].Certificates.record[idxCert].Series;
											var C_G = anns.record[idx].Certificates.record[idxCert].Grade;
											var C_DCI = anns.record[idx].Certificates.record[idxCert].Date_Certificate_Issued;
											if(C_DCI!='') {
												C_DCI = new Date(C_DCI);
												var C_DCE = new Date(C_DCI.getTime() + 120*24*60*60*1000);
												C_DCI = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCI);
												C_DCE = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCE);
											}
											var C_DCS = anns.record[idx].Certificates.record[idxCert].Date_Certificate_Sent_To_SO;
											if(C_DCS!='') {
												C_DCS = new Date(C_DCS);
												C_DCS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCS);
											}
											//var C_DCE = anns.record[idx].Certificates.record[idxCert].C_DCE;
											var C_SM  = anns.record[idx].Certificates.record[idxCert].Selection_Made;
											var C_AT = anns.record[idx].Certificates.record[idxCert].Action_Taken;
											//var C_DHD = anns.record[idx].Certificates.record[idxCert].C_DHD;
											//if(C_DHD!='') {
											//	C_DHD = new Date(C_DHD);
											//	C_DHD = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHD);
											//}
											var C_DHC = anns.record[idx].Certificates.record[idxCert].Date_Hiring_Decision_Received_In_HR;
											if(C_DHC!='') {
												C_DHC = new Date(C_DHC);
												C_DHC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHC);
											}
											var C_DFAS = anns.record[idx].Certificates.record[idxCert].Date_Final_Applicant_Statuses_Set;
											if(C_DFAS!='') {
												C_DFAS = new Date(C_DFAS);
												C_DFAS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DFAS);
											}
											var C_DAC = anns.record[idx].Certificates.record[idxCert].Date_Audit_Completed;
											if(C_DAC!='') {
												C_DAC = new Date(C_DAC);
												C_DAC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DAC);
											}
											//var C_PEWR = anns.record[idx].Certificates.record[idxCert].C_PEWR;
											//var C_VIN = anns.record[idx].Certificates.record[idxCert].C_VIN;
											var C_VIN = anns.record[idx].Vacancy_Identification_Number;
											
											$('#C_CN option:selected').val(certNumber);
											
											$('#C_ANT').val(C_ANT);

											$('#C_CT').val(C_CT);

											//$('#C_CI').val(C_CI);

											$('#C_DL').val(C_DL);

											$('#C_PT').val(C_PT);

											//$('#C_PP').val(C_PP);

											$('#C_S').val(C_S);

											$('#C_G').val(C_G);

											$('#C_DCI').val(C_DCI);

											$('#C_DCS').val(C_DCS);

											$('#C_DCE').val(C_DCE);

											$('#C_SM').val(C_SM);

											$('#C_AT').val(C_AT);

											//$('#C_DHD').val(C_DHD);

											$('#C_DHC').val(C_DHC);

											$('#C_DFAS').val(C_DFAS);

											$('#C_DAC').val(C_DAC);

											//$('#C_PEWR').val(C_PEWR);
											
											$('#C_VIN').val(C_VIN);
											
											alert_vinnum = C_VIN;
											
											$.ajax({
												url: base_url + 'certSearch.do?CertSearch=' + certNumber + '&AnSearch=' + vanNumber + '&TrSearch=' + h_transactionID,
												dataType: 'xml',
												cache: false,
												success: function (xmlResponse) {
													var data = $('record', xmlResponse ).map(function() {
														return {
															C_CE: $( 'CERT_EXTENDED', this ).text(),
															C_NCED: $( 'DATE_NEW_CERT_EXPIRES', this ).text(),
															C_DIRC: $( 'DATE_INTERNAL_REVIEW_COMPLETED', this ).text(),
															C_CC: $( 'CERT_USED', this ).text(),
															C_CRU: $( 'CERT_RET_UNUSED_REASON', this ).text(),
															C_DCR: $( 'DT_CERT_RTN_TO_DEU_FNL_AUDIT', this ).text(),
															C_CRUR: $( 'CERT_RET_UNUSED_REASON_OTHER', this ).text()
														};
													}).get();
													//response(data);
													if (data == ''){
														$("#C_CE").val('No').prop("selected", true);
														$('#C_NCED').val('');
														$('#C_DIRC').val('');
														$("#C_CC").val('No').prop("selected", true);
														$("#C_CRU").val('').prop("selected", true);
														$('#C_DCR').val('');
														$('#C_CRUR').val('');
														
														WHRSCMain.setAlwaysReadonly('C_NCED');
														$('#C_NCED').css('background-color', '#efefef');
														$('#C_NCED_calendar_anchor').addClass('hidden');
														WHRSCMain.setAlwaysReadonly('C_CRUR');
														$('#C_CRUR').css('background-color', '#efefef');
														$('#C_CRUR').val('');
													}else{
														$("#C_CE").val(data[0].C_CE).prop("selected", true);
														$('#C_NCED').val(data[0].C_NCED);
														$('#C_DIRC').val(data[0].C_DIRC);
														$("#C_CC").val(data[0].C_CC).prop("selected", true);
														$("#C_CRU").val(data[0].C_CRU).prop("selected", true);
														$('#C_DCR').val(data[0].C_DCR);
														$('#C_CRUR').val(data[0].C_CRUR);
														
														if (data[0].C_CE == 'No'){
															WHRSCMain.setAlwaysReadonly('C_NCED');
															$('#C_NCED').css('background-color', '#efefef');
															$('#C_NCED_calendar_anchor').addClass('hidden');
														}else{
															$('#C_NCED').removeAttr("readonly");
															$('#C_NCED').attr('alwaysDisabled','false');
															$('#C_NCED_calendar_anchor').removeClass('hidden');
															$('#C_NCED').css('background-color', '#FFFFFF');
														}
														if (data[0].C_CRU != 'Unused - Other'){
															WHRSCMain.setAlwaysReadonly('C_CRUR');
															$('#C_CRUR').css('background-color', '#efefef');
															$('#C_CRUR').val('');
															
														}else{
															$('#C_CRUR').removeAttr("readonly");
															$('#C_CRUR').css('background-color', '#FFFFFF');
														}
													}
													
													
													
													
												}
											});
											break;
										}
										
											
										
									}
								}
								else {
									//certCount = 1;
									var valCert = anns.record[idx].Certificates.record.Certificate_Number;
									if(valCert==certNumber) {
										certNumber = valCert;
										
										//var C_ANT = anns.record[idx].Certificates.record.C_ANT;
										var C_ANT = anns.record[idx].Announcement_Type;
										var C_CT = anns.record[idx].Certificates.record.Certificate_Type;
										//var C_CI = anns.record[idx].Certificates.record.C_CI;
										var C_DL = anns.record[idx].Certificates.record.Duty_Location;
										var C_PT = anns.record[idx].Certificates.record.Position_Title;
										//var C_PP = anns.record[idx].Certificates.record.C_PP;
										var C_S = anns.record[idx].Certificates.record.Series;
										var C_G = anns.record[idx].Certificates.record.Grade;
										var C_DCI = anns.record[idx].Certificates.record.Date_Certificate_Issued;
										if(C_DCI!='') {
												C_DCI = new Date(C_DCI);
												var C_DCE = new Date(C_DCI.getTime() + 120*24*60*60*1000);
												C_DCI = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCI);
												C_DCE = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCE);
											}
										var C_DCS = anns.record[idx].Certificates.record.Date_Certificate_Sent_To_SO;
										if(C_DCS!='') {
											C_DCS = new Date(C_DCS);
											C_DCS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DCS);
										}
										//var C_DCE = anns.record[idx].Certificates.record.C_DCE;
										var C_SM  = anns.record[idx].Certificates.record.Selection_Made;
										var C_AT = anns.record[idx].Certificates.record.Action_Taken;
										//var C_DHD = anns.record[idx].Certificates.record.C_DHD;
										//if(C_DHD!='') {
										//	C_DHD = new Date(C_DHD);
										//	C_DHD = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHD);
										//}
										var C_DHC = anns.record[idx].Certificates.record.Date_Hiring_Decision_Received_In_HR;
										if(C_DHC!='') {
											C_DHC = new Date(C_DHC);
											C_DHC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DHC);
											}
										var C_DFAS = anns.record[idx].Certificates.record.Date_Final_Applicant_Statuses_Set;
										if(C_DFAS!='') {
											C_DFAS = new Date(C_DFAS);
											C_DFAS = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DFAS);
										}
										var C_DAC = anns.record[idx].Certificates.record.Date_Audit_Completed;
										if(C_DAC!='') {
											C_DAC = new Date(C_DAC);
											C_DAC = utility.getDateString({isUTC: true, dateFormat: 'mm/dd/yyyy'}, C_DAC);
										}
										//var C_PEWR = anns.record[idx].Certificates.record.C_PEWR;
										//var C_VIN = anns.record[idx].Certificates.record.C_VIN;
										var C_VIN = anns.record[idx].Vacancy_Identification_Number;
										
										$('#C_CN option:selected').val(certNumber);
										
										$('#C_ANT').val(C_ANT);

										$('#C_CT').val(C_CT);

										//$('#C_CI').val(C_CI);

										$('#C_DL').val(C_DL);

										$('#C_PT').val(C_PT);

										//$('#C_PP').val(C_PP);

										$('#C_S').val(C_S);

										$('#C_G').val(C_G);

										$('#C_DCI').val(C_DCI);

										$('#C_DCS').val(C_DCS);

										$('#C_DCE').val(C_DCE);

										$('#C_SM').val(C_SM);

										$('#C_AT').val(C_AT);

										//$('#C_DHD').val(C_DHD);

										$('#C_DHC').val(C_DHC);

										$('#C_DFAS').val(C_DFAS);

										$('#C_DAC').val(C_DAC);

										//$('#C_PEWR').val(C_PEWR);
										
										$('#C_VIN').val(C_VIN);
										
										alert_vinnum = C_VIN;
												
										$.ajax({
											url: base_url + 'certSearch.do?CertSearch=' + certNumber + '&AnSearch=' + vanNumber + '&TrSearch=' + h_transactionID,
											dataType: 'xml',
											cache: false,
											success: function (xmlResponse) {
												var data = $('record', xmlResponse ).map(function() {
													return {
														C_CE: $( 'CERT_EXTENDED', this ).text(),
														C_NCED: $( 'DATE_NEW_CERT_EXPIRES', this ).text(),
														C_DIRC: $( 'DATE_INTERNAL_REVIEW_COMPLETED', this ).text(),
														C_CC: $( 'CERT_USED', this ).text(),
														C_CRU: $( 'CERT_RET_UNUSED_REASON', this ).text(),
														C_DCR: $( 'DT_CERT_RTN_TO_DEU_FNL_AUDIT', this ).text(),
														C_CRUR: $( 'CERT_RET_UNUSED_REASON_OTHER', this ).text()
													};
												}).get();
												//response(data);
												if (data == ''){
													$("#C_CE").val('No').prop("selected", true);
													$('#C_NCED').val('');
													$('#C_DIRC').val('');
													$("#C_CC").val('No').prop("selected", true);
													$("#C_CRU").val('').prop("selected", true);
													$('#C_DCR').val('');
													$('#C_CRUR').val('');
													
													WHRSCMain.setAlwaysReadonly('C_NCED');
													$('#C_NCED').css('background-color', '#efefef');
													$('#C_NCED_calendar_anchor').addClass('hidden');
													WHRSCMain.setAlwaysReadonly('C_CRUR');
													$('#C_CRUR').css('background-color', '#efefef');
													$('#C_CRUR').val('');
												}else{
													$("#C_CE").val(data[0].C_CE).prop("selected", true);
													$('#C_NCED').val(data[0].C_NCED);
													$('#C_DIRC').val(data[0].C_DIRC);
													$("#C_CC").val(data[0].C_CC).prop("selected", true);
													$("#C_CRU").val(data[0].C_CRU).prop("selected", true);
													$('#C_DCR').val(data[0].C_DCR);
													$('#C_CRUR').val(data[0].C_CRUR);
													
													if (data[0].C_CE == 'No'){
														WHRSCMain.setAlwaysReadonly('C_NCED');
														$('#C_NCED').css('background-color', '#efefef');
														$('#C_NCED_calendar_anchor').addClass('hidden');
													}else{
														$('#C_NCED').removeAttr("readonly");
														$('#C_NCED').attr('alwaysDisabled','false');
														$('#C_NCED_calendar_anchor').removeClass('hidden');
														$('#C_NCED').css('background-color', '#FFFFFF');
													}
													if (data[0].C_CRU != 'Unused - Other'){
														WHRSCMain.setAlwaysReadonly('C_CRUR');
														$('#C_CRUR').css('background-color', '#efefef');
														$('#C_CRUR').val('');
														
													}else{
														$('#C_CRUR').removeAttr("readonly");
														$('#C_CRUR').css('background-color', '#FFFFFF');
													}
												}
												
												
												
											}
										});
											
									}
									
								}
							}
						}
					}
				}
			}
			else {
				$('#C_CN option:selected').val('');
                
				$('#C_ANT').val('');

                $('#C_CT').val('');

                $('#C_CI').val('');

                $('#C_DL').val('');

                $('#C_PT').val('');

                $('#C_PP').val('');

                $('#C_S').val('');

                $('#C_G').val('');

                $('#C_DCI').val('');

                $('#C_DCS').val('');

                $('#C_DCE').val('');

                $('#C_SM').val('');

                $('#C_AT').val('');

                $('#C_DHD').val('');

                $('#C_DHC').val('');

                $('#C_DFAS').val('');

                $('#C_DAC').val('');

                $('#C_PEWR').val('');
                
                $('#C_VIN').val('');
                
                alert_vinnum = '';
                
                $("#C_CE").val('No').prop("selected", true);
                $('#C_NCED').val('');
                $('#C_DIRC').val('');
                $("#C_CC").val('No').prop("selected", true);
                $("#C_CRU").val('').prop("selected", true);
                $('#C_DCR').val('');
                $('#C_CRUR').val('');

			}
		});

	}
    
    //calendar icon tabindex
    $('#C_DCI_calendar_anchor').attr('tabindex', 221);
    $('#C_DCS_calendar_anchor').attr('tabindex', 241);
    $('#C_DCE_calendar_anchor').attr('tabindex', 261);
    $('#C_NCED_calendar_anchor').attr('tabindex', 276);
    $('#C_DHD_calendar_anchor').attr('tabindex', 321);
    $('#C_DHC_calendar_anchor').attr('tabindex', 341);
    $('#C_DFAS_calendar_anchor').attr('tabindex', 361);
    $('#C_DAC_calendar_anchor').attr('tabindex', 381);
    $('#C_DIRC_calendar_anchor').attr('tabindex', 401);
    $('#C_DCR_calendar_anchor').attr('tabindex', 541);
    
    
    
    $('#C_USASTAFF').on("click", function(){
        
        if (alert_vinnum==''){
    
            alert ('Please select Certificate Number!');

        }else{

            window.open('https://usastaffing.gov/referral/certificateoverview/edit/' + alert_vinnum + '','_blank');

        }

    	
    });

   
    WHRSCMain.setAlwaysReadonly('C_ANT');
    $('#C_ANT').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_CT');
    $('#C_CT').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_CI');
    $('#C_CI').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_DL');
    $('#C_DL').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_PT');
    $('#C_PT').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_PP');
    $('#C_PP').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_S');
    $('#C_S').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_G');
    $('#C_G').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_DCI');
    $('#C_DCI').css('background-color', '#efefef');
    $('#C_DCI_calendar_anchor').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('C_DCS');
    $('#C_DCS').css('background-color', '#efefef');
    $('#C_DCS_calendar_anchor').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('C_DCE');
    $('#C_DCE').css('background-color', '#efefef');
    $('#C_DCE_calendar_anchor').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('C_SM');
    $('#C_SM').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_AT');
    $('#C_AT').css('background-color', '#efefef');
    WHRSCMain.setAlwaysReadonly('C_DHD');
    $('#C_DHD').css('background-color', '#efefef');
    $('#C_DHD_calendar_anchor').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('C_DHC');
    $('#C_DHC').css('background-color', '#efefef');
    $('#C_DHC_calendar_anchor').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('C_DFAS');
    $('#C_DFAS').css('background-color', '#efefef');
    $('#C_DFAS_calendar_anchor').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('C_DAC');
    $('#C_DAC').css('background-color', '#efefef');
    $('#C_DAC_calendar_anchor').addClass('hidden');
    WHRSCMain.setAlwaysReadonly('C_PEWR');
    $('#C_PEWR').css('background-color', '#efefef');
    
    $('#temp_hidden').addClass('hidden');
    
    
    if ($('#C_CE').val() == 'No'){
        WHRSCMain.setAlwaysReadonly('C_NCED');
        $('#C_NCED').css('background-color', '#efefef');
        $('#C_NCED_calendar_anchor').addClass('hidden');
    }
    
    
    $('#C_CE').on("change", function(){
        var comSelVal = $(this).children("option:selected").val();
        if (comSelVal == 'Yes') {
            
            $('#C_NCED').removeAttr("disabled");
			$('#C_NCED').attr('alwaysDisabled','false');
            $('#C_NCED_calendar_anchor').removeClass('hidden');
            $('#C_NCED').css('background-color', '#FFFFFF');

        }else{
            
            WHRSCMain.setAlwaysReadonly('C_NCED');
            $('#C_NCED').css('background-color', '#efefef');
            $('#C_NCED_calendar_anchor').addClass('hidden');
            $('#C_NCED').val('');
        }
    });
    
    
    if ($('#C_CRU').val() != 'Unused - Other'){
        WHRSCMain.setAlwaysReadonly('C_CRUR');
        $('#C_CRUR').css('background-color', '#efefef');
       	$('#C_CRUR').val('');
    }
    
    $('#C_CRU').on("change", function(){
        var comSelVal = $(this).children("option:selected").val();
        if (comSelVal == 'Unused - Other') {
            
            $('#C_CRUR').removeAttr("readonly");
            $('#C_CRUR').css('background-color', '#FFFFFF');

        }else{
        	
            WHRSCMain.setAlwaysReadonly('C_CRUR');
            $('#C_CRUR').css('background-color', '#efefef');
            $('#C_CRUR').val('');
        }
        
    });
    
    
}