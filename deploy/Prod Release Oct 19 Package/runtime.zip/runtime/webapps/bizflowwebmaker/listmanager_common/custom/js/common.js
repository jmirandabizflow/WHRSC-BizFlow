function callPartialPage(o, action, sourceGroup, targetGroup) {

	if (window.location.pathname.indexOf('bizflowwebmaker') > -1 && action.indexOf('/') == 0) {
		action = "/bizflowwebmaker" + action;
	}

	var objEventSource5 = {
		name : 'EventSource',
		option : 'field',
		event : null,
		component : null,
		value : targetGroup,
		field : dojo.byId(targetGroup)
	};

	var objAction = {
		name : 'Action',
		option : 'Action',
		value : action
	};

	var objSourceGroup = null;
	if (null == sourceGroup || "" == sourceGroup || "all" == sourceGroup || "ALL" == sourceGroup)
	{
		objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
	}
	else
	{
		objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
	}

	var objTargetGroup = {
		name : 'TargetGroup',
		option : 'PageGroup',
		value : targetGroup
	};
	var objValidate = {
		name : 'Validate',
		option : 'Static',
		value : 'false'
	};
	hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, objEventSource5);
}

function submitFormPage(o, action) {
    var e = (typeof(event) != 'undefined') ? event : arguments[0];
    var evt = (window.event) ? window.event : e;
    var sourceComponent = null;
    if ((evt != null) && (typeof(evt) != 'undefined')) {
        sourceComponent = (evt.target) ? evt.target : evt.srcElement;
        if ((sourceComponent != null) && (sourceComponent.nodeType == 3)) // defeat Safari bug
            sourceComponent = sourceComponent.parentNode;
    }
    var objId = null;
    if (o != "undefined" && o != null && o.id != "undefined" && o.id != null) {
        objId = o.id;
    }
    var objEventSource = {
        name: 'EventSource',
        option: 'field',
        event: evt,
        component: sourceComponent,
        value: objId,
        field: document.getElementById(objId)
    };
    return dojo.hitch(objEventSource.field, function() {
        var objAction = {
            name: 'Action',
            option: 'Action',
            value: action
        };
        var objValidate = {
            name: 'Validate',
            option: 'Static',
            value: 'false'
        };
        hyf.FMAction.handleFormSubmission(objAction, objValidate, objEventSource);
    })();
}

function enableAllFields() {
	setAllFieldsEnabledDisabled("enable");
}

function disableAllFields() {
	setAllFieldsEnabledDisabled("disable");
}

function setAllFieldsEnabledDisabled(mode) {
	//mode: disable, enable
	if ("disable" == mode) {
		$("input").attr('disabled','disabled');
		$("select").attr('disabled','disabled');
		$("textarea").attr('disabled','disabled');
	} else {
		$("input").removeAttr('disabled');
		$("select").removeAttr('disabled');
		$("textarea").removeAttr('disabled');
	}
}

//Grey out screen and prevent from user input
function greyOutScreen(mode, messageBody) {
	try {
		if (mode) {
			if (null == messageBody || "" == messageBody) {
				messageBody = "<p style='font-size:30px;color:white;'>Please wait...</p>";
			}
			blockScreen(messageBody);
		} else {
			unblockScreen();
		}
	} catch (e) {}
}
/*
Wrapper API to use blockUI plugin
*/
function blockScreen(messageContent) {
	if (null == messageContent || "" == messageContent) {
		messageContent = "Please wait...";
	}
	$.blockUI({
		message: messageContent,
		css: {
			border: 'none',
			padding: '20px',
			backgroundColor: '#000',
			'-webkit-border-radius': '15px',
			'-moz-border-radius': '15px',
			opacity: .5,
			color: '#000'
	} });
}

function unblockScreen(waitTime) {
	if (null == waitTime) {
		500
	}
	$.unblockUI({ fadeOut: waitTime });
}

function getAutoCompRemoveIconElement(target, targetDescription, tabIndex) {
    var elementString = "<img src=\"" + base_url + "custom/images/delete-icon.png"
                + "\" id=\"delete-" + target + "\" deleteId=\"" + target
                + "\" title=\"Remove " + targetDescription + "\" tabindex=\"" + tabIndex + "\" /> ";

    return elementString;
}
